/*! jQuery v3.6.3 | (c) OpenJS Foundation and other contributors | jquery.org/license */
!function(e,t){"use strict";"object"==typeof module&&"object"==typeof module.exports?module.exports=e.document?t(e,!0):function(e){if(!e.document)throw new Error("jQuery requires a window with a document");return t(e)}:t(e)}("undefined"!=typeof window?window:this,function(C,e){"use strict";var t=[],r=Object.getPrototypeOf,s=t.slice,g=t.flat?function(e){return t.flat.call(e)}:function(e){return t.concat.apply([],e)},u=t.push,i=t.indexOf,n={},o=n.toString,y=n.hasOwnProperty,a=y.toString,l=a.call(Object),v={},m=function(e){return"function"==typeof e&&"number"!=typeof e.nodeType&&"function"!=typeof e.item},x=function(e){return null!=e&&e===e.window},S=C.document,c={type:!0,src:!0,nonce:!0,noModule:!0};function b(e,t,n){var r,i,o=(n=n||S).createElement("script");if(o.text=e,t)for(r in c)(i=t[r]||t.getAttribute&&t.getAttribute(r))&&o.setAttribute(r,i);n.head.appendChild(o).parentNode.removeChild(o)}function w(e){return null==e?e+"":"object"==typeof e||"function"==typeof e?n[o.call(e)]||"object":typeof e}var f="3.6.3",E=function(e,t){return new E.fn.init(e,t)};function p(e){var t=!!e&&"length"in e&&e.length,n=w(e);return!m(e)&&!x(e)&&("array"===n||0===t||"number"==typeof t&&0<t&&t-1 in e)}E.fn=E.prototype={jquery:f,constructor:E,length:0,toArray:function(){return s.call(this)},get:function(e){return null==e?s.call(this):e<0?this[e+this.length]:this[e]},pushStack:function(e){var t=E.merge(this.constructor(),e);return t.prevObject=this,t},each:function(e){return E.each(this,e)},map:function(n){return this.pushStack(E.map(this,function(e,t){return n.call(e,t,e)}))},slice:function(){return this.pushStack(s.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},even:function(){return this.pushStack(E.grep(this,function(e,t){return(t+1)%2}))},odd:function(){return this.pushStack(E.grep(this,function(e,t){return t%2}))},eq:function(e){var t=this.length,n=+e+(e<0?t:0);return this.pushStack(0<=n&&n<t?[this[n]]:[])},end:function(){return this.prevObject||this.constructor()},push:u,sort:t.sort,splice:t.splice},E.extend=E.fn.extend=function(){var e,t,n,r,i,o,a=arguments[0]||{},s=1,u=arguments.length,l=!1;for("boolean"==typeof a&&(l=a,a=arguments[s]||{},s++),"object"==typeof a||m(a)||(a={}),s===u&&(a=this,s--);s<u;s++)if(null!=(e=arguments[s]))for(t in e)r=e[t],"__proto__"!==t&&a!==r&&(l&&r&&(E.isPlainObject(r)||(i=Array.isArray(r)))?(n=a[t],o=i&&!Array.isArray(n)?[]:i||E.isPlainObject(n)?n:{},i=!1,a[t]=E.extend(l,o,r)):void 0!==r&&(a[t]=r));return a},E.extend({expando:"jQuery"+(f+Math.random()).replace(/\D/g,""),isReady:!0,error:function(e){throw new Error(e)},noop:function(){},isPlainObject:function(e){var t,n;return!(!e||"[object Object]"!==o.call(e))&&(!(t=r(e))||"function"==typeof(n=y.call(t,"constructor")&&t.constructor)&&a.call(n)===l)},isEmptyObject:function(e){var t;for(t in e)return!1;return!0},globalEval:function(e,t,n){b(e,{nonce:t&&t.nonce},n)},each:function(e,t){var n,r=0;if(p(e)){for(n=e.length;r<n;r++)if(!1===t.call(e[r],r,e[r]))break}else for(r in e)if(!1===t.call(e[r],r,e[r]))break;return e},makeArray:function(e,t){var n=t||[];return null!=e&&(p(Object(e))?E.merge(n,"string"==typeof e?[e]:e):u.call(n,e)),n},inArray:function(e,t,n){return null==t?-1:i.call(t,e,n)},merge:function(e,t){for(var n=+t.length,r=0,i=e.length;r<n;r++)e[i++]=t[r];return e.length=i,e},grep:function(e,t,n){for(var r=[],i=0,o=e.length,a=!n;i<o;i++)!t(e[i],i)!==a&&r.push(e[i]);return r},map:function(e,t,n){var r,i,o=0,a=[];if(p(e))for(r=e.length;o<r;o++)null!=(i=t(e[o],o,n))&&a.push(i);else for(o in e)null!=(i=t(e[o],o,n))&&a.push(i);return g(a)},guid:1,support:v}),"function"==typeof Symbol&&(E.fn[Symbol.iterator]=t[Symbol.iterator]),E.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),function(e,t){n["[object "+t+"]"]=t.toLowerCase()});var d=function(n){var e,d,b,o,i,h,f,g,w,u,l,T,C,a,S,y,s,c,v,E="sizzle"+1*new Date,p=n.document,k=0,r=0,m=ue(),x=ue(),A=ue(),N=ue(),j=function(e,t){return e===t&&(l=!0),0},D={}.hasOwnProperty,t=[],q=t.pop,L=t.push,H=t.push,O=t.slice,P=function(e,t){for(var n=0,r=e.length;n<r;n++)if(e[n]===t)return n;return-1},R="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",M="[\\x20\\t\\r\\n\\f]",I="(?:\\\\[\\da-fA-F]{1,6}"+M+"?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",W="\\["+M+"*("+I+")(?:"+M+"*([*^$|!~]?=)"+M+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+I+"))|)"+M+"*\\]",F=":("+I+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+W+")*)|.*)\\)|)",$=new RegExp(M+"+","g"),B=new RegExp("^"+M+"+|((?:^|[^\\\\])(?:\\\\.)*)"+M+"+$","g"),_=new RegExp("^"+M+"*,"+M+"*"),z=new RegExp("^"+M+"*([>+~]|"+M+")"+M+"*"),U=new RegExp(M+"|>"),X=new RegExp(F),V=new RegExp("^"+I+"$"),G={ID:new RegExp("^#("+I+")"),CLASS:new RegExp("^\\.("+I+")"),TAG:new RegExp("^("+I+"|[*])"),ATTR:new RegExp("^"+W),PSEUDO:new RegExp("^"+F),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+M+"*(even|odd|(([+-]|)(\\d*)n|)"+M+"*(?:([+-]|)"+M+"*(\\d+)|))"+M+"*\\)|)","i"),bool:new RegExp("^(?:"+R+")$","i"),needsContext:new RegExp("^"+M+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+M+"*((?:-\\d)?\\d*)"+M+"*\\)|)(?=[^-]|$)","i")},Y=/HTML$/i,Q=/^(?:input|select|textarea|button)$/i,J=/^h\d$/i,K=/^[^{]+\{\s*\[native \w/,Z=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,ee=/[+~]/,te=new RegExp("\\\\[\\da-fA-F]{1,6}"+M+"?|\\\\([^\\r\\n\\f])","g"),ne=function(e,t){var n="0x"+e.slice(1)-65536;return t||(n<0?String.fromCharCode(n+65536):String.fromCharCode(n>>10|55296,1023&n|56320))},re=/([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,ie=function(e,t){return t?"\0"===e?"\ufffd":e.slice(0,-1)+"\\"+e.charCodeAt(e.length-1).toString(16)+" ":"\\"+e},oe=function(){T()},ae=be(function(e){return!0===e.disabled&&"fieldset"===e.nodeName.toLowerCase()},{dir:"parentNode",next:"legend"});try{H.apply(t=O.call(p.childNodes),p.childNodes),t[p.childNodes.length].nodeType}catch(e){H={apply:t.length?function(e,t){L.apply(e,O.call(t))}:function(e,t){var n=e.length,r=0;while(e[n++]=t[r++]);e.length=n-1}}}function se(t,e,n,r){var i,o,a,s,u,l,c,f=e&&e.ownerDocument,p=e?e.nodeType:9;if(n=n||[],"string"!=typeof t||!t||1!==p&&9!==p&&11!==p)return n;if(!r&&(T(e),e=e||C,S)){if(11!==p&&(u=Z.exec(t)))if(i=u[1]){if(9===p){if(!(a=e.getElementById(i)))return n;if(a.id===i)return n.push(a),n}else if(f&&(a=f.getElementById(i))&&v(e,a)&&a.id===i)return n.push(a),n}else{if(u[2])return H.apply(n,e.getElementsByTagName(t)),n;if((i=u[3])&&d.getElementsByClassName&&e.getElementsByClassName)return H.apply(n,e.getElementsByClassName(i)),n}if(d.qsa&&!N[t+" "]&&(!y||!y.test(t))&&(1!==p||"object"!==e.nodeName.toLowerCase())){if(c=t,f=e,1===p&&(U.test(t)||z.test(t))){(f=ee.test(t)&&ve(e.parentNode)||e)===e&&d.scope||((s=e.getAttribute("id"))?s=s.replace(re,ie):e.setAttribute("id",s=E)),o=(l=h(t)).length;while(o--)l[o]=(s?"#"+s:":scope")+" "+xe(l[o]);c=l.join(",")}try{if(d.cssSupportsSelector&&!CSS.supports("selector(:is("+c+"))"))throw new Error;return H.apply(n,f.querySelectorAll(c)),n}catch(e){N(t,!0)}finally{s===E&&e.removeAttribute("id")}}}return g(t.replace(B,"$1"),e,n,r)}function ue(){var r=[];return function e(t,n){return r.push(t+" ")>b.cacheLength&&delete e[r.shift()],e[t+" "]=n}}function le(e){return e[E]=!0,e}function ce(e){var t=C.createElement("fieldset");try{return!!e(t)}catch(e){return!1}finally{t.parentNode&&t.parentNode.removeChild(t),t=null}}function fe(e,t){var n=e.split("|"),r=n.length;while(r--)b.attrHandle[n[r]]=t}function pe(e,t){var n=t&&e,r=n&&1===e.nodeType&&1===t.nodeType&&e.sourceIndex-t.sourceIndex;if(r)return r;if(n)while(n=n.nextSibling)if(n===t)return-1;return e?1:-1}function de(t){return function(e){return"input"===e.nodeName.toLowerCase()&&e.type===t}}function he(n){return function(e){var t=e.nodeName.toLowerCase();return("input"===t||"button"===t)&&e.type===n}}function ge(t){return function(e){return"form"in e?e.parentNode&&!1===e.disabled?"label"in e?"label"in e.parentNode?e.parentNode.disabled===t:e.disabled===t:e.isDisabled===t||e.isDisabled!==!t&&ae(e)===t:e.disabled===t:"label"in e&&e.disabled===t}}function ye(a){return le(function(o){return o=+o,le(function(e,t){var n,r=a([],e.length,o),i=r.length;while(i--)e[n=r[i]]&&(e[n]=!(t[n]=e[n]))})})}function ve(e){return e&&"undefined"!=typeof e.getElementsByTagName&&e}for(e in d=se.support={},i=se.isXML=function(e){var t=e&&e.namespaceURI,n=e&&(e.ownerDocument||e).documentElement;return!Y.test(t||n&&n.nodeName||"HTML")},T=se.setDocument=function(e){var t,n,r=e?e.ownerDocument||e:p;return r!=C&&9===r.nodeType&&r.documentElement&&(a=(C=r).documentElement,S=!i(C),p!=C&&(n=C.defaultView)&&n.top!==n&&(n.addEventListener?n.addEventListener("unload",oe,!1):n.attachEvent&&n.attachEvent("onunload",oe)),d.scope=ce(function(e){return a.appendChild(e).appendChild(C.createElement("div")),"undefined"!=typeof e.querySelectorAll&&!e.querySelectorAll(":scope fieldset div").length}),d.cssSupportsSelector=ce(function(){return CSS.supports("selector(*)")&&C.querySelectorAll(":is(:jqfake)")&&!CSS.supports("selector(:is(*,:jqfake))")}),d.attributes=ce(function(e){return e.className="i",!e.getAttribute("className")}),d.getElementsByTagName=ce(function(e){return e.appendChild(C.createComment("")),!e.getElementsByTagName("*").length}),d.getElementsByClassName=K.test(C.getElementsByClassName),d.getById=ce(function(e){return a.appendChild(e).id=E,!C.getElementsByName||!C.getElementsByName(E).length}),d.getById?(b.filter.ID=function(e){var t=e.replace(te,ne);return function(e){return e.getAttribute("id")===t}},b.find.ID=function(e,t){if("undefined"!=typeof t.getElementById&&S){var n=t.getElementById(e);return n?[n]:[]}}):(b.filter.ID=function(e){var n=e.replace(te,ne);return function(e){var t="undefined"!=typeof e.getAttributeNode&&e.getAttributeNode("id");return t&&t.value===n}},b.find.ID=function(e,t){if("undefined"!=typeof t.getElementById&&S){var n,r,i,o=t.getElementById(e);if(o){if((n=o.getAttributeNode("id"))&&n.value===e)return[o];i=t.getElementsByName(e),r=0;while(o=i[r++])if((n=o.getAttributeNode("id"))&&n.value===e)return[o]}return[]}}),b.find.TAG=d.getElementsByTagName?function(e,t){return"undefined"!=typeof t.getElementsByTagName?t.getElementsByTagName(e):d.qsa?t.querySelectorAll(e):void 0}:function(e,t){var n,r=[],i=0,o=t.getElementsByTagName(e);if("*"===e){while(n=o[i++])1===n.nodeType&&r.push(n);return r}return o},b.find.CLASS=d.getElementsByClassName&&function(e,t){if("undefined"!=typeof t.getElementsByClassName&&S)return t.getElementsByClassName(e)},s=[],y=[],(d.qsa=K.test(C.querySelectorAll))&&(ce(function(e){var t;a.appendChild(e).innerHTML="<a id='"+E+"'></a><select id='"+E+"-\r\\' msallowcapture=''><option selected=''></option></select>",e.querySelectorAll("[msallowcapture^='']").length&&y.push("[*^$]="+M+"*(?:''|\"\")"),e.querySelectorAll("[selected]").length||y.push("\\["+M+"*(?:value|"+R+")"),e.querySelectorAll("[id~="+E+"-]").length||y.push("~="),(t=C.createElement("input")).setAttribute("name",""),e.appendChild(t),e.querySelectorAll("[name='']").length||y.push("\\["+M+"*name"+M+"*="+M+"*(?:''|\"\")"),e.querySelectorAll(":checked").length||y.push(":checked"),e.querySelectorAll("a#"+E+"+*").length||y.push(".#.+[+~]"),e.querySelectorAll("\\\f"),y.push("[\\r\\n\\f]")}),ce(function(e){e.innerHTML="<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";var t=C.createElement("input");t.setAttribute("type","hidden"),e.appendChild(t).setAttribute("name","D"),e.querySelectorAll("[name=d]").length&&y.push("name"+M+"*[*^$|!~]?="),2!==e.querySelectorAll(":enabled").length&&y.push(":enabled",":disabled"),a.appendChild(e).disabled=!0,2!==e.querySelectorAll(":disabled").length&&y.push(":enabled",":disabled"),e.querySelectorAll("*,:x"),y.push(",.*:")})),(d.matchesSelector=K.test(c=a.matches||a.webkitMatchesSelector||a.mozMatchesSelector||a.oMatchesSelector||a.msMatchesSelector))&&ce(function(e){d.disconnectedMatch=c.call(e,"*"),c.call(e,"[s!='']:x"),s.push("!=",F)}),d.cssSupportsSelector||y.push(":has"),y=y.length&&new RegExp(y.join("|")),s=s.length&&new RegExp(s.join("|")),t=K.test(a.compareDocumentPosition),v=t||K.test(a.contains)?function(e,t){var n=9===e.nodeType&&e.documentElement||e,r=t&&t.parentNode;return e===r||!(!r||1!==r.nodeType||!(n.contains?n.contains(r):e.compareDocumentPosition&&16&e.compareDocumentPosition(r)))}:function(e,t){if(t)while(t=t.parentNode)if(t===e)return!0;return!1},j=t?function(e,t){if(e===t)return l=!0,0;var n=!e.compareDocumentPosition-!t.compareDocumentPosition;return n||(1&(n=(e.ownerDocument||e)==(t.ownerDocument||t)?e.compareDocumentPosition(t):1)||!d.sortDetached&&t.compareDocumentPosition(e)===n?e==C||e.ownerDocument==p&&v(p,e)?-1:t==C||t.ownerDocument==p&&v(p,t)?1:u?P(u,e)-P(u,t):0:4&n?-1:1)}:function(e,t){if(e===t)return l=!0,0;var n,r=0,i=e.parentNode,o=t.parentNode,a=[e],s=[t];if(!i||!o)return e==C?-1:t==C?1:i?-1:o?1:u?P(u,e)-P(u,t):0;if(i===o)return pe(e,t);n=e;while(n=n.parentNode)a.unshift(n);n=t;while(n=n.parentNode)s.unshift(n);while(a[r]===s[r])r++;return r?pe(a[r],s[r]):a[r]==p?-1:s[r]==p?1:0}),C},se.matches=function(e,t){return se(e,null,null,t)},se.matchesSelector=function(e,t){if(T(e),d.matchesSelector&&S&&!N[t+" "]&&(!s||!s.test(t))&&(!y||!y.test(t)))try{var n=c.call(e,t);if(n||d.disconnectedMatch||e.document&&11!==e.document.nodeType)return n}catch(e){N(t,!0)}return 0<se(t,C,null,[e]).length},se.contains=function(e,t){return(e.ownerDocument||e)!=C&&T(e),v(e,t)},se.attr=function(e,t){(e.ownerDocument||e)!=C&&T(e);var n=b.attrHandle[t.toLowerCase()],r=n&&D.call(b.attrHandle,t.toLowerCase())?n(e,t,!S):void 0;return void 0!==r?r:d.attributes||!S?e.getAttribute(t):(r=e.getAttributeNode(t))&&r.specified?r.value:null},se.escape=function(e){return(e+"").replace(re,ie)},se.error=function(e){throw new Error("Syntax error, unrecognized expression: "+e)},se.uniqueSort=function(e){var t,n=[],r=0,i=0;if(l=!d.detectDuplicates,u=!d.sortStable&&e.slice(0),e.sort(j),l){while(t=e[i++])t===e[i]&&(r=n.push(i));while(r--)e.splice(n[r],1)}return u=null,e},o=se.getText=function(e){var t,n="",r=0,i=e.nodeType;if(i){if(1===i||9===i||11===i){if("string"==typeof e.textContent)return e.textContent;for(e=e.firstChild;e;e=e.nextSibling)n+=o(e)}else if(3===i||4===i)return e.nodeValue}else while(t=e[r++])n+=o(t);return n},(b=se.selectors={cacheLength:50,createPseudo:le,match:G,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(e){return e[1]=e[1].replace(te,ne),e[3]=(e[3]||e[4]||e[5]||"").replace(te,ne),"~="===e[2]&&(e[3]=" "+e[3]+" "),e.slice(0,4)},CHILD:function(e){return e[1]=e[1].toLowerCase(),"nth"===e[1].slice(0,3)?(e[3]||se.error(e[0]),e[4]=+(e[4]?e[5]+(e[6]||1):2*("even"===e[3]||"odd"===e[3])),e[5]=+(e[7]+e[8]||"odd"===e[3])):e[3]&&se.error(e[0]),e},PSEUDO:function(e){var t,n=!e[6]&&e[2];return G.CHILD.test(e[0])?null:(e[3]?e[2]=e[4]||e[5]||"":n&&X.test(n)&&(t=h(n,!0))&&(t=n.indexOf(")",n.length-t)-n.length)&&(e[0]=e[0].slice(0,t),e[2]=n.slice(0,t)),e.slice(0,3))}},filter:{TAG:function(e){var t=e.replace(te,ne).toLowerCase();return"*"===e?function(){return!0}:function(e){return e.nodeName&&e.nodeName.toLowerCase()===t}},CLASS:function(e){var t=m[e+" "];return t||(t=new RegExp("(^|"+M+")"+e+"("+M+"|$)"))&&m(e,function(e){return t.test("string"==typeof e.className&&e.className||"undefined"!=typeof e.getAttribute&&e.getAttribute("class")||"")})},ATTR:function(n,r,i){return function(e){var t=se.attr(e,n);return null==t?"!="===r:!r||(t+="","="===r?t===i:"!="===r?t!==i:"^="===r?i&&0===t.indexOf(i):"*="===r?i&&-1<t.indexOf(i):"$="===r?i&&t.slice(-i.length)===i:"~="===r?-1<(" "+t.replace($," ")+" ").indexOf(i):"|="===r&&(t===i||t.slice(0,i.length+1)===i+"-"))}},CHILD:function(h,e,t,g,y){var v="nth"!==h.slice(0,3),m="last"!==h.slice(-4),x="of-type"===e;return 1===g&&0===y?function(e){return!!e.parentNode}:function(e,t,n){var r,i,o,a,s,u,l=v!==m?"nextSibling":"previousSibling",c=e.parentNode,f=x&&e.nodeName.toLowerCase(),p=!n&&!x,d=!1;if(c){if(v){while(l){a=e;while(a=a[l])if(x?a.nodeName.toLowerCase()===f:1===a.nodeType)return!1;u=l="only"===h&&!u&&"nextSibling"}return!0}if(u=[m?c.firstChild:c.lastChild],m&&p){d=(s=(r=(i=(o=(a=c)[E]||(a[E]={}))[a.uniqueID]||(o[a.uniqueID]={}))[h]||[])[0]===k&&r[1])&&r[2],a=s&&c.childNodes[s];while(a=++s&&a&&a[l]||(d=s=0)||u.pop())if(1===a.nodeType&&++d&&a===e){i[h]=[k,s,d];break}}else if(p&&(d=s=(r=(i=(o=(a=e)[E]||(a[E]={}))[a.uniqueID]||(o[a.uniqueID]={}))[h]||[])[0]===k&&r[1]),!1===d)while(a=++s&&a&&a[l]||(d=s=0)||u.pop())if((x?a.nodeName.toLowerCase()===f:1===a.nodeType)&&++d&&(p&&((i=(o=a[E]||(a[E]={}))[a.uniqueID]||(o[a.uniqueID]={}))[h]=[k,d]),a===e))break;return(d-=y)===g||d%g==0&&0<=d/g}}},PSEUDO:function(e,o){var t,a=b.pseudos[e]||b.setFilters[e.toLowerCase()]||se.error("unsupported pseudo: "+e);return a[E]?a(o):1<a.length?(t=[e,e,"",o],b.setFilters.hasOwnProperty(e.toLowerCase())?le(function(e,t){var n,r=a(e,o),i=r.length;while(i--)e[n=P(e,r[i])]=!(t[n]=r[i])}):function(e){return a(e,0,t)}):a}},pseudos:{not:le(function(e){var r=[],i=[],s=f(e.replace(B,"$1"));return s[E]?le(function(e,t,n,r){var i,o=s(e,null,r,[]),a=e.length;while(a--)(i=o[a])&&(e[a]=!(t[a]=i))}):function(e,t,n){return r[0]=e,s(r,null,n,i),r[0]=null,!i.pop()}}),has:le(function(t){return function(e){return 0<se(t,e).length}}),contains:le(function(t){return t=t.replace(te,ne),function(e){return-1<(e.textContent||o(e)).indexOf(t)}}),lang:le(function(n){return V.test(n||"")||se.error("unsupported lang: "+n),n=n.replace(te,ne).toLowerCase(),function(e){var t;do{if(t=S?e.lang:e.getAttribute("xml:lang")||e.getAttribute("lang"))return(t=t.toLowerCase())===n||0===t.indexOf(n+"-")}while((e=e.parentNode)&&1===e.nodeType);return!1}}),target:function(e){var t=n.location&&n.location.hash;return t&&t.slice(1)===e.id},root:function(e){return e===a},focus:function(e){return e===C.activeElement&&(!C.hasFocus||C.hasFocus())&&!!(e.type||e.href||~e.tabIndex)},enabled:ge(!1),disabled:ge(!0),checked:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&!!e.checked||"option"===t&&!!e.selected},selected:function(e){return e.parentNode&&e.parentNode.selectedIndex,!0===e.selected},empty:function(e){for(e=e.firstChild;e;e=e.nextSibling)if(e.nodeType<6)return!1;return!0},parent:function(e){return!b.pseudos.empty(e)},header:function(e){return J.test(e.nodeName)},input:function(e){return Q.test(e.nodeName)},button:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&"button"===e.type||"button"===t},text:function(e){var t;return"input"===e.nodeName.toLowerCase()&&"text"===e.type&&(null==(t=e.getAttribute("type"))||"text"===t.toLowerCase())},first:ye(function(){return[0]}),last:ye(function(e,t){return[t-1]}),eq:ye(function(e,t,n){return[n<0?n+t:n]}),even:ye(function(e,t){for(var n=0;n<t;n+=2)e.push(n);return e}),odd:ye(function(e,t){for(var n=1;n<t;n+=2)e.push(n);return e}),lt:ye(function(e,t,n){for(var r=n<0?n+t:t<n?t:n;0<=--r;)e.push(r);return e}),gt:ye(function(e,t,n){for(var r=n<0?n+t:n;++r<t;)e.push(r);return e})}}).pseudos.nth=b.pseudos.eq,{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})b.pseudos[e]=de(e);for(e in{submit:!0,reset:!0})b.pseudos[e]=he(e);function me(){}function xe(e){for(var t=0,n=e.length,r="";t<n;t++)r+=e[t].value;return r}function be(s,e,t){var u=e.dir,l=e.next,c=l||u,f=t&&"parentNode"===c,p=r++;return e.first?function(e,t,n){while(e=e[u])if(1===e.nodeType||f)return s(e,t,n);return!1}:function(e,t,n){var r,i,o,a=[k,p];if(n){while(e=e[u])if((1===e.nodeType||f)&&s(e,t,n))return!0}else while(e=e[u])if(1===e.nodeType||f)if(i=(o=e[E]||(e[E]={}))[e.uniqueID]||(o[e.uniqueID]={}),l&&l===e.nodeName.toLowerCase())e=e[u]||e;else{if((r=i[c])&&r[0]===k&&r[1]===p)return a[2]=r[2];if((i[c]=a)[2]=s(e,t,n))return!0}return!1}}function we(i){return 1<i.length?function(e,t,n){var r=i.length;while(r--)if(!i[r](e,t,n))return!1;return!0}:i[0]}function Te(e,t,n,r,i){for(var o,a=[],s=0,u=e.length,l=null!=t;s<u;s++)(o=e[s])&&(n&&!n(o,r,i)||(a.push(o),l&&t.push(s)));return a}function Ce(d,h,g,y,v,e){return y&&!y[E]&&(y=Ce(y)),v&&!v[E]&&(v=Ce(v,e)),le(function(e,t,n,r){var i,o,a,s=[],u=[],l=t.length,c=e||function(e,t,n){for(var r=0,i=t.length;r<i;r++)se(e,t[r],n);return n}(h||"*",n.nodeType?[n]:n,[]),f=!d||!e&&h?c:Te(c,s,d,n,r),p=g?v||(e?d:l||y)?[]:t:f;if(g&&g(f,p,n,r),y){i=Te(p,u),y(i,[],n,r),o=i.length;while(o--)(a=i[o])&&(p[u[o]]=!(f[u[o]]=a))}if(e){if(v||d){if(v){i=[],o=p.length;while(o--)(a=p[o])&&i.push(f[o]=a);v(null,p=[],i,r)}o=p.length;while(o--)(a=p[o])&&-1<(i=v?P(e,a):s[o])&&(e[i]=!(t[i]=a))}}else p=Te(p===t?p.splice(l,p.length):p),v?v(null,t,p,r):H.apply(t,p)})}function Se(e){for(var i,t,n,r=e.length,o=b.relative[e[0].type],a=o||b.relative[" "],s=o?1:0,u=be(function(e){return e===i},a,!0),l=be(function(e){return-1<P(i,e)},a,!0),c=[function(e,t,n){var r=!o&&(n||t!==w)||((i=t).nodeType?u(e,t,n):l(e,t,n));return i=null,r}];s<r;s++)if(t=b.relative[e[s].type])c=[be(we(c),t)];else{if((t=b.filter[e[s].type].apply(null,e[s].matches))[E]){for(n=++s;n<r;n++)if(b.relative[e[n].type])break;return Ce(1<s&&we(c),1<s&&xe(e.slice(0,s-1).concat({value:" "===e[s-2].type?"*":""})).replace(B,"$1"),t,s<n&&Se(e.slice(s,n)),n<r&&Se(e=e.slice(n)),n<r&&xe(e))}c.push(t)}return we(c)}return me.prototype=b.filters=b.pseudos,b.setFilters=new me,h=se.tokenize=function(e,t){var n,r,i,o,a,s,u,l=x[e+" "];if(l)return t?0:l.slice(0);a=e,s=[],u=b.preFilter;while(a){for(o in n&&!(r=_.exec(a))||(r&&(a=a.slice(r[0].length)||a),s.push(i=[])),n=!1,(r=z.exec(a))&&(n=r.shift(),i.push({value:n,type:r[0].replace(B," ")}),a=a.slice(n.length)),b.filter)!(r=G[o].exec(a))||u[o]&&!(r=u[o](r))||(n=r.shift(),i.push({value:n,type:o,matches:r}),a=a.slice(n.length));if(!n)break}return t?a.length:a?se.error(e):x(e,s).slice(0)},f=se.compile=function(e,t){var n,y,v,m,x,r,i=[],o=[],a=A[e+" "];if(!a){t||(t=h(e)),n=t.length;while(n--)(a=Se(t[n]))[E]?i.push(a):o.push(a);(a=A(e,(y=o,m=0<(v=i).length,x=0<y.length,r=function(e,t,n,r,i){var o,a,s,u=0,l="0",c=e&&[],f=[],p=w,d=e||x&&b.find.TAG("*",i),h=k+=null==p?1:Math.random()||.1,g=d.length;for(i&&(w=t==C||t||i);l!==g&&null!=(o=d[l]);l++){if(x&&o){a=0,t||o.ownerDocument==C||(T(o),n=!S);while(s=y[a++])if(s(o,t||C,n)){r.push(o);break}i&&(k=h)}m&&((o=!s&&o)&&u--,e&&c.push(o))}if(u+=l,m&&l!==u){a=0;while(s=v[a++])s(c,f,t,n);if(e){if(0<u)while(l--)c[l]||f[l]||(f[l]=q.call(r));f=Te(f)}H.apply(r,f),i&&!e&&0<f.length&&1<u+v.length&&se.uniqueSort(r)}return i&&(k=h,w=p),c},m?le(r):r))).selector=e}return a},g=se.select=function(e,t,n,r){var i,o,a,s,u,l="function"==typeof e&&e,c=!r&&h(e=l.selector||e);if(n=n||[],1===c.length){if(2<(o=c[0]=c[0].slice(0)).length&&"ID"===(a=o[0]).type&&9===t.nodeType&&S&&b.relative[o[1].type]){if(!(t=(b.find.ID(a.matches[0].replace(te,ne),t)||[])[0]))return n;l&&(t=t.parentNode),e=e.slice(o.shift().value.length)}i=G.needsContext.test(e)?0:o.length;while(i--){if(a=o[i],b.relative[s=a.type])break;if((u=b.find[s])&&(r=u(a.matches[0].replace(te,ne),ee.test(o[0].type)&&ve(t.parentNode)||t))){if(o.splice(i,1),!(e=r.length&&xe(o)))return H.apply(n,r),n;break}}}return(l||f(e,c))(r,t,!S,n,!t||ee.test(e)&&ve(t.parentNode)||t),n},d.sortStable=E.split("").sort(j).join("")===E,d.detectDuplicates=!!l,T(),d.sortDetached=ce(function(e){return 1&e.compareDocumentPosition(C.createElement("fieldset"))}),ce(function(e){return e.innerHTML="<a href='#'></a>","#"===e.firstChild.getAttribute("href")})||fe("type|href|height|width",function(e,t,n){if(!n)return e.getAttribute(t,"type"===t.toLowerCase()?1:2)}),d.attributes&&ce(function(e){return e.innerHTML="<input/>",e.firstChild.setAttribute("value",""),""===e.firstChild.getAttribute("value")})||fe("value",function(e,t,n){if(!n&&"input"===e.nodeName.toLowerCase())return e.defaultValue}),ce(function(e){return null==e.getAttribute("disabled")})||fe(R,function(e,t,n){var r;if(!n)return!0===e[t]?t.toLowerCase():(r=e.getAttributeNode(t))&&r.specified?r.value:null}),se}(C);E.find=d,E.expr=d.selectors,E.expr[":"]=E.expr.pseudos,E.uniqueSort=E.unique=d.uniqueSort,E.text=d.getText,E.isXMLDoc=d.isXML,E.contains=d.contains,E.escapeSelector=d.escape;var h=function(e,t,n){var r=[],i=void 0!==n;while((e=e[t])&&9!==e.nodeType)if(1===e.nodeType){if(i&&E(e).is(n))break;r.push(e)}return r},T=function(e,t){for(var n=[];e;e=e.nextSibling)1===e.nodeType&&e!==t&&n.push(e);return n},k=E.expr.match.needsContext;function A(e,t){return e.nodeName&&e.nodeName.toLowerCase()===t.toLowerCase()}var N=/^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;function j(e,n,r){return m(n)?E.grep(e,function(e,t){return!!n.call(e,t,e)!==r}):n.nodeType?E.grep(e,function(e){return e===n!==r}):"string"!=typeof n?E.grep(e,function(e){return-1<i.call(n,e)!==r}):E.filter(n,e,r)}E.filter=function(e,t,n){var r=t[0];return n&&(e=":not("+e+")"),1===t.length&&1===r.nodeType?E.find.matchesSelector(r,e)?[r]:[]:E.find.matches(e,E.grep(t,function(e){return 1===e.nodeType}))},E.fn.extend({find:function(e){var t,n,r=this.length,i=this;if("string"!=typeof e)return this.pushStack(E(e).filter(function(){for(t=0;t<r;t++)if(E.contains(i[t],this))return!0}));for(n=this.pushStack([]),t=0;t<r;t++)E.find(e,i[t],n);return 1<r?E.uniqueSort(n):n},filter:function(e){return this.pushStack(j(this,e||[],!1))},not:function(e){return this.pushStack(j(this,e||[],!0))},is:function(e){return!!j(this,"string"==typeof e&&k.test(e)?E(e):e||[],!1).length}});var D,q=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;(E.fn.init=function(e,t,n){var r,i;if(!e)return this;if(n=n||D,"string"==typeof e){if(!(r="<"===e[0]&&">"===e[e.length-1]&&3<=e.length?[null,e,null]:q.exec(e))||!r[1]&&t)return!t||t.jquery?(t||n).find(e):this.constructor(t).find(e);if(r[1]){if(t=t instanceof E?t[0]:t,E.merge(this,E.parseHTML(r[1],t&&t.nodeType?t.ownerDocument||t:S,!0)),N.test(r[1])&&E.isPlainObject(t))for(r in t)m(this[r])?this[r](t[r]):this.attr(r,t[r]);return this}return(i=S.getElementById(r[2]))&&(this[0]=i,this.length=1),this}return e.nodeType?(this[0]=e,this.length=1,this):m(e)?void 0!==n.ready?n.ready(e):e(E):E.makeArray(e,this)}).prototype=E.fn,D=E(S);var L=/^(?:parents|prev(?:Until|All))/,H={children:!0,contents:!0,next:!0,prev:!0};function O(e,t){while((e=e[t])&&1!==e.nodeType);return e}E.fn.extend({has:function(e){var t=E(e,this),n=t.length;return this.filter(function(){for(var e=0;e<n;e++)if(E.contains(this,t[e]))return!0})},closest:function(e,t){var n,r=0,i=this.length,o=[],a="string"!=typeof e&&E(e);if(!k.test(e))for(;r<i;r++)for(n=this[r];n&&n!==t;n=n.parentNode)if(n.nodeType<11&&(a?-1<a.index(n):1===n.nodeType&&E.find.matchesSelector(n,e))){o.push(n);break}return this.pushStack(1<o.length?E.uniqueSort(o):o)},index:function(e){return e?"string"==typeof e?i.call(E(e),this[0]):i.call(this,e.jquery?e[0]:e):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(e,t){return this.pushStack(E.uniqueSort(E.merge(this.get(),E(e,t))))},addBack:function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))}}),E.each({parent:function(e){var t=e.parentNode;return t&&11!==t.nodeType?t:null},parents:function(e){return h(e,"parentNode")},parentsUntil:function(e,t,n){return h(e,"parentNode",n)},next:function(e){return O(e,"nextSibling")},prev:function(e){return O(e,"previousSibling")},nextAll:function(e){return h(e,"nextSibling")},prevAll:function(e){return h(e,"previousSibling")},nextUntil:function(e,t,n){return h(e,"nextSibling",n)},prevUntil:function(e,t,n){return h(e,"previousSibling",n)},siblings:function(e){return T((e.parentNode||{}).firstChild,e)},children:function(e){return T(e.firstChild)},contents:function(e){return null!=e.contentDocument&&r(e.contentDocument)?e.contentDocument:(A(e,"template")&&(e=e.content||e),E.merge([],e.childNodes))}},function(r,i){E.fn[r]=function(e,t){var n=E.map(this,i,e);return"Until"!==r.slice(-5)&&(t=e),t&&"string"==typeof t&&(n=E.filter(t,n)),1<this.length&&(H[r]||E.uniqueSort(n),L.test(r)&&n.reverse()),this.pushStack(n)}});var P=/[^\x20\t\r\n\f]+/g;function R(e){return e}function M(e){throw e}function I(e,t,n,r){var i;try{e&&m(i=e.promise)?i.call(e).done(t).fail(n):e&&m(i=e.then)?i.call(e,t,n):t.apply(void 0,[e].slice(r))}catch(e){n.apply(void 0,[e])}}E.Callbacks=function(r){var e,n;r="string"==typeof r?(e=r,n={},E.each(e.match(P)||[],function(e,t){n[t]=!0}),n):E.extend({},r);var i,t,o,a,s=[],u=[],l=-1,c=function(){for(a=a||r.once,o=i=!0;u.length;l=-1){t=u.shift();while(++l<s.length)!1===s[l].apply(t[0],t[1])&&r.stopOnFalse&&(l=s.length,t=!1)}r.memory||(t=!1),i=!1,a&&(s=t?[]:"")},f={add:function(){return s&&(t&&!i&&(l=s.length-1,u.push(t)),function n(e){E.each(e,function(e,t){m(t)?r.unique&&f.has(t)||s.push(t):t&&t.length&&"string"!==w(t)&&n(t)})}(arguments),t&&!i&&c()),this},remove:function(){return E.each(arguments,function(e,t){var n;while(-1<(n=E.inArray(t,s,n)))s.splice(n,1),n<=l&&l--}),this},has:function(e){return e?-1<E.inArray(e,s):0<s.length},empty:function(){return s&&(s=[]),this},disable:function(){return a=u=[],s=t="",this},disabled:function(){return!s},lock:function(){return a=u=[],t||i||(s=t=""),this},locked:function(){return!!a},fireWith:function(e,t){return a||(t=[e,(t=t||[]).slice?t.slice():t],u.push(t),i||c()),this},fire:function(){return f.fireWith(this,arguments),this},fired:function(){return!!o}};return f},E.extend({Deferred:function(e){var o=[["notify","progress",E.Callbacks("memory"),E.Callbacks("memory"),2],["resolve","done",E.Callbacks("once memory"),E.Callbacks("once memory"),0,"resolved"],["reject","fail",E.Callbacks("once memory"),E.Callbacks("once memory"),1,"rejected"]],i="pending",a={state:function(){return i},always:function(){return s.done(arguments).fail(arguments),this},"catch":function(e){return a.then(null,e)},pipe:function(){var i=arguments;return E.Deferred(function(r){E.each(o,function(e,t){var n=m(i[t[4]])&&i[t[4]];s[t[1]](function(){var e=n&&n.apply(this,arguments);e&&m(e.promise)?e.promise().progress(r.notify).done(r.resolve).fail(r.reject):r[t[0]+"With"](this,n?[e]:arguments)})}),i=null}).promise()},then:function(t,n,r){var u=0;function l(i,o,a,s){return function(){var n=this,r=arguments,e=function(){var e,t;if(!(i<u)){if((e=a.apply(n,r))===o.promise())throw new TypeError("Thenable self-resolution");t=e&&("object"==typeof e||"function"==typeof e)&&e.then,m(t)?s?t.call(e,l(u,o,R,s),l(u,o,M,s)):(u++,t.call(e,l(u,o,R,s),l(u,o,M,s),l(u,o,R,o.notifyWith))):(a!==R&&(n=void 0,r=[e]),(s||o.resolveWith)(n,r))}},t=s?e:function(){try{e()}catch(e){E.Deferred.exceptionHook&&E.Deferred.exceptionHook(e,t.stackTrace),u<=i+1&&(a!==M&&(n=void 0,r=[e]),o.rejectWith(n,r))}};i?t():(E.Deferred.getStackHook&&(t.stackTrace=E.Deferred.getStackHook()),C.setTimeout(t))}}return E.Deferred(function(e){o[0][3].add(l(0,e,m(r)?r:R,e.notifyWith)),o[1][3].add(l(0,e,m(t)?t:R)),o[2][3].add(l(0,e,m(n)?n:M))}).promise()},promise:function(e){return null!=e?E.extend(e,a):a}},s={};return E.each(o,function(e,t){var n=t[2],r=t[5];a[t[1]]=n.add,r&&n.add(function(){i=r},o[3-e][2].disable,o[3-e][3].disable,o[0][2].lock,o[0][3].lock),n.add(t[3].fire),s[t[0]]=function(){return s[t[0]+"With"](this===s?void 0:this,arguments),this},s[t[0]+"With"]=n.fireWith}),a.promise(s),e&&e.call(s,s),s},when:function(e){var n=arguments.length,t=n,r=Array(t),i=s.call(arguments),o=E.Deferred(),a=function(t){return function(e){r[t]=this,i[t]=1<arguments.length?s.call(arguments):e,--n||o.resolveWith(r,i)}};if(n<=1&&(I(e,o.done(a(t)).resolve,o.reject,!n),"pending"===o.state()||m(i[t]&&i[t].then)))return o.then();while(t--)I(i[t],a(t),o.reject);return o.promise()}});var W=/^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;E.Deferred.exceptionHook=function(e,t){C.console&&C.console.warn&&e&&W.test(e.name)&&C.console.warn("jQuery.Deferred exception: "+e.message,e.stack,t)},E.readyException=function(e){C.setTimeout(function(){throw e})};var F=E.Deferred();function $(){S.removeEventListener("DOMContentLoaded",$),C.removeEventListener("load",$),E.ready()}E.fn.ready=function(e){return F.then(e)["catch"](function(e){E.readyException(e)}),this},E.extend({isReady:!1,readyWait:1,ready:function(e){(!0===e?--E.readyWait:E.isReady)||(E.isReady=!0)!==e&&0<--E.readyWait||F.resolveWith(S,[E])}}),E.ready.then=F.then,"complete"===S.readyState||"loading"!==S.readyState&&!S.documentElement.doScroll?C.setTimeout(E.ready):(S.addEventListener("DOMContentLoaded",$),C.addEventListener("load",$));var B=function(e,t,n,r,i,o,a){var s=0,u=e.length,l=null==n;if("object"===w(n))for(s in i=!0,n)B(e,t,s,n[s],!0,o,a);else if(void 0!==r&&(i=!0,m(r)||(a=!0),l&&(a?(t.call(e,r),t=null):(l=t,t=function(e,t,n){return l.call(E(e),n)})),t))for(;s<u;s++)t(e[s],n,a?r:r.call(e[s],s,t(e[s],n)));return i?e:l?t.call(e):u?t(e[0],n):o},_=/^-ms-/,z=/-([a-z])/g;function U(e,t){return t.toUpperCase()}function X(e){return e.replace(_,"ms-").replace(z,U)}var V=function(e){return 1===e.nodeType||9===e.nodeType||!+e.nodeType};function G(){this.expando=E.expando+G.uid++}G.uid=1,G.prototype={cache:function(e){var t=e[this.expando];return t||(t={},V(e)&&(e.nodeType?e[this.expando]=t:Object.defineProperty(e,this.expando,{value:t,configurable:!0}))),t},set:function(e,t,n){var r,i=this.cache(e);if("string"==typeof t)i[X(t)]=n;else for(r in t)i[X(r)]=t[r];return i},get:function(e,t){return void 0===t?this.cache(e):e[this.expando]&&e[this.expando][X(t)]},access:function(e,t,n){return void 0===t||t&&"string"==typeof t&&void 0===n?this.get(e,t):(this.set(e,t,n),void 0!==n?n:t)},remove:function(e,t){var n,r=e[this.expando];if(void 0!==r){if(void 0!==t){n=(t=Array.isArray(t)?t.map(X):(t=X(t))in r?[t]:t.match(P)||[]).length;while(n--)delete r[t[n]]}(void 0===t||E.isEmptyObject(r))&&(e.nodeType?e[this.expando]=void 0:delete e[this.expando])}},hasData:function(e){var t=e[this.expando];return void 0!==t&&!E.isEmptyObject(t)}};var Y=new G,Q=new G,J=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,K=/[A-Z]/g;function Z(e,t,n){var r,i;if(void 0===n&&1===e.nodeType)if(r="data-"+t.replace(K,"-$&").toLowerCase(),"string"==typeof(n=e.getAttribute(r))){try{n="true"===(i=n)||"false"!==i&&("null"===i?null:i===+i+""?+i:J.test(i)?JSON.parse(i):i)}catch(e){}Q.set(e,t,n)}else n=void 0;return n}E.extend({hasData:function(e){return Q.hasData(e)||Y.hasData(e)},data:function(e,t,n){return Q.access(e,t,n)},removeData:function(e,t){Q.remove(e,t)},_data:function(e,t,n){return Y.access(e,t,n)},_removeData:function(e,t){Y.remove(e,t)}}),E.fn.extend({data:function(n,e){var t,r,i,o=this[0],a=o&&o.attributes;if(void 0===n){if(this.length&&(i=Q.get(o),1===o.nodeType&&!Y.get(o,"hasDataAttrs"))){t=a.length;while(t--)a[t]&&0===(r=a[t].name).indexOf("data-")&&(r=X(r.slice(5)),Z(o,r,i[r]));Y.set(o,"hasDataAttrs",!0)}return i}return"object"==typeof n?this.each(function(){Q.set(this,n)}):B(this,function(e){var t;if(o&&void 0===e)return void 0!==(t=Q.get(o,n))?t:void 0!==(t=Z(o,n))?t:void 0;this.each(function(){Q.set(this,n,e)})},null,e,1<arguments.length,null,!0)},removeData:function(e){return this.each(function(){Q.remove(this,e)})}}),E.extend({queue:function(e,t,n){var r;if(e)return t=(t||"fx")+"queue",r=Y.get(e,t),n&&(!r||Array.isArray(n)?r=Y.access(e,t,E.makeArray(n)):r.push(n)),r||[]},dequeue:function(e,t){t=t||"fx";var n=E.queue(e,t),r=n.length,i=n.shift(),o=E._queueHooks(e,t);"inprogress"===i&&(i=n.shift(),r--),i&&("fx"===t&&n.unshift("inprogress"),delete o.stop,i.call(e,function(){E.dequeue(e,t)},o)),!r&&o&&o.empty.fire()},_queueHooks:function(e,t){var n=t+"queueHooks";return Y.get(e,n)||Y.access(e,n,{empty:E.Callbacks("once memory").add(function(){Y.remove(e,[t+"queue",n])})})}}),E.fn.extend({queue:function(t,n){var e=2;return"string"!=typeof t&&(n=t,t="fx",e--),arguments.length<e?E.queue(this[0],t):void 0===n?this:this.each(function(){var e=E.queue(this,t,n);E._queueHooks(this,t),"fx"===t&&"inprogress"!==e[0]&&E.dequeue(this,t)})},dequeue:function(e){return this.each(function(){E.dequeue(this,e)})},clearQueue:function(e){return this.queue(e||"fx",[])},promise:function(e,t){var n,r=1,i=E.Deferred(),o=this,a=this.length,s=function(){--r||i.resolveWith(o,[o])};"string"!=typeof e&&(t=e,e=void 0),e=e||"fx";while(a--)(n=Y.get(o[a],e+"queueHooks"))&&n.empty&&(r++,n.empty.add(s));return s(),i.promise(t)}});var ee=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,te=new RegExp("^(?:([+-])=|)("+ee+")([a-z%]*)$","i"),ne=["Top","Right","Bottom","Left"],re=S.documentElement,ie=function(e){return E.contains(e.ownerDocument,e)},oe={composed:!0};re.getRootNode&&(ie=function(e){return E.contains(e.ownerDocument,e)||e.getRootNode(oe)===e.ownerDocument});var ae=function(e,t){return"none"===(e=t||e).style.display||""===e.style.display&&ie(e)&&"none"===E.css(e,"display")};function se(e,t,n,r){var i,o,a=20,s=r?function(){return r.cur()}:function(){return E.css(e,t,"")},u=s(),l=n&&n[3]||(E.cssNumber[t]?"":"px"),c=e.nodeType&&(E.cssNumber[t]||"px"!==l&&+u)&&te.exec(E.css(e,t));if(c&&c[3]!==l){u/=2,l=l||c[3],c=+u||1;while(a--)E.style(e,t,c+l),(1-o)*(1-(o=s()/u||.5))<=0&&(a=0),c/=o;c*=2,E.style(e,t,c+l),n=n||[]}return n&&(c=+c||+u||0,i=n[1]?c+(n[1]+1)*n[2]:+n[2],r&&(r.unit=l,r.start=c,r.end=i)),i}var ue={};function le(e,t){for(var n,r,i,o,a,s,u,l=[],c=0,f=e.length;c<f;c++)(r=e[c]).style&&(n=r.style.display,t?("none"===n&&(l[c]=Y.get(r,"display")||null,l[c]||(r.style.display="")),""===r.style.display&&ae(r)&&(l[c]=(u=a=o=void 0,a=(i=r).ownerDocument,s=i.nodeName,(u=ue[s])||(o=a.body.appendChild(a.createElement(s)),u=E.css(o,"display"),o.parentNode.removeChild(o),"none"===u&&(u="block"),ue[s]=u)))):"none"!==n&&(l[c]="none",Y.set(r,"display",n)));for(c=0;c<f;c++)null!=l[c]&&(e[c].style.display=l[c]);return e}E.fn.extend({show:function(){return le(this,!0)},hide:function(){return le(this)},toggle:function(e){return"boolean"==typeof e?e?this.show():this.hide():this.each(function(){ae(this)?E(this).show():E(this).hide()})}});var ce,fe,pe=/^(?:checkbox|radio)$/i,de=/<([a-z][^\/\0>\x20\t\r\n\f]*)/i,he=/^$|^module$|\/(?:java|ecma)script/i;ce=S.createDocumentFragment().appendChild(S.createElement("div")),(fe=S.createElement("input")).setAttribute("type","radio"),fe.setAttribute("checked","checked"),fe.setAttribute("name","t"),ce.appendChild(fe),v.checkClone=ce.cloneNode(!0).cloneNode(!0).lastChild.checked,ce.innerHTML="<textarea>x</textarea>",v.noCloneChecked=!!ce.cloneNode(!0).lastChild.defaultValue,ce.innerHTML="<option></option>",v.option=!!ce.lastChild;var ge={thead:[1,"<table>","</table>"],col:[2,"<table><colgroup>","</colgroup></table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:[0,"",""]};function ye(e,t){var n;return n="undefined"!=typeof e.getElementsByTagName?e.getElementsByTagName(t||"*"):"undefined"!=typeof e.querySelectorAll?e.querySelectorAll(t||"*"):[],void 0===t||t&&A(e,t)?E.merge([e],n):n}function ve(e,t){for(var n=0,r=e.length;n<r;n++)Y.set(e[n],"globalEval",!t||Y.get(t[n],"globalEval"))}ge.tbody=ge.tfoot=ge.colgroup=ge.caption=ge.thead,ge.th=ge.td,v.option||(ge.optgroup=ge.option=[1,"<select multiple='multiple'>","</select>"]);var me=/<|&#?\w+;/;function xe(e,t,n,r,i){for(var o,a,s,u,l,c,f=t.createDocumentFragment(),p=[],d=0,h=e.length;d<h;d++)if((o=e[d])||0===o)if("object"===w(o))E.merge(p,o.nodeType?[o]:o);else if(me.test(o)){a=a||f.appendChild(t.createElement("div")),s=(de.exec(o)||["",""])[1].toLowerCase(),u=ge[s]||ge._default,a.innerHTML=u[1]+E.htmlPrefilter(o)+u[2],c=u[0];while(c--)a=a.lastChild;E.merge(p,a.childNodes),(a=f.firstChild).textContent=""}else p.push(t.createTextNode(o));f.textContent="",d=0;while(o=p[d++])if(r&&-1<E.inArray(o,r))i&&i.push(o);else if(l=ie(o),a=ye(f.appendChild(o),"script"),l&&ve(a),n){c=0;while(o=a[c++])he.test(o.type||"")&&n.push(o)}return f}var be=/^([^.]*)(?:\.(.+)|)/;function we(){return!0}function Te(){return!1}function Ce(e,t){return e===function(){try{return S.activeElement}catch(e){}}()==("focus"===t)}function Se(e,t,n,r,i,o){var a,s;if("object"==typeof t){for(s in"string"!=typeof n&&(r=r||n,n=void 0),t)Se(e,s,n,r,t[s],o);return e}if(null==r&&null==i?(i=n,r=n=void 0):null==i&&("string"==typeof n?(i=r,r=void 0):(i=r,r=n,n=void 0)),!1===i)i=Te;else if(!i)return e;return 1===o&&(a=i,(i=function(e){return E().off(e),a.apply(this,arguments)}).guid=a.guid||(a.guid=E.guid++)),e.each(function(){E.event.add(this,t,i,r,n)})}function Ee(e,i,o){o?(Y.set(e,i,!1),E.event.add(e,i,{namespace:!1,handler:function(e){var t,n,r=Y.get(this,i);if(1&e.isTrigger&&this[i]){if(r.length)(E.event.special[i]||{}).delegateType&&e.stopPropagation();else if(r=s.call(arguments),Y.set(this,i,r),t=o(this,i),this[i](),r!==(n=Y.get(this,i))||t?Y.set(this,i,!1):n={},r!==n)return e.stopImmediatePropagation(),e.preventDefault(),n&&n.value}else r.length&&(Y.set(this,i,{value:E.event.trigger(E.extend(r[0],E.Event.prototype),r.slice(1),this)}),e.stopImmediatePropagation())}})):void 0===Y.get(e,i)&&E.event.add(e,i,we)}E.event={global:{},add:function(t,e,n,r,i){var o,a,s,u,l,c,f,p,d,h,g,y=Y.get(t);if(V(t)){n.handler&&(n=(o=n).handler,i=o.selector),i&&E.find.matchesSelector(re,i),n.guid||(n.guid=E.guid++),(u=y.events)||(u=y.events=Object.create(null)),(a=y.handle)||(a=y.handle=function(e){return"undefined"!=typeof E&&E.event.triggered!==e.type?E.event.dispatch.apply(t,arguments):void 0}),l=(e=(e||"").match(P)||[""]).length;while(l--)d=g=(s=be.exec(e[l])||[])[1],h=(s[2]||"").split(".").sort(),d&&(f=E.event.special[d]||{},d=(i?f.delegateType:f.bindType)||d,f=E.event.special[d]||{},c=E.extend({type:d,origType:g,data:r,handler:n,guid:n.guid,selector:i,needsContext:i&&E.expr.match.needsContext.test(i),namespace:h.join(".")},o),(p=u[d])||((p=u[d]=[]).delegateCount=0,f.setup&&!1!==f.setup.call(t,r,h,a)||t.addEventListener&&t.addEventListener(d,a)),f.add&&(f.add.call(t,c),c.handler.guid||(c.handler.guid=n.guid)),i?p.splice(p.delegateCount++,0,c):p.push(c),E.event.global[d]=!0)}},remove:function(e,t,n,r,i){var o,a,s,u,l,c,f,p,d,h,g,y=Y.hasData(e)&&Y.get(e);if(y&&(u=y.events)){l=(t=(t||"").match(P)||[""]).length;while(l--)if(d=g=(s=be.exec(t[l])||[])[1],h=(s[2]||"").split(".").sort(),d){f=E.event.special[d]||{},p=u[d=(r?f.delegateType:f.bindType)||d]||[],s=s[2]&&new RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"),a=o=p.length;while(o--)c=p[o],!i&&g!==c.origType||n&&n.guid!==c.guid||s&&!s.test(c.namespace)||r&&r!==c.selector&&("**"!==r||!c.selector)||(p.splice(o,1),c.selector&&p.delegateCount--,f.remove&&f.remove.call(e,c));a&&!p.length&&(f.teardown&&!1!==f.teardown.call(e,h,y.handle)||E.removeEvent(e,d,y.handle),delete u[d])}else for(d in u)E.event.remove(e,d+t[l],n,r,!0);E.isEmptyObject(u)&&Y.remove(e,"handle events")}},dispatch:function(e){var t,n,r,i,o,a,s=new Array(arguments.length),u=E.event.fix(e),l=(Y.get(this,"events")||Object.create(null))[u.type]||[],c=E.event.special[u.type]||{};for(s[0]=u,t=1;t<arguments.length;t++)s[t]=arguments[t];if(u.delegateTarget=this,!c.preDispatch||!1!==c.preDispatch.call(this,u)){a=E.event.handlers.call(this,u,l),t=0;while((i=a[t++])&&!u.isPropagationStopped()){u.currentTarget=i.elem,n=0;while((o=i.handlers[n++])&&!u.isImmediatePropagationStopped())u.rnamespace&&!1!==o.namespace&&!u.rnamespace.test(o.namespace)||(u.handleObj=o,u.data=o.data,void 0!==(r=((E.event.special[o.origType]||{}).handle||o.handler).apply(i.elem,s))&&!1===(u.result=r)&&(u.preventDefault(),u.stopPropagation()))}return c.postDispatch&&c.postDispatch.call(this,u),u.result}},handlers:function(e,t){var n,r,i,o,a,s=[],u=t.delegateCount,l=e.target;if(u&&l.nodeType&&!("click"===e.type&&1<=e.button))for(;l!==this;l=l.parentNode||this)if(1===l.nodeType&&("click"!==e.type||!0!==l.disabled)){for(o=[],a={},n=0;n<u;n++)void 0===a[i=(r=t[n]).selector+" "]&&(a[i]=r.needsContext?-1<E(i,this).index(l):E.find(i,this,null,[l]).length),a[i]&&o.push(r);o.length&&s.push({elem:l,handlers:o})}return l=this,u<t.length&&s.push({elem:l,handlers:t.slice(u)}),s},addProp:function(t,e){Object.defineProperty(E.Event.prototype,t,{enumerable:!0,configurable:!0,get:m(e)?function(){if(this.originalEvent)return e(this.originalEvent)}:function(){if(this.originalEvent)return this.originalEvent[t]},set:function(e){Object.defineProperty(this,t,{enumerable:!0,configurable:!0,writable:!0,value:e})}})},fix:function(e){return e[E.expando]?e:new E.Event(e)},special:{load:{noBubble:!0},click:{setup:function(e){var t=this||e;return pe.test(t.type)&&t.click&&A(t,"input")&&Ee(t,"click",we),!1},trigger:function(e){var t=this||e;return pe.test(t.type)&&t.click&&A(t,"input")&&Ee(t,"click"),!0},_default:function(e){var t=e.target;return pe.test(t.type)&&t.click&&A(t,"input")&&Y.get(t,"click")||A(t,"a")}},beforeunload:{postDispatch:function(e){void 0!==e.result&&e.originalEvent&&(e.originalEvent.returnValue=e.result)}}}},E.removeEvent=function(e,t,n){e.removeEventListener&&e.removeEventListener(t,n)},E.Event=function(e,t){if(!(this instanceof E.Event))return new E.Event(e,t);e&&e.type?(this.originalEvent=e,this.type=e.type,this.isDefaultPrevented=e.defaultPrevented||void 0===e.defaultPrevented&&!1===e.returnValue?we:Te,this.target=e.target&&3===e.target.nodeType?e.target.parentNode:e.target,this.currentTarget=e.currentTarget,this.relatedTarget=e.relatedTarget):this.type=e,t&&E.extend(this,t),this.timeStamp=e&&e.timeStamp||Date.now(),this[E.expando]=!0},E.Event.prototype={constructor:E.Event,isDefaultPrevented:Te,isPropagationStopped:Te,isImmediatePropagationStopped:Te,isSimulated:!1,preventDefault:function(){var e=this.originalEvent;this.isDefaultPrevented=we,e&&!this.isSimulated&&e.preventDefault()},stopPropagation:function(){var e=this.originalEvent;this.isPropagationStopped=we,e&&!this.isSimulated&&e.stopPropagation()},stopImmediatePropagation:function(){var e=this.originalEvent;this.isImmediatePropagationStopped=we,e&&!this.isSimulated&&e.stopImmediatePropagation(),this.stopPropagation()}},E.each({altKey:!0,bubbles:!0,cancelable:!0,changedTouches:!0,ctrlKey:!0,detail:!0,eventPhase:!0,metaKey:!0,pageX:!0,pageY:!0,shiftKey:!0,view:!0,"char":!0,code:!0,charCode:!0,key:!0,keyCode:!0,button:!0,buttons:!0,clientX:!0,clientY:!0,offsetX:!0,offsetY:!0,pointerId:!0,pointerType:!0,screenX:!0,screenY:!0,targetTouches:!0,toElement:!0,touches:!0,which:!0},E.event.addProp),E.each({focus:"focusin",blur:"focusout"},function(t,e){E.event.special[t]={setup:function(){return Ee(this,t,Ce),!1},trigger:function(){return Ee(this,t),!0},_default:function(e){return Y.get(e.target,t)},delegateType:e}}),E.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(e,i){E.event.special[e]={delegateType:i,bindType:i,handle:function(e){var t,n=e.relatedTarget,r=e.handleObj;return n&&(n===this||E.contains(this,n))||(e.type=r.origType,t=r.handler.apply(this,arguments),e.type=i),t}}}),E.fn.extend({on:function(e,t,n,r){return Se(this,e,t,n,r)},one:function(e,t,n,r){return Se(this,e,t,n,r,1)},off:function(e,t,n){var r,i;if(e&&e.preventDefault&&e.handleObj)return r=e.handleObj,E(e.delegateTarget).off(r.namespace?r.origType+"."+r.namespace:r.origType,r.selector,r.handler),this;if("object"==typeof e){for(i in e)this.off(i,t,e[i]);return this}return!1!==t&&"function"!=typeof t||(n=t,t=void 0),!1===n&&(n=Te),this.each(function(){E.event.remove(this,e,n,t)})}});var ke=/<script|<style|<link/i,Ae=/checked\s*(?:[^=]|=\s*.checked.)/i,Ne=/^\s*<!\[CDATA\[|\]\]>\s*$/g;function je(e,t){return A(e,"table")&&A(11!==t.nodeType?t:t.firstChild,"tr")&&E(e).children("tbody")[0]||e}function De(e){return e.type=(null!==e.getAttribute("type"))+"/"+e.type,e}function qe(e){return"true/"===(e.type||"").slice(0,5)?e.type=e.type.slice(5):e.removeAttribute("type"),e}function Le(e,t){var n,r,i,o,a,s;if(1===t.nodeType){if(Y.hasData(e)&&(s=Y.get(e).events))for(i in Y.remove(t,"handle events"),s)for(n=0,r=s[i].length;n<r;n++)E.event.add(t,i,s[i][n]);Q.hasData(e)&&(o=Q.access(e),a=E.extend({},o),Q.set(t,a))}}function He(n,r,i,o){r=g(r);var e,t,a,s,u,l,c=0,f=n.length,p=f-1,d=r[0],h=m(d);if(h||1<f&&"string"==typeof d&&!v.checkClone&&Ae.test(d))return n.each(function(e){var t=n.eq(e);h&&(r[0]=d.call(this,e,t.html())),He(t,r,i,o)});if(f&&(t=(e=xe(r,n[0].ownerDocument,!1,n,o)).firstChild,1===e.childNodes.length&&(e=t),t||o)){for(s=(a=E.map(ye(e,"script"),De)).length;c<f;c++)u=e,c!==p&&(u=E.clone(u,!0,!0),s&&E.merge(a,ye(u,"script"))),i.call(n[c],u,c);if(s)for(l=a[a.length-1].ownerDocument,E.map(a,qe),c=0;c<s;c++)u=a[c],he.test(u.type||"")&&!Y.access(u,"globalEval")&&E.contains(l,u)&&(u.src&&"module"!==(u.type||"").toLowerCase()?E._evalUrl&&!u.noModule&&E._evalUrl(u.src,{nonce:u.nonce||u.getAttribute("nonce")},l):b(u.textContent.replace(Ne,""),u,l))}return n}function Oe(e,t,n){for(var r,i=t?E.filter(t,e):e,o=0;null!=(r=i[o]);o++)n||1!==r.nodeType||E.cleanData(ye(r)),r.parentNode&&(n&&ie(r)&&ve(ye(r,"script")),r.parentNode.removeChild(r));return e}E.extend({htmlPrefilter:function(e){return e},clone:function(e,t,n){var r,i,o,a,s,u,l,c=e.cloneNode(!0),f=ie(e);if(!(v.noCloneChecked||1!==e.nodeType&&11!==e.nodeType||E.isXMLDoc(e)))for(a=ye(c),r=0,i=(o=ye(e)).length;r<i;r++)s=o[r],u=a[r],void 0,"input"===(l=u.nodeName.toLowerCase())&&pe.test(s.type)?u.checked=s.checked:"input"!==l&&"textarea"!==l||(u.defaultValue=s.defaultValue);if(t)if(n)for(o=o||ye(e),a=a||ye(c),r=0,i=o.length;r<i;r++)Le(o[r],a[r]);else Le(e,c);return 0<(a=ye(c,"script")).length&&ve(a,!f&&ye(e,"script")),c},cleanData:function(e){for(var t,n,r,i=E.event.special,o=0;void 0!==(n=e[o]);o++)if(V(n)){if(t=n[Y.expando]){if(t.events)for(r in t.events)i[r]?E.event.remove(n,r):E.removeEvent(n,r,t.handle);n[Y.expando]=void 0}n[Q.expando]&&(n[Q.expando]=void 0)}}}),E.fn.extend({detach:function(e){return Oe(this,e,!0)},remove:function(e){return Oe(this,e)},text:function(e){return B(this,function(e){return void 0===e?E.text(this):this.empty().each(function(){1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||(this.textContent=e)})},null,e,arguments.length)},append:function(){return He(this,arguments,function(e){1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||je(this,e).appendChild(e)})},prepend:function(){return He(this,arguments,function(e){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var t=je(this,e);t.insertBefore(e,t.firstChild)}})},before:function(){return He(this,arguments,function(e){this.parentNode&&this.parentNode.insertBefore(e,this)})},after:function(){return He(this,arguments,function(e){this.parentNode&&this.parentNode.insertBefore(e,this.nextSibling)})},empty:function(){for(var e,t=0;null!=(e=this[t]);t++)1===e.nodeType&&(E.cleanData(ye(e,!1)),e.textContent="");return this},clone:function(e,t){return e=null!=e&&e,t=null==t?e:t,this.map(function(){return E.clone(this,e,t)})},html:function(e){return B(this,function(e){var t=this[0]||{},n=0,r=this.length;if(void 0===e&&1===t.nodeType)return t.innerHTML;if("string"==typeof e&&!ke.test(e)&&!ge[(de.exec(e)||["",""])[1].toLowerCase()]){e=E.htmlPrefilter(e);try{for(;n<r;n++)1===(t=this[n]||{}).nodeType&&(E.cleanData(ye(t,!1)),t.innerHTML=e);t=0}catch(e){}}t&&this.empty().append(e)},null,e,arguments.length)},replaceWith:function(){var n=[];return He(this,arguments,function(e){var t=this.parentNode;E.inArray(this,n)<0&&(E.cleanData(ye(this)),t&&t.replaceChild(e,this))},n)}}),E.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(e,a){E.fn[e]=function(e){for(var t,n=[],r=E(e),i=r.length-1,o=0;o<=i;o++)t=o===i?this:this.clone(!0),E(r[o])[a](t),u.apply(n,t.get());return this.pushStack(n)}});var Pe=new RegExp("^("+ee+")(?!px)[a-z%]+$","i"),Re=/^--/,Me=function(e){var t=e.ownerDocument.defaultView;return t&&t.opener||(t=C),t.getComputedStyle(e)},Ie=function(e,t,n){var r,i,o={};for(i in t)o[i]=e.style[i],e.style[i]=t[i];for(i in r=n.call(e),t)e.style[i]=o[i];return r},We=new RegExp(ne.join("|"),"i"),Fe="[\\x20\\t\\r\\n\\f]",$e=new RegExp("^"+Fe+"+|((?:^|[^\\\\])(?:\\\\.)*)"+Fe+"+$","g");function Be(e,t,n){var r,i,o,a,s=Re.test(t),u=e.style;return(n=n||Me(e))&&(a=n.getPropertyValue(t)||n[t],s&&a&&(a=a.replace($e,"$1")||void 0),""!==a||ie(e)||(a=E.style(e,t)),!v.pixelBoxStyles()&&Pe.test(a)&&We.test(t)&&(r=u.width,i=u.minWidth,o=u.maxWidth,u.minWidth=u.maxWidth=u.width=a,a=n.width,u.width=r,u.minWidth=i,u.maxWidth=o)),void 0!==a?a+"":a}function _e(e,t){return{get:function(){if(!e())return(this.get=t).apply(this,arguments);delete this.get}}}!function(){function e(){if(l){u.style.cssText="position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0",l.style.cssText="position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%",re.appendChild(u).appendChild(l);var e=C.getComputedStyle(l);n="1%"!==e.top,s=12===t(e.marginLeft),l.style.right="60%",o=36===t(e.right),r=36===t(e.width),l.style.position="absolute",i=12===t(l.offsetWidth/3),re.removeChild(u),l=null}}function t(e){return Math.round(parseFloat(e))}var n,r,i,o,a,s,u=S.createElement("div"),l=S.createElement("div");l.style&&(l.style.backgroundClip="content-box",l.cloneNode(!0).style.backgroundClip="",v.clearCloneStyle="content-box"===l.style.backgroundClip,E.extend(v,{boxSizingReliable:function(){return e(),r},pixelBoxStyles:function(){return e(),o},pixelPosition:function(){return e(),n},reliableMarginLeft:function(){return e(),s},scrollboxSize:function(){return e(),i},reliableTrDimensions:function(){var e,t,n,r;return null==a&&(e=S.createElement("table"),t=S.createElement("tr"),n=S.createElement("div"),e.style.cssText="position:absolute;left:-11111px;border-collapse:separate",t.style.cssText="border:1px solid",t.style.height="1px",n.style.height="9px",n.style.display="block",re.appendChild(e).appendChild(t).appendChild(n),r=C.getComputedStyle(t),a=parseInt(r.height,10)+parseInt(r.borderTopWidth,10)+parseInt(r.borderBottomWidth,10)===t.offsetHeight,re.removeChild(e)),a}}))}();var ze=["Webkit","Moz","ms"],Ue=S.createElement("div").style,Xe={};function Ve(e){var t=E.cssProps[e]||Xe[e];return t||(e in Ue?e:Xe[e]=function(e){var t=e[0].toUpperCase()+e.slice(1),n=ze.length;while(n--)if((e=ze[n]+t)in Ue)return e}(e)||e)}var Ge=/^(none|table(?!-c[ea]).+)/,Ye={position:"absolute",visibility:"hidden",display:"block"},Qe={letterSpacing:"0",fontWeight:"400"};function Je(e,t,n){var r=te.exec(t);return r?Math.max(0,r[2]-(n||0))+(r[3]||"px"):t}function Ke(e,t,n,r,i,o){var a="width"===t?1:0,s=0,u=0;if(n===(r?"border":"content"))return 0;for(;a<4;a+=2)"margin"===n&&(u+=E.css(e,n+ne[a],!0,i)),r?("content"===n&&(u-=E.css(e,"padding"+ne[a],!0,i)),"margin"!==n&&(u-=E.css(e,"border"+ne[a]+"Width",!0,i))):(u+=E.css(e,"padding"+ne[a],!0,i),"padding"!==n?u+=E.css(e,"border"+ne[a]+"Width",!0,i):s+=E.css(e,"border"+ne[a]+"Width",!0,i));return!r&&0<=o&&(u+=Math.max(0,Math.ceil(e["offset"+t[0].toUpperCase()+t.slice(1)]-o-u-s-.5))||0),u}function Ze(e,t,n){var r=Me(e),i=(!v.boxSizingReliable()||n)&&"border-box"===E.css(e,"boxSizing",!1,r),o=i,a=Be(e,t,r),s="offset"+t[0].toUpperCase()+t.slice(1);if(Pe.test(a)){if(!n)return a;a="auto"}return(!v.boxSizingReliable()&&i||!v.reliableTrDimensions()&&A(e,"tr")||"auto"===a||!parseFloat(a)&&"inline"===E.css(e,"display",!1,r))&&e.getClientRects().length&&(i="border-box"===E.css(e,"boxSizing",!1,r),(o=s in e)&&(a=e[s])),(a=parseFloat(a)||0)+Ke(e,t,n||(i?"border":"content"),o,r,a)+"px"}function et(e,t,n,r,i){return new et.prototype.init(e,t,n,r,i)}E.extend({cssHooks:{opacity:{get:function(e,t){if(t){var n=Be(e,"opacity");return""===n?"1":n}}}},cssNumber:{animationIterationCount:!0,columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,gridArea:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnStart:!0,gridRow:!0,gridRowEnd:!0,gridRowStart:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{},style:function(e,t,n,r){if(e&&3!==e.nodeType&&8!==e.nodeType&&e.style){var i,o,a,s=X(t),u=Re.test(t),l=e.style;if(u||(t=Ve(s)),a=E.cssHooks[t]||E.cssHooks[s],void 0===n)return a&&"get"in a&&void 0!==(i=a.get(e,!1,r))?i:l[t];"string"===(o=typeof n)&&(i=te.exec(n))&&i[1]&&(n=se(e,t,i),o="number"),null!=n&&n==n&&("number"!==o||u||(n+=i&&i[3]||(E.cssNumber[s]?"":"px")),v.clearCloneStyle||""!==n||0!==t.indexOf("background")||(l[t]="inherit"),a&&"set"in a&&void 0===(n=a.set(e,n,r))||(u?l.setProperty(t,n):l[t]=n))}},css:function(e,t,n,r){var i,o,a,s=X(t);return Re.test(t)||(t=Ve(s)),(a=E.cssHooks[t]||E.cssHooks[s])&&"get"in a&&(i=a.get(e,!0,n)),void 0===i&&(i=Be(e,t,r)),"normal"===i&&t in Qe&&(i=Qe[t]),""===n||n?(o=parseFloat(i),!0===n||isFinite(o)?o||0:i):i}}),E.each(["height","width"],function(e,u){E.cssHooks[u]={get:function(e,t,n){if(t)return!Ge.test(E.css(e,"display"))||e.getClientRects().length&&e.getBoundingClientRect().width?Ze(e,u,n):Ie(e,Ye,function(){return Ze(e,u,n)})},set:function(e,t,n){var r,i=Me(e),o=!v.scrollboxSize()&&"absolute"===i.position,a=(o||n)&&"border-box"===E.css(e,"boxSizing",!1,i),s=n?Ke(e,u,n,a,i):0;return a&&o&&(s-=Math.ceil(e["offset"+u[0].toUpperCase()+u.slice(1)]-parseFloat(i[u])-Ke(e,u,"border",!1,i)-.5)),s&&(r=te.exec(t))&&"px"!==(r[3]||"px")&&(e.style[u]=t,t=E.css(e,u)),Je(0,t,s)}}}),E.cssHooks.marginLeft=_e(v.reliableMarginLeft,function(e,t){if(t)return(parseFloat(Be(e,"marginLeft"))||e.getBoundingClientRect().left-Ie(e,{marginLeft:0},function(){return e.getBoundingClientRect().left}))+"px"}),E.each({margin:"",padding:"",border:"Width"},function(i,o){E.cssHooks[i+o]={expand:function(e){for(var t=0,n={},r="string"==typeof e?e.split(" "):[e];t<4;t++)n[i+ne[t]+o]=r[t]||r[t-2]||r[0];return n}},"margin"!==i&&(E.cssHooks[i+o].set=Je)}),E.fn.extend({css:function(e,t){return B(this,function(e,t,n){var r,i,o={},a=0;if(Array.isArray(t)){for(r=Me(e),i=t.length;a<i;a++)o[t[a]]=E.css(e,t[a],!1,r);return o}return void 0!==n?E.style(e,t,n):E.css(e,t)},e,t,1<arguments.length)}}),((E.Tween=et).prototype={constructor:et,init:function(e,t,n,r,i,o){this.elem=e,this.prop=n,this.easing=i||E.easing._default,this.options=t,this.start=this.now=this.cur(),this.end=r,this.unit=o||(E.cssNumber[n]?"":"px")},cur:function(){var e=et.propHooks[this.prop];return e&&e.get?e.get(this):et.propHooks._default.get(this)},run:function(e){var t,n=et.propHooks[this.prop];return this.options.duration?this.pos=t=E.easing[this.easing](e,this.options.duration*e,0,1,this.options.duration):this.pos=t=e,this.now=(this.end-this.start)*t+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),n&&n.set?n.set(this):et.propHooks._default.set(this),this}}).init.prototype=et.prototype,(et.propHooks={_default:{get:function(e){var t;return 1!==e.elem.nodeType||null!=e.elem[e.prop]&&null==e.elem.style[e.prop]?e.elem[e.prop]:(t=E.css(e.elem,e.prop,""))&&"auto"!==t?t:0},set:function(e){E.fx.step[e.prop]?E.fx.step[e.prop](e):1!==e.elem.nodeType||!E.cssHooks[e.prop]&&null==e.elem.style[Ve(e.prop)]?e.elem[e.prop]=e.now:E.style(e.elem,e.prop,e.now+e.unit)}}}).scrollTop=et.propHooks.scrollLeft={set:function(e){e.elem.nodeType&&e.elem.parentNode&&(e.elem[e.prop]=e.now)}},E.easing={linear:function(e){return e},swing:function(e){return.5-Math.cos(e*Math.PI)/2},_default:"swing"},E.fx=et.prototype.init,E.fx.step={};var tt,nt,rt,it,ot=/^(?:toggle|show|hide)$/,at=/queueHooks$/;function st(){nt&&(!1===S.hidden&&C.requestAnimationFrame?C.requestAnimationFrame(st):C.setTimeout(st,E.fx.interval),E.fx.tick())}function ut(){return C.setTimeout(function(){tt=void 0}),tt=Date.now()}function lt(e,t){var n,r=0,i={height:e};for(t=t?1:0;r<4;r+=2-t)i["margin"+(n=ne[r])]=i["padding"+n]=e;return t&&(i.opacity=i.width=e),i}function ct(e,t,n){for(var r,i=(ft.tweeners[t]||[]).concat(ft.tweeners["*"]),o=0,a=i.length;o<a;o++)if(r=i[o].call(n,t,e))return r}function ft(o,e,t){var n,a,r=0,i=ft.prefilters.length,s=E.Deferred().always(function(){delete u.elem}),u=function(){if(a)return!1;for(var e=tt||ut(),t=Math.max(0,l.startTime+l.duration-e),n=1-(t/l.duration||0),r=0,i=l.tweens.length;r<i;r++)l.tweens[r].run(n);return s.notifyWith(o,[l,n,t]),n<1&&i?t:(i||s.notifyWith(o,[l,1,0]),s.resolveWith(o,[l]),!1)},l=s.promise({elem:o,props:E.extend({},e),opts:E.extend(!0,{specialEasing:{},easing:E.easing._default},t),originalProperties:e,originalOptions:t,startTime:tt||ut(),duration:t.duration,tweens:[],createTween:function(e,t){var n=E.Tween(o,l.opts,e,t,l.opts.specialEasing[e]||l.opts.easing);return l.tweens.push(n),n},stop:function(e){var t=0,n=e?l.tweens.length:0;if(a)return this;for(a=!0;t<n;t++)l.tweens[t].run(1);return e?(s.notifyWith(o,[l,1,0]),s.resolveWith(o,[l,e])):s.rejectWith(o,[l,e]),this}}),c=l.props;for(!function(e,t){var n,r,i,o,a;for(n in e)if(i=t[r=X(n)],o=e[n],Array.isArray(o)&&(i=o[1],o=e[n]=o[0]),n!==r&&(e[r]=o,delete e[n]),(a=E.cssHooks[r])&&"expand"in a)for(n in o=a.expand(o),delete e[r],o)n in e||(e[n]=o[n],t[n]=i);else t[r]=i}(c,l.opts.specialEasing);r<i;r++)if(n=ft.prefilters[r].call(l,o,c,l.opts))return m(n.stop)&&(E._queueHooks(l.elem,l.opts.queue).stop=n.stop.bind(n)),n;return E.map(c,ct,l),m(l.opts.start)&&l.opts.start.call(o,l),l.progress(l.opts.progress).done(l.opts.done,l.opts.complete).fail(l.opts.fail).always(l.opts.always),E.fx.timer(E.extend(u,{elem:o,anim:l,queue:l.opts.queue})),l}E.Animation=E.extend(ft,{tweeners:{"*":[function(e,t){var n=this.createTween(e,t);return se(n.elem,e,te.exec(t),n),n}]},tweener:function(e,t){m(e)?(t=e,e=["*"]):e=e.match(P);for(var n,r=0,i=e.length;r<i;r++)n=e[r],ft.tweeners[n]=ft.tweeners[n]||[],ft.tweeners[n].unshift(t)},prefilters:[function(e,t,n){var r,i,o,a,s,u,l,c,f="width"in t||"height"in t,p=this,d={},h=e.style,g=e.nodeType&&ae(e),y=Y.get(e,"fxshow");for(r in n.queue||(null==(a=E._queueHooks(e,"fx")).unqueued&&(a.unqueued=0,s=a.empty.fire,a.empty.fire=function(){a.unqueued||s()}),a.unqueued++,p.always(function(){p.always(function(){a.unqueued--,E.queue(e,"fx").length||a.empty.fire()})})),t)if(i=t[r],ot.test(i)){if(delete t[r],o=o||"toggle"===i,i===(g?"hide":"show")){if("show"!==i||!y||void 0===y[r])continue;g=!0}d[r]=y&&y[r]||E.style(e,r)}if((u=!E.isEmptyObject(t))||!E.isEmptyObject(d))for(r in f&&1===e.nodeType&&(n.overflow=[h.overflow,h.overflowX,h.overflowY],null==(l=y&&y.display)&&(l=Y.get(e,"display")),"none"===(c=E.css(e,"display"))&&(l?c=l:(le([e],!0),l=e.style.display||l,c=E.css(e,"display"),le([e]))),("inline"===c||"inline-block"===c&&null!=l)&&"none"===E.css(e,"float")&&(u||(p.done(function(){h.display=l}),null==l&&(c=h.display,l="none"===c?"":c)),h.display="inline-block")),n.overflow&&(h.overflow="hidden",p.always(function(){h.overflow=n.overflow[0],h.overflowX=n.overflow[1],h.overflowY=n.overflow[2]})),u=!1,d)u||(y?"hidden"in y&&(g=y.hidden):y=Y.access(e,"fxshow",{display:l}),o&&(y.hidden=!g),g&&le([e],!0),p.done(function(){for(r in g||le([e]),Y.remove(e,"fxshow"),d)E.style(e,r,d[r])})),u=ct(g?y[r]:0,r,p),r in y||(y[r]=u.start,g&&(u.end=u.start,u.start=0))}],prefilter:function(e,t){t?ft.prefilters.unshift(e):ft.prefilters.push(e)}}),E.speed=function(e,t,n){var r=e&&"object"==typeof e?E.extend({},e):{complete:n||!n&&t||m(e)&&e,duration:e,easing:n&&t||t&&!m(t)&&t};return E.fx.off?r.duration=0:"number"!=typeof r.duration&&(r.duration in E.fx.speeds?r.duration=E.fx.speeds[r.duration]:r.duration=E.fx.speeds._default),null!=r.queue&&!0!==r.queue||(r.queue="fx"),r.old=r.complete,r.complete=function(){m(r.old)&&r.old.call(this),r.queue&&E.dequeue(this,r.queue)},r},E.fn.extend({fadeTo:function(e,t,n,r){return this.filter(ae).css("opacity",0).show().end().animate({opacity:t},e,n,r)},animate:function(t,e,n,r){var i=E.isEmptyObject(t),o=E.speed(e,n,r),a=function(){var e=ft(this,E.extend({},t),o);(i||Y.get(this,"finish"))&&e.stop(!0)};return a.finish=a,i||!1===o.queue?this.each(a):this.queue(o.queue,a)},stop:function(i,e,o){var a=function(e){var t=e.stop;delete e.stop,t(o)};return"string"!=typeof i&&(o=e,e=i,i=void 0),e&&this.queue(i||"fx",[]),this.each(function(){var e=!0,t=null!=i&&i+"queueHooks",n=E.timers,r=Y.get(this);if(t)r[t]&&r[t].stop&&a(r[t]);else for(t in r)r[t]&&r[t].stop&&at.test(t)&&a(r[t]);for(t=n.length;t--;)n[t].elem!==this||null!=i&&n[t].queue!==i||(n[t].anim.stop(o),e=!1,n.splice(t,1));!e&&o||E.dequeue(this,i)})},finish:function(a){return!1!==a&&(a=a||"fx"),this.each(function(){var e,t=Y.get(this),n=t[a+"queue"],r=t[a+"queueHooks"],i=E.timers,o=n?n.length:0;for(t.finish=!0,E.queue(this,a,[]),r&&r.stop&&r.stop.call(this,!0),e=i.length;e--;)i[e].elem===this&&i[e].queue===a&&(i[e].anim.stop(!0),i.splice(e,1));for(e=0;e<o;e++)n[e]&&n[e].finish&&n[e].finish.call(this);delete t.finish})}}),E.each(["toggle","show","hide"],function(e,r){var i=E.fn[r];E.fn[r]=function(e,t,n){return null==e||"boolean"==typeof e?i.apply(this,arguments):this.animate(lt(r,!0),e,t,n)}}),E.each({slideDown:lt("show"),slideUp:lt("hide"),slideToggle:lt("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(e,r){E.fn[e]=function(e,t,n){return this.animate(r,e,t,n)}}),E.timers=[],E.fx.tick=function(){var e,t=0,n=E.timers;for(tt=Date.now();t<n.length;t++)(e=n[t])()||n[t]!==e||n.splice(t--,1);n.length||E.fx.stop(),tt=void 0},E.fx.timer=function(e){E.timers.push(e),E.fx.start()},E.fx.interval=13,E.fx.start=function(){nt||(nt=!0,st())},E.fx.stop=function(){nt=null},E.fx.speeds={slow:600,fast:200,_default:400},E.fn.delay=function(r,e){return r=E.fx&&E.fx.speeds[r]||r,e=e||"fx",this.queue(e,function(e,t){var n=C.setTimeout(e,r);t.stop=function(){C.clearTimeout(n)}})},rt=S.createElement("input"),it=S.createElement("select").appendChild(S.createElement("option")),rt.type="checkbox",v.checkOn=""!==rt.value,v.optSelected=it.selected,(rt=S.createElement("input")).value="t",rt.type="radio",v.radioValue="t"===rt.value;var pt,dt=E.expr.attrHandle;E.fn.extend({attr:function(e,t){return B(this,E.attr,e,t,1<arguments.length)},removeAttr:function(e){return this.each(function(){E.removeAttr(this,e)})}}),E.extend({attr:function(e,t,n){var r,i,o=e.nodeType;if(3!==o&&8!==o&&2!==o)return"undefined"==typeof e.getAttribute?E.prop(e,t,n):(1===o&&E.isXMLDoc(e)||(i=E.attrHooks[t.toLowerCase()]||(E.expr.match.bool.test(t)?pt:void 0)),void 0!==n?null===n?void E.removeAttr(e,t):i&&"set"in i&&void 0!==(r=i.set(e,n,t))?r:(e.setAttribute(t,n+""),n):i&&"get"in i&&null!==(r=i.get(e,t))?r:null==(r=E.find.attr(e,t))?void 0:r)},attrHooks:{type:{set:function(e,t){if(!v.radioValue&&"radio"===t&&A(e,"input")){var n=e.value;return e.setAttribute("type",t),n&&(e.value=n),t}}}},removeAttr:function(e,t){var n,r=0,i=t&&t.match(P);if(i&&1===e.nodeType)while(n=i[r++])e.removeAttribute(n)}}),pt={set:function(e,t,n){return!1===t?E.removeAttr(e,n):e.setAttribute(n,n),n}},E.each(E.expr.match.bool.source.match(/\w+/g),function(e,t){var a=dt[t]||E.find.attr;dt[t]=function(e,t,n){var r,i,o=t.toLowerCase();return n||(i=dt[o],dt[o]=r,r=null!=a(e,t,n)?o:null,dt[o]=i),r}});var ht=/^(?:input|select|textarea|button)$/i,gt=/^(?:a|area)$/i;function yt(e){return(e.match(P)||[]).join(" ")}function vt(e){return e.getAttribute&&e.getAttribute("class")||""}function mt(e){return Array.isArray(e)?e:"string"==typeof e&&e.match(P)||[]}E.fn.extend({prop:function(e,t){return B(this,E.prop,e,t,1<arguments.length)},removeProp:function(e){return this.each(function(){delete this[E.propFix[e]||e]})}}),E.extend({prop:function(e,t,n){var r,i,o=e.nodeType;if(3!==o&&8!==o&&2!==o)return 1===o&&E.isXMLDoc(e)||(t=E.propFix[t]||t,i=E.propHooks[t]),void 0!==n?i&&"set"in i&&void 0!==(r=i.set(e,n,t))?r:e[t]=n:i&&"get"in i&&null!==(r=i.get(e,t))?r:e[t]},propHooks:{tabIndex:{get:function(e){var t=E.find.attr(e,"tabindex");return t?parseInt(t,10):ht.test(e.nodeName)||gt.test(e.nodeName)&&e.href?0:-1}}},propFix:{"for":"htmlFor","class":"className"}}),v.optSelected||(E.propHooks.selected={get:function(e){var t=e.parentNode;return t&&t.parentNode&&t.parentNode.selectedIndex,null},set:function(e){var t=e.parentNode;t&&(t.selectedIndex,t.parentNode&&t.parentNode.selectedIndex)}}),E.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){E.propFix[this.toLowerCase()]=this}),E.fn.extend({addClass:function(t){var e,n,r,i,o,a;return m(t)?this.each(function(e){E(this).addClass(t.call(this,e,vt(this)))}):(e=mt(t)).length?this.each(function(){if(r=vt(this),n=1===this.nodeType&&" "+yt(r)+" "){for(o=0;o<e.length;o++)i=e[o],n.indexOf(" "+i+" ")<0&&(n+=i+" ");a=yt(n),r!==a&&this.setAttribute("class",a)}}):this},removeClass:function(t){var e,n,r,i,o,a;return m(t)?this.each(function(e){E(this).removeClass(t.call(this,e,vt(this)))}):arguments.length?(e=mt(t)).length?this.each(function(){if(r=vt(this),n=1===this.nodeType&&" "+yt(r)+" "){for(o=0;o<e.length;o++){i=e[o];while(-1<n.indexOf(" "+i+" "))n=n.replace(" "+i+" "," ")}a=yt(n),r!==a&&this.setAttribute("class",a)}}):this:this.attr("class","")},toggleClass:function(t,n){var e,r,i,o,a=typeof t,s="string"===a||Array.isArray(t);return m(t)?this.each(function(e){E(this).toggleClass(t.call(this,e,vt(this),n),n)}):"boolean"==typeof n&&s?n?this.addClass(t):this.removeClass(t):(e=mt(t),this.each(function(){if(s)for(o=E(this),i=0;i<e.length;i++)r=e[i],o.hasClass(r)?o.removeClass(r):o.addClass(r);else void 0!==t&&"boolean"!==a||((r=vt(this))&&Y.set(this,"__className__",r),this.setAttribute&&this.setAttribute("class",r||!1===t?"":Y.get(this,"__className__")||""))}))},hasClass:function(e){var t,n,r=0;t=" "+e+" ";while(n=this[r++])if(1===n.nodeType&&-1<(" "+yt(vt(n))+" ").indexOf(t))return!0;return!1}});var xt=/\r/g;E.fn.extend({val:function(n){var r,e,i,t=this[0];return arguments.length?(i=m(n),this.each(function(e){var t;1===this.nodeType&&(null==(t=i?n.call(this,e,E(this).val()):n)?t="":"number"==typeof t?t+="":Array.isArray(t)&&(t=E.map(t,function(e){return null==e?"":e+""})),(r=E.valHooks[this.type]||E.valHooks[this.nodeName.toLowerCase()])&&"set"in r&&void 0!==r.set(this,t,"value")||(this.value=t))})):t?(r=E.valHooks[t.type]||E.valHooks[t.nodeName.toLowerCase()])&&"get"in r&&void 0!==(e=r.get(t,"value"))?e:"string"==typeof(e=t.value)?e.replace(xt,""):null==e?"":e:void 0}}),E.extend({valHooks:{option:{get:function(e){var t=E.find.attr(e,"value");return null!=t?t:yt(E.text(e))}},select:{get:function(e){var t,n,r,i=e.options,o=e.selectedIndex,a="select-one"===e.type,s=a?null:[],u=a?o+1:i.length;for(r=o<0?u:a?o:0;r<u;r++)if(((n=i[r]).selected||r===o)&&!n.disabled&&(!n.parentNode.disabled||!A(n.parentNode,"optgroup"))){if(t=E(n).val(),a)return t;s.push(t)}return s},set:function(e,t){var n,r,i=e.options,o=E.makeArray(t),a=i.length;while(a--)((r=i[a]).selected=-1<E.inArray(E.valHooks.option.get(r),o))&&(n=!0);return n||(e.selectedIndex=-1),o}}}}),E.each(["radio","checkbox"],function(){E.valHooks[this]={set:function(e,t){if(Array.isArray(t))return e.checked=-1<E.inArray(E(e).val(),t)}},v.checkOn||(E.valHooks[this].get=function(e){return null===e.getAttribute("value")?"on":e.value})}),v.focusin="onfocusin"in C;var bt=/^(?:focusinfocus|focusoutblur)$/,wt=function(e){e.stopPropagation()};E.extend(E.event,{trigger:function(e,t,n,r){var i,o,a,s,u,l,c,f,p=[n||S],d=y.call(e,"type")?e.type:e,h=y.call(e,"namespace")?e.namespace.split("."):[];if(o=f=a=n=n||S,3!==n.nodeType&&8!==n.nodeType&&!bt.test(d+E.event.triggered)&&(-1<d.indexOf(".")&&(d=(h=d.split(".")).shift(),h.sort()),u=d.indexOf(":")<0&&"on"+d,(e=e[E.expando]?e:new E.Event(d,"object"==typeof e&&e)).isTrigger=r?2:3,e.namespace=h.join("."),e.rnamespace=e.namespace?new RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,e.result=void 0,e.target||(e.target=n),t=null==t?[e]:E.makeArray(t,[e]),c=E.event.special[d]||{},r||!c.trigger||!1!==c.trigger.apply(n,t))){if(!r&&!c.noBubble&&!x(n)){for(s=c.delegateType||d,bt.test(s+d)||(o=o.parentNode);o;o=o.parentNode)p.push(o),a=o;a===(n.ownerDocument||S)&&p.push(a.defaultView||a.parentWindow||C)}i=0;while((o=p[i++])&&!e.isPropagationStopped())f=o,e.type=1<i?s:c.bindType||d,(l=(Y.get(o,"events")||Object.create(null))[e.type]&&Y.get(o,"handle"))&&l.apply(o,t),(l=u&&o[u])&&l.apply&&V(o)&&(e.result=l.apply(o,t),!1===e.result&&e.preventDefault());return e.type=d,r||e.isDefaultPrevented()||c._default&&!1!==c._default.apply(p.pop(),t)||!V(n)||u&&m(n[d])&&!x(n)&&((a=n[u])&&(n[u]=null),E.event.triggered=d,e.isPropagationStopped()&&f.addEventListener(d,wt),n[d](),e.isPropagationStopped()&&f.removeEventListener(d,wt),E.event.triggered=void 0,a&&(n[u]=a)),e.result}},simulate:function(e,t,n){var r=E.extend(new E.Event,n,{type:e,isSimulated:!0});E.event.trigger(r,null,t)}}),E.fn.extend({trigger:function(e,t){return this.each(function(){E.event.trigger(e,t,this)})},triggerHandler:function(e,t){var n=this[0];if(n)return E.event.trigger(e,t,n,!0)}}),v.focusin||E.each({focus:"focusin",blur:"focusout"},function(n,r){var i=function(e){E.event.simulate(r,e.target,E.event.fix(e))};E.event.special[r]={setup:function(){var e=this.ownerDocument||this.document||this,t=Y.access(e,r);t||e.addEventListener(n,i,!0),Y.access(e,r,(t||0)+1)},teardown:function(){var e=this.ownerDocument||this.document||this,t=Y.access(e,r)-1;t?Y.access(e,r,t):(e.removeEventListener(n,i,!0),Y.remove(e,r))}}});var Tt=C.location,Ct={guid:Date.now()},St=/\?/;E.parseXML=function(e){var t,n;if(!e||"string"!=typeof e)return null;try{t=(new C.DOMParser).parseFromString(e,"text/xml")}catch(e){}return n=t&&t.getElementsByTagName("parsererror")[0],t&&!n||E.error("Invalid XML: "+(n?E.map(n.childNodes,function(e){return e.textContent}).join("\n"):e)),t};var Et=/\[\]$/,kt=/\r?\n/g,At=/^(?:submit|button|image|reset|file)$/i,Nt=/^(?:input|select|textarea|keygen)/i;function jt(n,e,r,i){var t;if(Array.isArray(e))E.each(e,function(e,t){r||Et.test(n)?i(n,t):jt(n+"["+("object"==typeof t&&null!=t?e:"")+"]",t,r,i)});else if(r||"object"!==w(e))i(n,e);else for(t in e)jt(n+"["+t+"]",e[t],r,i)}E.param=function(e,t){var n,r=[],i=function(e,t){var n=m(t)?t():t;r[r.length]=encodeURIComponent(e)+"="+encodeURIComponent(null==n?"":n)};if(null==e)return"";if(Array.isArray(e)||e.jquery&&!E.isPlainObject(e))E.each(e,function(){i(this.name,this.value)});else for(n in e)jt(n,e[n],t,i);return r.join("&")},E.fn.extend({serialize:function(){return E.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var e=E.prop(this,"elements");return e?E.makeArray(e):this}).filter(function(){var e=this.type;return this.name&&!E(this).is(":disabled")&&Nt.test(this.nodeName)&&!At.test(e)&&(this.checked||!pe.test(e))}).map(function(e,t){var n=E(this).val();return null==n?null:Array.isArray(n)?E.map(n,function(e){return{name:t.name,value:e.replace(kt,"\r\n")}}):{name:t.name,value:n.replace(kt,"\r\n")}}).get()}});var Dt=/%20/g,qt=/#.*$/,Lt=/([?&])_=[^&]*/,Ht=/^(.*?):[ \t]*([^\r\n]*)$/gm,Ot=/^(?:GET|HEAD)$/,Pt=/^\/\//,Rt={},Mt={},It="*/".concat("*"),Wt=S.createElement("a");function Ft(o){return function(e,t){"string"!=typeof e&&(t=e,e="*");var n,r=0,i=e.toLowerCase().match(P)||[];if(m(t))while(n=i[r++])"+"===n[0]?(n=n.slice(1)||"*",(o[n]=o[n]||[]).unshift(t)):(o[n]=o[n]||[]).push(t)}}function $t(t,i,o,a){var s={},u=t===Mt;function l(e){var r;return s[e]=!0,E.each(t[e]||[],function(e,t){var n=t(i,o,a);return"string"!=typeof n||u||s[n]?u?!(r=n):void 0:(i.dataTypes.unshift(n),l(n),!1)}),r}return l(i.dataTypes[0])||!s["*"]&&l("*")}function Bt(e,t){var n,r,i=E.ajaxSettings.flatOptions||{};for(n in t)void 0!==t[n]&&((i[n]?e:r||(r={}))[n]=t[n]);return r&&E.extend(!0,e,r),e}Wt.href=Tt.href,E.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:Tt.href,type:"GET",isLocal:/^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Tt.protocol),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":It,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/\bxml\b/,html:/\bhtml/,json:/\bjson\b/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":JSON.parse,"text xml":E.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(e,t){return t?Bt(Bt(e,E.ajaxSettings),t):Bt(E.ajaxSettings,e)},ajaxPrefilter:Ft(Rt),ajaxTransport:Ft(Mt),ajax:function(e,t){"object"==typeof e&&(t=e,e=void 0),t=t||{};var c,f,p,n,d,r,h,g,i,o,y=E.ajaxSetup({},t),v=y.context||y,m=y.context&&(v.nodeType||v.jquery)?E(v):E.event,x=E.Deferred(),b=E.Callbacks("once memory"),w=y.statusCode||{},a={},s={},u="canceled",T={readyState:0,getResponseHeader:function(e){var t;if(h){if(!n){n={};while(t=Ht.exec(p))n[t[1].toLowerCase()+" "]=(n[t[1].toLowerCase()+" "]||[]).concat(t[2])}t=n[e.toLowerCase()+" "]}return null==t?null:t.join(", ")},getAllResponseHeaders:function(){return h?p:null},setRequestHeader:function(e,t){return null==h&&(e=s[e.toLowerCase()]=s[e.toLowerCase()]||e,a[e]=t),this},overrideMimeType:function(e){return null==h&&(y.mimeType=e),this},statusCode:function(e){var t;if(e)if(h)T.always(e[T.status]);else for(t in e)w[t]=[w[t],e[t]];return this},abort:function(e){var t=e||u;return c&&c.abort(t),l(0,t),this}};if(x.promise(T),y.url=((e||y.url||Tt.href)+"").replace(Pt,Tt.protocol+"//"),y.type=t.method||t.type||y.method||y.type,y.dataTypes=(y.dataType||"*").toLowerCase().match(P)||[""],null==y.crossDomain){r=S.createElement("a");try{r.href=y.url,r.href=r.href,y.crossDomain=Wt.protocol+"//"+Wt.host!=r.protocol+"//"+r.host}catch(e){y.crossDomain=!0}}if(y.data&&y.processData&&"string"!=typeof y.data&&(y.data=E.param(y.data,y.traditional)),$t(Rt,y,t,T),h)return T;for(i in(g=E.event&&y.global)&&0==E.active++&&E.event.trigger("ajaxStart"),y.type=y.type.toUpperCase(),y.hasContent=!Ot.test(y.type),f=y.url.replace(qt,""),y.hasContent?y.data&&y.processData&&0===(y.contentType||"").indexOf("application/x-www-form-urlencoded")&&(y.data=y.data.replace(Dt,"+")):(o=y.url.slice(f.length),y.data&&(y.processData||"string"==typeof y.data)&&(f+=(St.test(f)?"&":"?")+y.data,delete y.data),!1===y.cache&&(f=f.replace(Lt,"$1"),o=(St.test(f)?"&":"?")+"_="+Ct.guid+++o),y.url=f+o),y.ifModified&&(E.lastModified[f]&&T.setRequestHeader("If-Modified-Since",E.lastModified[f]),E.etag[f]&&T.setRequestHeader("If-None-Match",E.etag[f])),(y.data&&y.hasContent&&!1!==y.contentType||t.contentType)&&T.setRequestHeader("Content-Type",y.contentType),T.setRequestHeader("Accept",y.dataTypes[0]&&y.accepts[y.dataTypes[0]]?y.accepts[y.dataTypes[0]]+("*"!==y.dataTypes[0]?", "+It+"; q=0.01":""):y.accepts["*"]),y.headers)T.setRequestHeader(i,y.headers[i]);if(y.beforeSend&&(!1===y.beforeSend.call(v,T,y)||h))return T.abort();if(u="abort",b.add(y.complete),T.done(y.success),T.fail(y.error),c=$t(Mt,y,t,T)){if(T.readyState=1,g&&m.trigger("ajaxSend",[T,y]),h)return T;y.async&&0<y.timeout&&(d=C.setTimeout(function(){T.abort("timeout")},y.timeout));try{h=!1,c.send(a,l)}catch(e){if(h)throw e;l(-1,e)}}else l(-1,"No Transport");function l(e,t,n,r){var i,o,a,s,u,l=t;h||(h=!0,d&&C.clearTimeout(d),c=void 0,p=r||"",T.readyState=0<e?4:0,i=200<=e&&e<300||304===e,n&&(s=function(e,t,n){var r,i,o,a,s=e.contents,u=e.dataTypes;while("*"===u[0])u.shift(),void 0===r&&(r=e.mimeType||t.getResponseHeader("Content-Type"));if(r)for(i in s)if(s[i]&&s[i].test(r)){u.unshift(i);break}if(u[0]in n)o=u[0];else{for(i in n){if(!u[0]||e.converters[i+" "+u[0]]){o=i;break}a||(a=i)}o=o||a}if(o)return o!==u[0]&&u.unshift(o),n[o]}(y,T,n)),!i&&-1<E.inArray("script",y.dataTypes)&&E.inArray("json",y.dataTypes)<0&&(y.converters["text script"]=function(){}),s=function(e,t,n,r){var i,o,a,s,u,l={},c=e.dataTypes.slice();if(c[1])for(a in e.converters)l[a.toLowerCase()]=e.converters[a];o=c.shift();while(o)if(e.responseFields[o]&&(n[e.responseFields[o]]=t),!u&&r&&e.dataFilter&&(t=e.dataFilter(t,e.dataType)),u=o,o=c.shift())if("*"===o)o=u;else if("*"!==u&&u!==o){if(!(a=l[u+" "+o]||l["* "+o]))for(i in l)if((s=i.split(" "))[1]===o&&(a=l[u+" "+s[0]]||l["* "+s[0]])){!0===a?a=l[i]:!0!==l[i]&&(o=s[0],c.unshift(s[1]));break}if(!0!==a)if(a&&e["throws"])t=a(t);else try{t=a(t)}catch(e){return{state:"parsererror",error:a?e:"No conversion from "+u+" to "+o}}}return{state:"success",data:t}}(y,s,T,i),i?(y.ifModified&&((u=T.getResponseHeader("Last-Modified"))&&(E.lastModified[f]=u),(u=T.getResponseHeader("etag"))&&(E.etag[f]=u)),204===e||"HEAD"===y.type?l="nocontent":304===e?l="notmodified":(l=s.state,o=s.data,i=!(a=s.error))):(a=l,!e&&l||(l="error",e<0&&(e=0))),T.status=e,T.statusText=(t||l)+"",i?x.resolveWith(v,[o,l,T]):x.rejectWith(v,[T,l,a]),T.statusCode(w),w=void 0,g&&m.trigger(i?"ajaxSuccess":"ajaxError",[T,y,i?o:a]),b.fireWith(v,[T,l]),g&&(m.trigger("ajaxComplete",[T,y]),--E.active||E.event.trigger("ajaxStop")))}return T},getJSON:function(e,t,n){return E.get(e,t,n,"json")},getScript:function(e,t){return E.get(e,void 0,t,"script")}}),E.each(["get","post"],function(e,i){E[i]=function(e,t,n,r){return m(t)&&(r=r||n,n=t,t=void 0),E.ajax(E.extend({url:e,type:i,dataType:r,data:t,success:n},E.isPlainObject(e)&&e))}}),E.ajaxPrefilter(function(e){var t;for(t in e.headers)"content-type"===t.toLowerCase()&&(e.contentType=e.headers[t]||"")}),E._evalUrl=function(e,t,n){return E.ajax({url:e,type:"GET",dataType:"script",cache:!0,async:!1,global:!1,converters:{"text script":function(){}},dataFilter:function(e){E.globalEval(e,t,n)}})},E.fn.extend({wrapAll:function(e){var t;return this[0]&&(m(e)&&(e=e.call(this[0])),t=E(e,this[0].ownerDocument).eq(0).clone(!0),this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){var e=this;while(e.firstElementChild)e=e.firstElementChild;return e}).append(this)),this},wrapInner:function(n){return m(n)?this.each(function(e){E(this).wrapInner(n.call(this,e))}):this.each(function(){var e=E(this),t=e.contents();t.length?t.wrapAll(n):e.append(n)})},wrap:function(t){var n=m(t);return this.each(function(e){E(this).wrapAll(n?t.call(this,e):t)})},unwrap:function(e){return this.parent(e).not("body").each(function(){E(this).replaceWith(this.childNodes)}),this}}),E.expr.pseudos.hidden=function(e){return!E.expr.pseudos.visible(e)},E.expr.pseudos.visible=function(e){return!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)},E.ajaxSettings.xhr=function(){try{return new C.XMLHttpRequest}catch(e){}};var _t={0:200,1223:204},zt=E.ajaxSettings.xhr();v.cors=!!zt&&"withCredentials"in zt,v.ajax=zt=!!zt,E.ajaxTransport(function(i){var o,a;if(v.cors||zt&&!i.crossDomain)return{send:function(e,t){var n,r=i.xhr();if(r.open(i.type,i.url,i.async,i.username,i.password),i.xhrFields)for(n in i.xhrFields)r[n]=i.xhrFields[n];for(n in i.mimeType&&r.overrideMimeType&&r.overrideMimeType(i.mimeType),i.crossDomain||e["X-Requested-With"]||(e["X-Requested-With"]="XMLHttpRequest"),e)r.setRequestHeader(n,e[n]);o=function(e){return function(){o&&(o=a=r.onload=r.onerror=r.onabort=r.ontimeout=r.onreadystatechange=null,"abort"===e?r.abort():"error"===e?"number"!=typeof r.status?t(0,"error"):t(r.status,r.statusText):t(_t[r.status]||r.status,r.statusText,"text"!==(r.responseType||"text")||"string"!=typeof r.responseText?{binary:r.response}:{text:r.responseText},r.getAllResponseHeaders()))}},r.onload=o(),a=r.onerror=r.ontimeout=o("error"),void 0!==r.onabort?r.onabort=a:r.onreadystatechange=function(){4===r.readyState&&C.setTimeout(function(){o&&a()})},o=o("abort");try{r.send(i.hasContent&&i.data||null)}catch(e){if(o)throw e}},abort:function(){o&&o()}}}),E.ajaxPrefilter(function(e){e.crossDomain&&(e.contents.script=!1)}),E.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/\b(?:java|ecma)script\b/},converters:{"text script":function(e){return E.globalEval(e),e}}}),E.ajaxPrefilter("script",function(e){void 0===e.cache&&(e.cache=!1),e.crossDomain&&(e.type="GET")}),E.ajaxTransport("script",function(n){var r,i;if(n.crossDomain||n.scriptAttrs)return{send:function(e,t){r=E("<script>").attr(n.scriptAttrs||{}).prop({charset:n.scriptCharset,src:n.url}).on("load error",i=function(e){r.remove(),i=null,e&&t("error"===e.type?404:200,e.type)}),S.head.appendChild(r[0])},abort:function(){i&&i()}}});var Ut,Xt=[],Vt=/(=)\?(?=&|$)|\?\?/;E.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var e=Xt.pop()||E.expando+"_"+Ct.guid++;return this[e]=!0,e}}),E.ajaxPrefilter("json jsonp",function(e,t,n){var r,i,o,a=!1!==e.jsonp&&(Vt.test(e.url)?"url":"string"==typeof e.data&&0===(e.contentType||"").indexOf("application/x-www-form-urlencoded")&&Vt.test(e.data)&&"data");if(a||"jsonp"===e.dataTypes[0])return r=e.jsonpCallback=m(e.jsonpCallback)?e.jsonpCallback():e.jsonpCallback,a?e[a]=e[a].replace(Vt,"$1"+r):!1!==e.jsonp&&(e.url+=(St.test(e.url)?"&":"?")+e.jsonp+"="+r),e.converters["script json"]=function(){return o||E.error(r+" was not called"),o[0]},e.dataTypes[0]="json",i=C[r],C[r]=function(){o=arguments},n.always(function(){void 0===i?E(C).removeProp(r):C[r]=i,e[r]&&(e.jsonpCallback=t.jsonpCallback,Xt.push(r)),o&&m(i)&&i(o[0]),o=i=void 0}),"script"}),v.createHTMLDocument=((Ut=S.implementation.createHTMLDocument("").body).innerHTML="<form></form><form></form>",2===Ut.childNodes.length),E.parseHTML=function(e,t,n){return"string"!=typeof e?[]:("boolean"==typeof t&&(n=t,t=!1),t||(v.createHTMLDocument?((r=(t=S.implementation.createHTMLDocument("")).createElement("base")).href=S.location.href,t.head.appendChild(r)):t=S),o=!n&&[],(i=N.exec(e))?[t.createElement(i[1])]:(i=xe([e],t,o),o&&o.length&&E(o).remove(),E.merge([],i.childNodes)));var r,i,o},E.fn.load=function(e,t,n){var r,i,o,a=this,s=e.indexOf(" ");return-1<s&&(r=yt(e.slice(s)),e=e.slice(0,s)),m(t)?(n=t,t=void 0):t&&"object"==typeof t&&(i="POST"),0<a.length&&E.ajax({url:e,type:i||"GET",dataType:"html",data:t}).done(function(e){o=arguments,a.html(r?E("<div>").append(E.parseHTML(e)).find(r):e)}).always(n&&function(e,t){a.each(function(){n.apply(this,o||[e.responseText,t,e])})}),this},E.expr.pseudos.animated=function(t){return E.grep(E.timers,function(e){return t===e.elem}).length},E.offset={setOffset:function(e,t,n){var r,i,o,a,s,u,l=E.css(e,"position"),c=E(e),f={};"static"===l&&(e.style.position="relative"),s=c.offset(),o=E.css(e,"top"),u=E.css(e,"left"),("absolute"===l||"fixed"===l)&&-1<(o+u).indexOf("auto")?(a=(r=c.position()).top,i=r.left):(a=parseFloat(o)||0,i=parseFloat(u)||0),m(t)&&(t=t.call(e,n,E.extend({},s))),null!=t.top&&(f.top=t.top-s.top+a),null!=t.left&&(f.left=t.left-s.left+i),"using"in t?t.using.call(e,f):c.css(f)}},E.fn.extend({offset:function(t){if(arguments.length)return void 0===t?this:this.each(function(e){E.offset.setOffset(this,t,e)});var e,n,r=this[0];return r?r.getClientRects().length?(e=r.getBoundingClientRect(),n=r.ownerDocument.defaultView,{top:e.top+n.pageYOffset,left:e.left+n.pageXOffset}):{top:0,left:0}:void 0},position:function(){if(this[0]){var e,t,n,r=this[0],i={top:0,left:0};if("fixed"===E.css(r,"position"))t=r.getBoundingClientRect();else{t=this.offset(),n=r.ownerDocument,e=r.offsetParent||n.documentElement;while(e&&(e===n.body||e===n.documentElement)&&"static"===E.css(e,"position"))e=e.parentNode;e&&e!==r&&1===e.nodeType&&((i=E(e).offset()).top+=E.css(e,"borderTopWidth",!0),i.left+=E.css(e,"borderLeftWidth",!0))}return{top:t.top-i.top-E.css(r,"marginTop",!0),left:t.left-i.left-E.css(r,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){var e=this.offsetParent;while(e&&"static"===E.css(e,"position"))e=e.offsetParent;return e||re})}}),E.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(t,i){var o="pageYOffset"===i;E.fn[t]=function(e){return B(this,function(e,t,n){var r;if(x(e)?r=e:9===e.nodeType&&(r=e.defaultView),void 0===n)return r?r[i]:e[t];r?r.scrollTo(o?r.pageXOffset:n,o?n:r.pageYOffset):e[t]=n},t,e,arguments.length)}}),E.each(["top","left"],function(e,n){E.cssHooks[n]=_e(v.pixelPosition,function(e,t){if(t)return t=Be(e,n),Pe.test(t)?E(e).position()[n]+"px":t})}),E.each({Height:"height",Width:"width"},function(a,s){E.each({padding:"inner"+a,content:s,"":"outer"+a},function(r,o){E.fn[o]=function(e,t){var n=arguments.length&&(r||"boolean"!=typeof e),i=r||(!0===e||!0===t?"margin":"border");return B(this,function(e,t,n){var r;return x(e)?0===o.indexOf("outer")?e["inner"+a]:e.document.documentElement["client"+a]:9===e.nodeType?(r=e.documentElement,Math.max(e.body["scroll"+a],r["scroll"+a],e.body["offset"+a],r["offset"+a],r["client"+a])):void 0===n?E.css(e,t,i):E.style(e,t,n,i)},s,n?e:void 0,n)}})}),E.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(e,t){E.fn[t]=function(e){return this.on(t,e)}}),E.fn.extend({bind:function(e,t,n){return this.on(e,null,t,n)},unbind:function(e,t){return this.off(e,null,t)},delegate:function(e,t,n,r){return this.on(t,e,n,r)},undelegate:function(e,t,n){return 1===arguments.length?this.off(e,"**"):this.off(t,e||"**",n)},hover:function(e,t){return this.mouseenter(e).mouseleave(t||e)}}),E.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "),function(e,n){E.fn[n]=function(e,t){return 0<arguments.length?this.on(n,null,e,t):this.trigger(n)}});var Gt=/^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;E.proxy=function(e,t){var n,r,i;if("string"==typeof t&&(n=e[t],t=e,e=n),m(e))return r=s.call(arguments,2),(i=function(){return e.apply(t||this,r.concat(s.call(arguments)))}).guid=e.guid=e.guid||E.guid++,i},E.holdReady=function(e){e?E.readyWait++:E.ready(!0)},E.isArray=Array.isArray,E.parseJSON=JSON.parse,E.nodeName=A,E.isFunction=m,E.isWindow=x,E.camelCase=X,E.type=w,E.now=Date.now,E.isNumeric=function(e){var t=E.type(e);return("number"===t||"string"===t)&&!isNaN(e-parseFloat(e))},E.trim=function(e){return null==e?"":(e+"").replace(Gt,"$1")},"function"==typeof define&&define.amd&&define("jquery",[],function(){return E});var Yt=C.jQuery,Qt=C.$;return E.noConflict=function(e){return C.$===E&&(C.$=Qt),e&&C.jQuery===E&&(C.jQuery=Yt),E},"undefined"==typeof e&&(C.jQuery=C.$=E),E});
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector;
};
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
if (typeof Object.assign !== 'function') {
  Object.defineProperty(Object, 'assign', {
    value: function assign(target, varArgs) {
      'use strict';

      if (target === null || target === undefined) {
        throw new TypeError('Cannot convert undefined or null to object');
      }
      var to = Object(target);
      for (var index = 1; index < arguments.length; index++) {
        var nextSource = arguments[index];
        if (nextSource !== null && nextSource !== undefined) {
          for (var nextKey in nextSource) {
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }
      return to;
    },
    writable: true,
    configurable: true
  });
};
/*! @drupal/once - v1.0.1 - 2021-06-12 */
var once=function(){"use strict";var n=/[\11\12\14\15\40]+/,e="data-once",t=document;function r(n,t,r){return n[t+"Attribute"](e,r)}function o(e){if("string"!=typeof e)throw new TypeError("once ID must be a string");if(""===e||n.test(e))throw new RangeError("once ID must not be empty or contain spaces");return'[data-once~="'+e+'"]'}function u(n){if(!(n instanceof Element))throw new TypeError("The element must be an instance of Element");return!0}function i(n,e){void 0===e&&(e=t);var r=n;if(null===n)r=[];else{if(!n)throw new TypeError("Selector must not be empty");"string"!=typeof n||e!==t&&!u(e)?n instanceof Element&&(r=[n]):r=e.querySelectorAll(n)}return Array.prototype.slice.call(r)}function c(n,e,t){return e.filter((function(e){var r=u(e)&&e.matches(n);return r&&t&&t(e),r}))}function f(e,t){var o=t.add,u=t.remove,i=[];r(e,"has")&&r(e,"get").trim().split(n).forEach((function(n){i.indexOf(n)<0&&n!==u&&i.push(n)})),o&&i.push(o);var c=i.join(" ");r(e,""===c?"remove":"set",c)}function a(n,e,t){return c(":not("+o(n)+")",i(e,t),(function(e){return f(e,{add:n})}))}return a.remove=function(n,e,t){return c(o(n),i(e,t),(function(e){return f(e,{remove:n})}))},a.filter=function(n,e,t){return c(o(n),i(e,t))},a.find=function(n,e){return i(n?o(n):"[data-once]",e)},a}();

;
/*!
 * jQuery Once v2.2.3 - http://github.com/robloach/jquery-once
 * @license MIT, GPL-2.0
 *   http://opensource.org/licenses/MIT
 *   http://opensource.org/licenses/GPL-2.0
 */
(function(e){"use strict";if(typeof exports==="object"&&typeof exports.nodeName!=="string"){e(require("jquery"))}else if(typeof define==="function"&&define.amd){define(["jquery"],e)}else{e(jQuery)}})(function(t){"use strict";var r=function(e){e=e||"once";if(typeof e!=="string"){throw new TypeError("The jQuery Once id parameter must be a string")}return e};t.fn.once=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)!==true}).data(n,true)};t.fn.removeOnce=function(e){return this.findOnce(e).removeData("jquery-once-"+r(e))};t.fn.findOnce=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)===true})}});

/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
(function () {
  var settingsElement = document.querySelector('head > script[type="application/json"][data-drupal-selector="drupal-settings-json"], body > script[type="application/json"][data-drupal-selector="drupal-settings-json"]');
  window.drupalSettings = {};
  if (settingsElement !== null) {
    window.drupalSettings = JSON.parse(settingsElement.textContent);
  }
})();;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
window.Drupal = {
  behaviors: {},
  locale: {}
};
(function (Drupal, drupalSettings, drupalTranslations, console, Proxy, Reflect) {
  Drupal.throwError = function (error) {
    setTimeout(function () {
      throw error;
    }, 0);
  };
  Drupal.attachBehaviors = function (context, settings) {
    context = context || document;
    settings = settings || drupalSettings;
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].attach === 'function') {
        try {
          behaviors[i].attach(context, settings);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };
  Drupal.detachBehaviors = function (context, settings, trigger) {
    context = context || document;
    settings = settings || drupalSettings;
    trigger = trigger || 'unload';
    var behaviors = Drupal.behaviors;
    Object.keys(behaviors || {}).forEach(function (i) {
      if (typeof behaviors[i].detach === 'function') {
        try {
          behaviors[i].detach(context, settings, trigger);
        } catch (e) {
          Drupal.throwError(e);
        }
      }
    });
  };
  Drupal.checkPlain = function (str) {
    str = str.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    return str;
  };
  Drupal.formatString = function (str, args) {
    var processedArgs = {};
    Object.keys(args || {}).forEach(function (key) {
      switch (key.charAt(0)) {
        case '@':
          processedArgs[key] = Drupal.checkPlain(args[key]);
          break;
        case '!':
          processedArgs[key] = args[key];
          break;
        default:
          processedArgs[key] = Drupal.theme('placeholder', args[key]);
          break;
      }
    });
    return Drupal.stringReplace(str, processedArgs, null);
  };
  Drupal.stringReplace = function (str, args, keys) {
    if (str.length === 0) {
      return str;
    }
    if (!Array.isArray(keys)) {
      keys = Object.keys(args || {});
      keys.sort(function (a, b) {
        return a.length - b.length;
      });
    }
    if (keys.length === 0) {
      return str;
    }
    var key = keys.pop();
    var fragments = str.split(key);
    if (keys.length) {
      for (var i = 0; i < fragments.length; i++) {
        fragments[i] = Drupal.stringReplace(fragments[i], args, keys.slice(0));
      }
    }
    return fragments.join(args[key]);
  };
  Drupal.t = function (str, args, options) {
    options = options || {};
    options.context = options.context || '';
    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.strings && drupalTranslations.strings[options.context] && drupalTranslations.strings[options.context][str]) {
      str = drupalTranslations.strings[options.context][str];
    }
    if (args) {
      str = Drupal.formatString(str, args);
    }
    return str;
  };
  Drupal.url = function (path) {
    return drupalSettings.path.baseUrl + drupalSettings.path.pathPrefix + path;
  };
  Drupal.url.toAbsolute = function (url) {
    var urlParsingNode = document.createElement('a');
    try {
      url = decodeURIComponent(url);
    } catch (e) {}
    urlParsingNode.setAttribute('href', url);
    return urlParsingNode.cloneNode(false).href;
  };
  Drupal.url.isLocal = function (url) {
    var absoluteUrl = Drupal.url.toAbsolute(url);
    var protocol = window.location.protocol;
    if (protocol === 'http:' && absoluteUrl.indexOf('https:') === 0) {
      protocol = 'https:';
    }
    var baseUrl = "".concat(protocol, "//").concat(window.location.host).concat(drupalSettings.path.baseUrl.slice(0, -1));
    try {
      absoluteUrl = decodeURIComponent(absoluteUrl);
    } catch (e) {}
    try {
      baseUrl = decodeURIComponent(baseUrl);
    } catch (e) {}
    return absoluteUrl === baseUrl || absoluteUrl.indexOf("".concat(baseUrl, "/")) === 0;
  };
  Drupal.formatPlural = function (count, singular, plural, args, options) {
    args = args || {};
    args['@count'] = count;
    var pluralDelimiter = drupalSettings.pluralDelimiter;
    var translations = Drupal.t(singular + pluralDelimiter + plural, args, options).split(pluralDelimiter);
    var index = 0;
    if (typeof drupalTranslations !== 'undefined' && drupalTranslations.pluralFormula) {
      index = count in drupalTranslations.pluralFormula ? drupalTranslations.pluralFormula[count] : drupalTranslations.pluralFormula.default;
    } else if (args['@count'] !== 1) {
      index = 1;
    }
    return translations[index];
  };
  Drupal.encodePath = function (item) {
    return window.encodeURIComponent(item).replace(/%2F/g, '/');
  };
  Drupal.deprecationError = function (_ref) {
    var message = _ref.message;
    if (drupalSettings.suppressDeprecationErrors === false && typeof console !== 'undefined' && console.warn) {
      console.warn("[Deprecation] ".concat(message));
    }
  };
  Drupal.deprecatedProperty = function (_ref2) {
    var target = _ref2.target,
      deprecatedProperty = _ref2.deprecatedProperty,
      message = _ref2.message;
    if (!Proxy || !Reflect) {
      return target;
    }
    return new Proxy(target, {
      get: function get(target, key) {
        if (key === deprecatedProperty) {
          Drupal.deprecationError({
            message: message
          });
        }
        for (var _len = arguments.length, rest = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          rest[_key - 2] = arguments[_key];
        }
        return Reflect.get.apply(Reflect, [target, key].concat(rest));
      }
    });
  };
  Drupal.theme = function (func) {
    if (func in Drupal.theme) {
      var _Drupal$theme;
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      return (_Drupal$theme = Drupal.theme)[func].apply(_Drupal$theme, args);
    }
  };
  Drupal.theme.placeholder = function (str) {
    return "<em class=\"placeholder\">".concat(Drupal.checkPlain(str), "</em>");
  };
})(Drupal, window.drupalSettings, window.drupalTranslations, window.console, window.Proxy, window.Reflect);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
if (window.jQuery) {
  jQuery.noConflict();
}
document.documentElement.className += ' js';
(function (Drupal, drupalSettings) {
  var domReady = function domReady(callback) {
    var listener = function listener() {
      callback();
      document.removeEventListener('DOMContentLoaded', listener);
    };
    if (document.readyState !== 'loading') {
      setTimeout(callback, 0);
    } else {
      document.addEventListener('DOMContentLoaded', listener);
    }
  };
  domReady(function () {
    Drupal.attachBehaviors(document, drupalSettings);
  });
})(Drupal, window.drupalSettings);;
/**
 * @file
 * The Lazy-load behavior.
 */

(function (Drupal) {

  'use strict';

  Drupal.behaviors.lazy = {
    attach: function (context, settings) {
      var utils = {
        extend: function (obj, src) {
          Object.keys(src).forEach(function (key) {
            obj[key] = src[key];
          });
          return obj;
        },
        once: function (selector, context) {
          return (context || document).querySelector(selector);
        },
        loadScript: function (url) {
          if (document.querySelectorAll('script[src="' + url + '"]').length == 0) {
            var script = document.createElement('script'),
              scripts = document.getElementsByTagName('script')[0];
            script.src = url;
            script.async = true;
            scripts.parentNode.insertBefore(script, scripts);
          }
        }
      };

      if (utils.once('body', context)) {
        var lazysizes = settings.lazy.lazysizes || {};

        if (!settings.lazy.preferNative) {
          // 1. Lazysizes configuration.
          window.lazySizesConfig = window.lazySizesConfig || {};
          window.lazySizesConfig = utils.extend(window.lazySizesConfig, lazysizes);
          // 2. Load all selected lazysizes plugins.
          if (!Object.entries) {
            Object.entries = function (obj) {
              var ownProps = Object.keys(obj),
                i = ownProps.length,
                resArray = new Array(i);
              while (i--) {
                resArray[i] = [ownProps[i], obj[ownProps[i]]];
              }
              return resArray;
            };
          }
          var min = settings.lazy.minified ? '.min' : '';
          Object.entries(lazysizes.plugins).forEach(function (path) {
            utils.loadScript(settings.lazy.libraryPath + '/plugins/' + path[1] + min + '.js');
          });
          // 3. Load the lazysizes library.
          utils.loadScript(settings.lazy.libraryPath + '/lazysizes' + min + '.js');
        }
      }
    }
  };

})(Drupal);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
(function ($, once) {
  var deprecatedMessageSuffix = "is deprecated in Drupal 9.3.0 and will be removed in Drupal 10.0.0. Use the core/once library instead. See https://www.drupal.org/node/3158256";
  var originalJQOnce = $.fn.once;
  var originalJQRemoveOnce = $.fn.removeOnce;
  $.fn.once = function jQueryOnce(id) {
    Drupal.deprecationError({
      message: "jQuery.once() ".concat(deprecatedMessageSuffix)
    });
    return originalJQOnce.apply(this, [id]);
  };
  $.fn.removeOnce = function jQueryRemoveOnce(id) {
    Drupal.deprecationError({
      message: "jQuery.removeOnce() ".concat(deprecatedMessageSuffix)
    });
    return originalJQRemoveOnce.apply(this, [id]);
  };
  var drupalOnce = once;
  function augmentedOnce(id, selector, context) {
    originalJQOnce.apply($(selector, context), [id]);
    return drupalOnce(id, selector, context);
  }
  function remove(id, selector, context) {
    originalJQRemoveOnce.apply($(selector, context), [id]);
    return drupalOnce.remove(id, selector, context);
  }
  window.once = Object.assign(augmentedOnce, drupalOnce, {
    remove: remove
  });
})(jQuery, once);;
!function(t){var r=["support","secure","gifts","shop","volunteers"],e=t("a[href^='http://'], a[href^='https://'], a[href^='//']");e.not("[href*=bestfriends\\.org]").attr("target","_blank").attr("rel","nofollow"),r.forEach(function(t){e.filter("[href*="+t+"\\.bestfriends\\.org]").attr("target","_blank").attr("rel","nofollow")}),e.filter(r).attr("target","_blank").attr("rel","nofollow")}(jQuery,Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
(function ($, Drupal, drupalSettings) {
  $(document).ready(function () {
    $.ajax({
      type: 'POST',
      cache: false,
      url: drupalSettings.statistics.url,
      data: drupalSettings.statistics.data
    });
  });
})(jQuery, Drupal, drupalSettings);;
!function(a){Drupal.behaviors.atsParagraph={attach:function(t){a("#ACTION_SUBMIT_SURVEY_RESPONSE",t).click(function(t){if(0<a("#denySubmit").val().length)return alert("FALSE!"),t.preventDefault(),!1})}}}(jQuery);;
!function(o,e){"use strict";o.behaviors.bfasModal={attach:function(o){e(".modal",o).once("bfasModal").each(function(){var o=e(this),d=o.find(".modal-trigger"),n=o.find(".modal-content");d.click(function(){d.attr("href","javascript:void(0)"),0==e(".modal-open").length&&(e("body").append(n),n.wrap('<div class="modal-open"></div>'),n.append('<div class="modal-close">&#xf00d;</div'),document.body.style.overflow="hidden",document.body.scroll="no",document.body.style.paddingRight="15px")}),e("body").once(".modal-open").on("click",".modal-open",function(){e(".modal-open").length&&(o.append(n),e(".modal-open").remove(),document.body.style.overflow="scroll",document.body.scroll="yes",document.body.style.paddingRight="0px")})})}}}(Drupal,jQuery,drupalSettings);;
!function(t,o){t.fn.doCheck=function(){var o=t(this).offset().top,a=o+t(this).outerHeight(),n=t(window).scrollTop(),r=n+t(window).height();return n<a&&o<r},t.fn.doLoad=function(){var o=t(this),a=o.find(".bg-loader img");a&&a.attr("src")&&o.find(".body-bg").css({"background-image":'url("'+a.attr("src")+'")'})},o.behaviors.bodyParagraph={attach:function(o){t(".paragraph-body",o).once("bodyParagraph").each(function(){var o=t(this);o.ready(function(){o.doCheck()&&o.once().doLoad()}),t(window).scroll(function(){o.doCheck()&&o.once().doLoad()})})}}}(jQuery,Drupal);;
!function(d){d.flexslider=function(u,e){var p=d(u),m=d.extend({},d.flexslider.defaults,e),s=m.namespace,r="ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch,a=r?"touchend":"click",v="vertical"===m.direction,f=m.reverse,g=0<m.itemWidth,h="fade"===m.animation,l=""!==m.asNavFor,c={};d.data(u,"flexslider",p),c={init:function(){p.animating=!1,p.currentSlide=m.startAt,p.animatingTo=p.currentSlide,p.atEnd=0===p.currentSlide||p.currentSlide===p.last,p.containerSelector=m.selector.substr(0,m.selector.search(" ")),p.slides=d(m.selector,p),p.container=d(p.containerSelector,p),p.count=p.slides.length,p.syncExists=0<d(m.sync).length,"slide"===m.animation&&(m.animation="swing"),p.prop=v?"top":"marginLeft",p.args={},p.manualPause=!1;var e=p;if(n=(n=(n=!m.video)&&!h)&&m.useCSS)e:{var t,n=document.createElement("div"),a=["perspectiveProperty","WebkitPerspective","MozPerspective","OPerspective","msPerspective"];for(t in a)if(void 0!==n.style[a[t]]){p.pfx=a[t].replace("Perspective","").toLowerCase(),p.prop="-"+p.pfx+"-transform",n=!0;break e}n=!1}e.transitions=n,""!==m.controlsContainer&&(p.controlsContainer=0<d(m.controlsContainer).length&&d(m.controlsContainer)),""!==m.manualControls&&(p.manualControls=0<d(m.manualControls).length&&d(m.manualControls)),m.randomize&&(p.slides.sort(function(){return Math.round(Math.random())-.5}),p.container.empty().append(p.slides)),p.doMath(),l&&c.asNav.setup(),p.setup("init"),m.controlNav&&c.controlNav.setup(),m.directionNav&&c.directionNav.setup(),m.keyboard&&(1===d(p.containerSelector).length||m.multipleKeyboard)&&d(document).bind("keyup",function(e){e=e.keyCode,p.animating||39!==e&&37!==e||(e=39===e?p.getTarget("next"):37===e&&p.getTarget("prev"),p.flexAnimate(e,m.pauseOnAction))}),m.mousewheel&&p.bind("mousewheel",function(e,t){e.preventDefault();e=t<0?p.getTarget("next"):p.getTarget("prev");p.flexAnimate(e,m.pauseOnAction)}),m.pausePlay&&c.pausePlay.setup(),m.slideshow&&(m.pauseOnHover&&p.hover(function(){p.manualPlay||p.manualPause||p.pause()},function(){p.manualPause||p.manualPlay||p.play()}),0<m.initDelay?setTimeout(p.play,m.initDelay):p.play()),r&&m.touch&&c.touch(),h&&!m.smoothHeight||d(window).bind("resize focus",c.resize),setTimeout(function(){m.start(p)},200)},asNav:{setup:function(){p.asNav=!0,p.animatingTo=Math.floor(p.currentSlide/p.move),p.currentItem=p.currentSlide,p.slides.removeClass(s+"active-slide").eq(p.currentItem).addClass(s+"active-slide"),p.slides.click(function(e){e.preventDefault();var t=(e=d(this)).index();d(m.asNavFor).data("flexslider").animating||e.hasClass("active")||(p.direction=p.currentItem<t?"next":"prev",p.flexAnimate(t,m.pauseOnAction,!1,!0,!0))})}},controlNav:{setup:function(){p.manualControls?c.controlNav.setupManual():c.controlNav.setupPaging()},setupPaging:function(){var e,t=1;if(p.controlNavScaffold=d('<ol class="'+s+"control-nav "+s+("thumbnails"===m.controlNav?"control-thumbs":"control-paging")+'"></ol>'),1<p.pagingCount)for(var n=0;n<p.pagingCount;n++)e="thumbnails"===m.controlNav?'<img src="'+p.slides.eq(n).attr("data-thumb")+'"/>':"<a>"+t+"</a>",p.controlNavScaffold.append("<li>"+e+"</li>"),t++;(p.controlsContainer?d(p.controlsContainer):p).append(p.controlNavScaffold),c.controlNav.set(),c.controlNav.active(),p.controlNavScaffold.delegate("a, img",a,function(e){e.preventDefault(),e=d(this);var t=p.controlNav.index(e);e.hasClass(s+"active")||(p.direction=t>p.currentSlide?"next":"prev",p.flexAnimate(t,m.pauseOnAction))}),r&&p.controlNavScaffold.delegate("a","click touchstart",function(e){e.preventDefault()})},setupManual:function(){p.controlNav=p.manualControls,c.controlNav.active(),p.controlNav.live(a,function(e){e.preventDefault(),e=d(this);var t=p.controlNav.index(e);e.hasClass(s+"active")||(t>p.currentSlide?p.direction="next":p.direction="prev",p.flexAnimate(t,m.pauseOnAction))}),r&&p.controlNav.live("click touchstart",function(e){e.preventDefault()})},set:function(){p.controlNav=d("."+s+"control-nav li "+("thumbnails"===m.controlNav?"img":"a"),p.controlsContainer||p)},active:function(){p.controlNav.removeClass(s+"active").eq(p.animatingTo).addClass(s+"active")},update:function(e,t){1<p.pagingCount&&"add"===e?p.controlNavScaffold.append(d("<li><a>"+p.count+"</a></li>")):(1===p.pagingCount?p.controlNavScaffold.find("li"):p.controlNav.eq(t).closest("li")).remove(),c.controlNav.set(),1<p.pagingCount&&p.pagingCount!==p.controlNav.length?p.update(t,e):c.controlNav.active()}},directionNav:{setup:function(){var e=d('<ul class="'+s+'direction-nav"><li><a class="'+s+'prev" href="#">'+m.prevText+'</a></li><li><a class="'+s+'next" href="#">'+m.nextText+"</a></li></ul>");p.controlsContainer?(d(p.controlsContainer).append(e),p.directionNav=d("."+s+"direction-nav li a",p.controlsContainer)):(p.append(e),p.directionNav=d("."+s+"direction-nav li a",p)),c.directionNav.update(),p.directionNav.bind(a,function(e){e.preventDefault(),e=d(this).hasClass(s+"next")?p.getTarget("next"):p.getTarget("prev"),p.flexAnimate(e,m.pauseOnAction)}),r&&p.directionNav.bind("click touchstart",function(e){e.preventDefault()})},update:function(){var e=s+"disabled";1===p.pagingCount?p.directionNav.addClass(e):m.animationLoop?p.directionNav.removeClass(e):0===p.animatingTo?p.directionNav.removeClass(e).filter("."+s+"prev").addClass(e):p.animatingTo===p.last?p.directionNav.removeClass(e).filter("."+s+"next").addClass(e):p.directionNav.removeClass(e)}},pausePlay:{setup:function(){var e=d('<div class="'+s+'pauseplay"><a></a></div>');p.controlsContainer?(p.controlsContainer.append(e),p.pausePlay=d("."+s+"pauseplay a",p.controlsContainer)):(p.append(e),p.pausePlay=d("."+s+"pauseplay a",p)),c.pausePlay.update(m.slideshow?s+"pause":s+"play"),p.pausePlay.bind(a,function(e){e.preventDefault(),d(this).hasClass(s+"pause")?(p.manualPause=!0,p.manualPlay=!1,p.pause()):(p.manualPause=!1,p.manualPlay=!0,p.play())}),r&&p.pausePlay.bind("click touchstart",function(e){e.preventDefault()})},update:function(e){"play"===e?p.pausePlay.removeClass(s+"pause").addClass(s+"play").text(m.playText):p.pausePlay.removeClass(s+"play").addClass(s+"pause").text(m.pauseText)}},touch:function(){function n(e){l=v?i-e.touches[0].pageY:i-e.touches[0].pageX,(!(d=v?Math.abs(l)<Math.abs(e.touches[0].pageX-o):Math.abs(l)<Math.abs(e.touches[0].pageY-o))||500<Number(new Date)-c)&&(e.preventDefault(),!h&&p.transitions&&(m.animationLoop||(l/=0===p.currentSlide&&l<0||p.currentSlide===p.last&&0<l?Math.abs(l)/r+2:1),p.setProps(s+l,"setTouch")))}function a(){var e,t;u.removeEventListener("touchmove",n,!1),p.animatingTo!==p.currentSlide||d||null===l||(t=0<(e=f?-l:l)?p.getTarget("next"):p.getTarget("prev"),p.canAdvance(t)&&(Number(new Date)-c<550&&50<Math.abs(e)||Math.abs(e)>r/2)?p.flexAnimate(t,m.pauseOnAction):h||p.flexAnimate(p.currentSlide,m.pauseOnAction,!0)),u.removeEventListener("touchend",a,!1),s=l=o=i=null}var i,o,s,r,l,c,d=!1;u.addEventListener("touchstart",function(e){p.animating?e.preventDefault():1===e.touches.length&&(p.pause(),r=v?p.h:p.w,c=Number(new Date),s=g&&f&&p.animatingTo===p.last?0:g&&f?p.limit-(p.itemW+m.itemMargin)*p.move*p.animatingTo:g&&p.currentSlide===p.last?p.limit:g?(p.itemW+m.itemMargin)*p.move*p.currentSlide:f?(p.last-p.currentSlide+p.cloneOffset)*r:(p.currentSlide+p.cloneOffset)*r,i=v?e.touches[0].pageY:e.touches[0].pageX,o=v?e.touches[0].pageX:e.touches[0].pageY,u.addEventListener("touchmove",n,!1),u.addEventListener("touchend",a,!1))},!1)},resize:function(){!p.animating&&p.is(":visible")&&(g||p.doMath(),h?c.smoothHeight():g?(p.slides.width(p.computedW),p.update(p.pagingCount),p.setProps()):v?(p.viewport.height(p.h),p.setProps(p.h,"setTotal")):(m.smoothHeight&&c.smoothHeight(),p.newSlides.width(p.computedW),p.setProps(p.computedW,"setTotal")))},smoothHeight:function(e){var t;v&&!h||(t=h?p:p.viewport,e?t.animate({height:p.slides.eq(p.animatingTo).height()},e):t.height(p.slides.eq(p.animatingTo).height()))},sync:function(e){var t=d(m.sync).data("flexslider"),n=p.animatingTo;switch(e){case"animate":t.flexAnimate(n,m.pauseOnAction,!1,!0);break;case"play":t.playing||t.asNav||t.play();break;case"pause":t.pause()}}},p.flexAnimate=function(e,t,n,a,i){if(l&&1===p.pagingCount&&(p.direction=p.currentItem<e?"next":"prev"),!p.animating&&(p.canAdvance(e,i)||n)&&p.is(":visible")){if(l&&a){if(n=d(m.asNavFor).data("flexslider"),p.atEnd=0===e||e===p.count-1,n.flexAnimate(e,!0,!1,!0,i),p.direction=p.currentItem<e?"next":"prev",n.direction=p.direction,Math.ceil((e+1)/p.visible)-1===p.currentSlide||0===e)return p.currentItem=e,p.slides.removeClass(s+"active-slide").eq(e).addClass(s+"active-slide"),!1;p.currentItem=e,p.slides.removeClass(s+"active-slide").eq(e).addClass(s+"active-slide"),e=Math.floor(e/p.visible)}var o;p.animating=!0,p.animatingTo=e,m.before(p),t&&p.pause(),p.syncExists&&!i&&c.sync("animate"),m.controlNav&&c.controlNav.active(),g||p.slides.removeClass(s+"active-slide").eq(e).addClass(s+"active-slide"),p.atEnd=0===e||e===p.last,m.directionNav&&c.directionNav.update(),e===p.last&&(m.end(p),m.animationLoop||p.pause()),h?r?(p.slides.eq(p.currentSlide).css({opacity:0,zIndex:1}),p.slides.eq(e).css({opacity:1,zIndex:2}),p.slides.unbind("webkitTransitionEnd transitionend"),p.slides.eq(p.currentSlide).bind("webkitTransitionEnd transitionend",function(){m.after(p)}),p.animating=!1,p.currentSlide=p.animatingTo):(p.slides.eq(p.currentSlide).fadeOut(m.animationSpeed,m.easing),p.slides.eq(e).fadeIn(m.animationSpeed,m.easing,p.wrapup)):(o=v?p.slides.filter(":first").height():p.computedW,e=g?(e=m.itemWidth>p.w?2*m.itemMargin:m.itemMargin,(e=(p.itemW+e)*p.move*p.animatingTo)>p.limit&&1!==p.visible?p.limit:e):0===p.currentSlide&&e===p.count-1&&m.animationLoop&&"next"!==p.direction?f?(p.count+p.cloneOffset)*o:0:p.currentSlide===p.last&&0===e&&m.animationLoop&&"prev"!==p.direction?f?0:(p.count+1)*o:f?(p.count-1-e+p.cloneOffset)*o:(e+p.cloneOffset)*o,p.setProps(e,"",m.animationSpeed),p.transitions?(m.animationLoop&&p.atEnd||(p.animating=!1,p.currentSlide=p.animatingTo),p.container.unbind("webkitTransitionEnd transitionend"),p.container.bind("webkitTransitionEnd transitionend",function(){p.wrapup(o)})):p.container.animate(p.args,m.animationSpeed,m.easing,function(){p.wrapup(o)})),m.smoothHeight&&c.smoothHeight(m.animationSpeed)}},p.wrapup=function(e){h||g||(0===p.currentSlide&&p.animatingTo===p.last&&m.animationLoop?p.setProps(e,"jumpEnd"):p.currentSlide===p.last&&0===p.animatingTo&&m.animationLoop&&p.setProps(e,"jumpStart")),p.animating=!1,p.currentSlide=p.animatingTo,m.after(p)},p.animateSlides=function(){p.animating||p.flexAnimate(p.getTarget("next"))},p.pause=function(){clearInterval(p.animatedSlides),p.playing=!1,m.pausePlay&&c.pausePlay.update("play"),p.syncExists&&c.sync("pause")},p.play=function(){p.animatedSlides=setInterval(p.animateSlides,m.slideshowSpeed),p.playing=!0,m.pausePlay&&c.pausePlay.update("pause"),p.syncExists&&c.sync("play")},p.canAdvance=function(e,t){var n=l?p.pagingCount-1:p.last;return!!t||(l&&p.currentItem===p.count-1&&0===e&&"prev"===p.direction||(!l||0!==p.currentItem||e!==p.pagingCount-1||"next"===p.direction)&&((e!==p.currentSlide||l)&&(!!m.animationLoop||(!p.atEnd||0!==p.currentSlide||e!==n||"next"===p.direction)&&(!p.atEnd||p.currentSlide!==n||0!==e||"next"!==p.direction))))},p.getTarget=function(e){return"next"===(p.direction=e)?p.currentSlide===p.last?0:p.currentSlide+1:0===p.currentSlide?p.last:p.currentSlide-1},p.setProps=function(e,t,n){var a=e||(p.itemW+m.itemMargin)*p.move*p.animatingTo,i=-1*function(){if(g)return"setTouch"===t?e:f&&p.animatingTo===p.last?0:f?p.limit-(p.itemW+m.itemMargin)*p.move*p.animatingTo:p.animatingTo===p.last?p.limit:a;switch(t){case"setTotal":return f?(p.count-1-p.currentSlide+p.cloneOffset)*e:(p.currentSlide+p.cloneOffset)*e;case"setTouch":return e;case"jumpEnd":return f?e:p.count*e;case"jumpStart":return f?p.count*e:e;default:return e}}()+"px";p.transitions&&(i=v?"translate3d(0,"+i+",0)":"translate3d("+i+",0,0)",p.container.css("-"+p.pfx+"-transition-duration",n=void 0!==n?n/1e3+"s":"0s")),p.args[p.prop]=i,!p.transitions&&void 0!==n||p.container.css(p.args)},p.setup=function(e){var t,n;h?(p.slides.css({width:"100%",float:"left",marginRight:"-100%",position:"relative"}),"init"===e&&(r?p.slides.css({opacity:0,display:"block",webkitTransition:"opacity "+m.animationSpeed/1e3+"s ease",zIndex:1}).eq(p.currentSlide).css({opacity:1,zIndex:2}):p.slides.eq(p.currentSlide).fadeIn(m.animationSpeed,m.easing)),m.smoothHeight&&c.smoothHeight()):("init"===e&&(p.viewport=d('<div class="'+s+'viewport"></div>').css({overflow:"hidden",position:"relative"}).appendTo(p).append(p.container),p.cloneCount=0,p.cloneOffset=0,f&&(n=d.makeArray(p.slides).reverse(),p.slides=d(n),p.container.empty().append(p.slides))),m.animationLoop&&!g&&(p.cloneCount=2,p.cloneOffset=1,"init"!==e&&p.container.find(".clone").remove(),p.container.append(p.slides.first().clone().addClass("clone")).prepend(p.slides.last().clone().addClass("clone"))),p.newSlides=d(m.selector,p),t=f?p.count-1-p.currentSlide+p.cloneOffset:p.currentSlide+p.cloneOffset,v&&!g?(p.container.height(200*(p.count+p.cloneCount)+"%").css("position","absolute").width("100%"),setTimeout(function(){p.newSlides.css({display:"block"}),p.doMath(),p.viewport.height(p.h),p.setProps(t*p.h,"init")},"init"===e?100:0)):(p.container.width(200*(p.count+p.cloneCount)+"%"),p.setProps(t*p.computedW,"init"),setTimeout(function(){p.doMath(),p.newSlides.css({width:p.computedW,float:"left",display:"block"}),m.smoothHeight&&c.smoothHeight()},"init"===e?100:0))),g||p.slides.removeClass(s+"active-slide").eq(p.currentSlide).addClass(s+"active-slide")},p.doMath=function(){var e=p.slides.first(),t=m.itemMargin,n=m.minItems,a=m.maxItems;p.w=p.width(),p.h=e.height(),p.boxPadding=e.outerWidth()-e.width(),g?(p.itemT=m.itemWidth+t,p.minW=n?n*p.itemT:p.w,p.maxW=a?a*p.itemT:p.w,p.itemW=p.minW>p.w?(p.w-t*n)/n:p.maxW<p.w?(p.w-t*a)/a:m.itemWidth>p.w?p.w:m.itemWidth,p.visible=Math.floor(p.w/(p.itemW+t)),p.move=0<m.move&&m.move<p.visible?m.move:p.visible,p.pagingCount=Math.ceil((p.count-p.visible)/p.move+1),p.last=p.pagingCount-1,p.limit=1===p.pagingCount?0:m.itemWidth>p.w?(p.itemW+2*t)*p.count-p.w-t:(p.itemW+t)*p.count-p.w-t):(p.itemW=p.w,p.pagingCount=p.count,p.last=p.count-1),p.computedW=p.itemW-p.boxPadding},p.update=function(e,t){p.doMath(),g||(e<p.currentSlide?p.currentSlide+=1:e<=p.currentSlide&&0!==e&&--p.currentSlide,p.animatingTo=p.currentSlide),m.controlNav&&!p.manualControls&&("add"===t&&!g||p.pagingCount>p.controlNav.length?c.controlNav.update("add"):("remove"===t&&!g||p.pagingCount<p.controlNav.length)&&(g&&p.currentSlide>p.last&&(--p.currentSlide,--p.animatingTo),c.controlNav.update("remove",p.last))),m.directionNav&&c.directionNav.update()},p.addSlide=function(e,t){e=d(e);p.count+=1,p.last=p.count-1,v&&f?void 0!==t?p.slides.eq(p.count-t).after(e):p.container.prepend(e):void 0!==t?p.slides.eq(t).before(e):p.container.append(e),p.update(t,"add"),p.slides=d(m.selector+":not(.clone)",p),p.setup(),m.added(p)},p.removeSlide=function(e){var t=isNaN(e)?p.slides.index(d(e)):e;--p.count,p.last=p.count-1,(isNaN(e)?d(e,p.slides):v&&f?p.slides.eq(p.last):p.slides.eq(e)).remove(),p.doMath(),p.update(t,"remove"),p.slides=d(m.selector+":not(.clone)",p),p.setup(),m.removed(p)},c.init()},d.flexslider.defaults={namespace:"flex-",selector:".slides > li",animation:"fade",easing:"swing",direction:"horizontal",reverse:!1,animationLoop:!0,smoothHeight:!1,startAt:0,slideshow:!0,slideshowSpeed:7e3,animationSpeed:600,initDelay:0,randomize:!1,pauseOnAction:!0,pauseOnHover:!1,useCSS:!0,touch:!0,video:!1,controlNav:!0,directionNav:!0,prevText:"Previous",nextText:"Next",keyboard:!0,multipleKeyboard:!1,mousewheel:!1,pausePlay:!1,pauseText:"Pause",playText:"Play",controlsContainer:"",manualControls:"",sync:"",asNavFor:"",itemWidth:0,itemMargin:0,minItems:0,maxItems:0,move:0,start:function(){},before:function(){},after:function(){},end:function(){},added:function(){},removed:function(){}},d.fn.flexslider=function(n){if("object"==typeof(n=void 0===n?{}:n))return this.each(function(){var e=d(this),t=e.find(n.selector||".slides > li");1===t.length?(t.fadeIn(400),n.start&&n.start(e)):null==e.data("flexslider")&&new d.flexslider(this,n)});var e=d(this).data("flexslider");switch(n){case"play":e.play();break;case"pause":e.pause();break;case"next":e.flexAnimate(e.getTarget("next"),!0);break;case"prev":case"previous":e.flexAnimate(e.getTarget("prev"),!0);break;default:"number"==typeof n&&e.flexAnimate(n,!0)}}}(jQuery);;
$=jQuery;var win=window;!function(){function e(){$(".video-container").each(function(){var t=$(this),e=t.parent().width(),i=e/1.77;if(0<t.parent(".youtube-container").length)return!0;t.css({height:i,width:e}),t.closest(".career-feature").length&&767<$(window).width()&&t.css({height:e/2.5,width:"75%"})})}$(".layout-container").each(function(){$(this).find(["iframe[src^='http://player.vimeo.com']","iframe[src^='http://www.youtube.com']","iframe[src^='https://www.youtube.com']","object","embed"].join(",")).each(function(){var t=$(this);if(0<t.parent(".youtube-container").length)return!0;t.css({height:"100%",width:"100%"}).removeAttr("height").removeAttr("width").wrap('<div class="video-container"></div>'),e()})}),$(win).on("resize",function(){var t=win.setTimeout(function(){win.clearTimeout(t),e()},30)})}();;
!function(i,t){"use strict";i.behaviors.FlexSliderInit={attach:function(i,e){for(var o=[{slider:t(".flexslider"),options:{width:"100%",height:"457px",responsive:!0,responsiveUnder:940,animation:"slide",direction:"horizontal",animationLoop:!1,controlNav:!1,directionNav:!1,slideshow:!1,slideshowSpeed:6e3,animationSpeed:600,randomize:!1,sync:".flexslider-controls"}},{slider:t("#career-slideshow"),options:{width:"100%",height:"100%",responsive:!1,responsiveUnder:940,animation:"fade",direction:"horizontal",animationLoop:!0,controlNav:!1,directionNav:!1,slideshow:!0,slideshowSpeed:3e3,animationSpeed:400,randomize:!1,smoothHeight:!1}}],n=0;n<o.length;n++)this.initialize(o[n].slider,o[n].options)},initialize:function(i,e,o){i=t(i,o);i.length&&i.flexslider(e)}},i.behaviors.FlexSlider={attach:function(i,e){this.flexControls()},flexControls:function(){var i={width:"890px",height:"167px",responsive:!0,responsiveUnder:940,animation:"slide",direction:"horizontal",animationLoop:!1,controlNav:!1,directionNav:!0,slideshow:!1,slideshowSpeed:6e3,animationSpeed:600,itemWidth:164,itemMargin:15,asNavFor:".flexslider"},e=t(".flexslider-controls");e.length&&t(win).load(function(){e.flexslider(i)})}}}(Drupal,jQuery,drupalSettings);;
/*! tableau-2.1.2 */
(function() {


/*! BEGIN MscorlibSlim */



////////////////////////////////////////////////////////////////////////////////
// Globals and assembly registration
////////////////////////////////////////////////////////////////////////////////

var global = {};

(function(global) {
"use strict";

var ss = { __assemblies: {} };

ss.initAssembly = function assembly(obj, name, res) {
  res = res || {};
  obj.name = name;
  obj.toString = function() { return this.name; };
  obj.__types = {};
  obj.getResourceNames = function() { return Object.keys(res); };
  obj.getResourceDataBase64 = function(name) { return res[name] || null; };
  obj.getResourceData = function(name) { var r = res[name]; return r ? ss.dec64(r) : null; };
  ss.__assemblies[name] = obj;
};
ss.initAssembly(ss, 'mscorlib');



////////////////////////////////////////////////////////////////////////////////
// Utility methods (generated via Script.IsNull, etc.)
////////////////////////////////////////////////////////////////////////////////


ss.getAssemblies = function ss$getAssemblies() {
  return Object.keys(ss.__assemblies).map(function(n) { return ss.__assemblies[n]; });
};

ss.isNullOrUndefined = function ss$isNullOrUndefined(o) {
  return (o === null) || (o === undefined);
};

ss.isValue = function ss$isValue(o) {
  return (o !== null) && (o !== undefined);
};

ss.referenceEquals = function ss$referenceEquals(a, b) {
  return ss.isValue(a) ? a === b : !ss.isValue(b);
};

ss.mkdict = function ss$mkdict() {
  var a = (arguments.length != 1 ? arguments : arguments[0]);
  var r = {};
  for (var i = 0; i < a.length; i += 2) {
    r[a[i]] = a[i + 1];
  }
  return r;
};

ss.clone = function ss$clone(t, o) {
  return o ? t.$clone(o) : o;
}

ss.coalesce = function ss$coalesce(a, b) {
  return ss.isValue(a) ? a : b;
};

ss.isDate = function ss$isDate(obj) {
  return Object.prototype.toString.call(obj) === '[object Date]';
};

ss.isArray = function ss$isArray(obj) {
  return Object.prototype.toString.call(obj) === '[object Array]';
};

ss.isTypedArrayType = function ss$isTypedArrayType(type) {
  return ['Float32Array', 'Float64Array', 'Int8Array', 'Int16Array', 'Int32Array', 'Uint8Array', 'Uint16Array', 'Uint32Array', 'Uint8ClampedArray'].indexOf(ss.getTypeFullName(type)) >= 0;
};

ss.isArrayOrTypedArray = function ss$isArray(obj) {
  return ss.isArray(obj) || ss.isTypedArrayType(ss.getInstanceType(obj));
};

ss.getHashCode = function ss$getHashCode(obj) {
  if (!ss.isValue(obj))
    throw new ss_NullReferenceException('Cannot get hash code of null');
  else if (typeof(obj.getHashCode) === 'function')
    return obj.getHashCode();
  else if (typeof(obj) === 'boolean') {
    return obj ? 1 : 0;
  }
  else if (typeof(obj) === 'number') {
    var s = obj.toExponential();
    s = s.substr(0, s.indexOf('e'));
    return parseInt(s.replace('.', ''), 10) & 0xffffffff;
  }
  else if (typeof(obj) === 'string') {
    var res = 0;
    for (var i = 0; i < obj.length; i++)
      res = (res * 31 + obj.charCodeAt(i)) & 0xffffffff;
    return res;
  }
  else if (ss.isDate(obj)) {
    return obj.valueOf() & 0xffffffff;
  }
  else {
    return ss.defaultHashCode(obj);
  }
};

ss.defaultHashCode = function ss$defaultHashCode(obj) {
  return obj.$__hashCode__ || (obj.$__hashCode__ = (Math.random() * 0x100000000) | 0);
};


ss.equals = function ss$equals(a, b) {
    if (!ss.isValue(a))
        throw new ss_NullReferenceException('Object is null');
    else if (a !== ss && typeof(a.equals) === 'function')
        return a.equals(b);
    if (ss.isDate(a) && ss.isDate(b))
        return a.valueOf() === b.valueOf();
    else if (typeof(a) === 'function' && typeof(b) === 'function')
        return ss.delegateEquals(a, b);
    else if (ss.isNullOrUndefined(a) && ss.isNullOrUndefined(b))
        return true;
    else
        return a === b;
};

ss.compare = function ss$compare(a, b) {
  if (!ss.isValue(a))
    throw new ss_NullReferenceException('Object is null');
  else if (typeof(a) === 'number' || typeof(a) === 'string' || typeof(a) === 'boolean')
    return a < b ? -1 : (a > b ? 1 : 0);
  else if (ss.isDate(a))
    return ss.compare(a.valueOf(), b.valueOf());
  else
    return a.compareTo(b);
};

ss.equalsT = function ss$equalsT(a, b) {
  if (!ss.isValue(a))
    throw new ss_NullReferenceException('Object is null');
  else if (typeof(a) === 'number' || typeof(a) === 'string' || typeof(a) === 'boolean')
    return a === b;
  else if (ss.isDate(a))
    return a.valueOf() === b.valueOf();
  else
    return a.equalsT(b);
};

ss.staticEquals = function ss$staticEquals(a, b) {
  if (!ss.isValue(a))
    return !ss.isValue(b);
  else
    return ss.isValue(b) ? ss.equals(a, b) : false;
};

ss.shallowCopy = function ss$shallowCopy(source, target) {
  var keys = Object.keys(source);
  for (var i = 0, l = keys.length; i < l; i++) {
    var k = keys[i];
    target[k] = source[k];
  }
};

ss.isLower = function ss$isLower(c) {
  var s = String.fromCharCode(c);
  return s === s.toLowerCase() && s !== s.toUpperCase();
};

ss.isUpper = function ss$isUpper(c) {
  var s = String.fromCharCode(c);
  return s !== s.toLowerCase() && s === s.toUpperCase();
};

if (typeof(window) == 'object') {
  // Browser-specific stuff that could go into the Web assembly, but that assembly does not have an associated JS file.
  if (!window.Element) {
    // IE does not have an Element constructor. This implementation should make casting to elements work.
    window.Element = function() {};
    window.Element.isInstanceOfType = function(instance) { return instance && typeof instance.constructor === 'undefined' && typeof instance.tagName === 'string'; };
  }
  window.Element.__typeName = 'Element';
}

///////////////////////////////////////////////////////////////////////////////
// Object Extensions

ss.clearKeys = function ss$clearKeys(d) {
  for (var n in d) {
    if (d.hasOwnProperty(n))
      delete d[n];
  }
};

ss.keyExists = function ss$keyExists(d, key) {
  return d[key] !== undefined;
};

if (!Object.keys) {
  Object.keys = (function() {
    'use strict';
    var hasOwnProperty = Object.prototype.hasOwnProperty,
      hasDontEnumBug = !({toString: null}).propertyIsEnumerable('toString'),
      dontEnums = ['toString','toLocaleString','valueOf','hasOwnProperty','isPrototypeOf','propertyIsEnumerable','constructor'],
      dontEnumsLength = dontEnums.length;

    return function (obj) {
      if (typeof obj !== 'object' && (typeof obj !== 'function' || obj === null)) {
        throw new TypeError('Object.keys called on non-object');
      }

      var result = [], prop, i;

      for (prop in obj) {
        if (hasOwnProperty.call(obj, prop)) {
          result.push(prop);
        }
      }

      if (hasDontEnumBug) {
        for (i = 0; i < dontEnumsLength; i++) {
          if (hasOwnProperty.call(obj, dontEnums[i])) {
            result.push(dontEnums[i]);
          }
        }
      }
      return result;
    };
  }());
}

ss.getKeyCount = function ss$getKeyCount(d) {
  return Object.keys(d).length;
};

////////////////////////////////////////////////////////////////////////////////
// Type System Implementation
////////////////////////////////////////////////////////////////////////////////

// When FULL_TYPE_SYSTEM is not defined, then the code is not the full-blown
// type system. It's Just enough to allow us to call base class methods.

ss.__genericCache = {};

ss._makeGenericTypeName = function ss$_makeGenericTypeName(genericType, typeArguments) {
  var result = genericType.__typeName;
  for (var i = 0; i < typeArguments.length; i++)
    result += (i === 0 ? '[' : ',') + '[' + ss.getTypeQName(typeArguments[i]) + ']';
  result += ']';
  return result;
};

ss.makeGenericType = function ss$makeGenericType(genericType, typeArguments) {
  var name = ss._makeGenericTypeName(genericType, typeArguments);
  return ss.__genericCache[name] || genericType.apply(null, typeArguments);
};

ss.registerGenericClassInstance = function ss$registerGenericClassInstance(instance, genericType, typeArguments, members, baseType, interfaceTypes) {
  var name = ss._makeGenericTypeName(genericType, typeArguments);
  ss.__genericCache[name] = instance;
  instance.__typeName = name;
  instance.__genericTypeDefinition = genericType;
  instance.__typeArguments = typeArguments;
  ss.initClass(instance, genericType.__assembly, members, baseType(), interfaceTypes());
};

ss.registerGenericInterfaceInstance = function ss$registerGenericInterfaceInstance(instance, genericType, typeArguments, members, baseInterfaces) {
  var name = ss._makeGenericTypeName(genericType, typeArguments);
  ss.__genericCache[name] = instance;
  instance.__typeName = name;
  instance.__genericTypeDefinition = genericType;
  instance.__typeArguments = typeArguments;
  ss.initInterface(instance, genericType.__assembly, members, baseInterfaces());
};

ss.isGenericTypeDefinition = function ss$isGenericTypeDefinition(type) {
  return type.__isGenericTypeDefinition || false;
};

ss.getGenericTypeDefinition = function ss$getGenericTypeDefinition(type) {
  return type.__genericTypeDefinition || null;
};

ss.getGenericParameterCount = function ss$getGenericParameterCount(type) {
  return type.__typeArgumentCount || 0;
};

ss.getGenericArguments = function ss$getGenericArguments(type) {
  return type.__typeArguments || null;
};


ss.setMetadata = function ss$_setMetadata(type, metadata) {
  if (metadata.members) {
    for (var i = 0; i < metadata.members.length; i++) {
      var m = metadata.members[i];
      m.typeDef = type;
      if (m.adder) m.adder.typeDef = type;
      if (m.remover) m.remover.typeDef = type;
      if (m.getter) m.getter.typeDef = type;
      if (m.setter) m.setter.typeDef = type;
    }
  }
  type.__metadata = metadata;
  if (metadata.variance) {
    type.isAssignableFrom = function(source) {
      var check = function(target, type) {
        if (type.__genericTypeDefinition === target.__genericTypeDefinition && type.__typeArguments.length == target.__typeArguments.length) {
          for (var i = 0; i < target.__typeArguments.length; i++) {
            var v = target.__metadata.variance[i], t = target.__typeArguments[i], s = type.__typeArguments[i];
            switch (v) {
              case 1: if (!ss.isAssignableFrom(t, s)) return false; break;
              case 2: if (!ss.isAssignableFrom(s, t)) return false; break;
              default: if (s !== t) return false;
            }
          }
          return true;
        }
        return false;
      };

      if (source.__interface && check(this, source))
        return true;
      var ifs = ss.getInterfaces(source);
      for (var i = 0; i < ifs.length; i++) {
        if (ifs[i] === this || check(this, ifs[i]))
          return true;
      }
      return false;
    };
  }
}
ss.setMetadata = function ss$_setMetadata(type, metadata) {
};

ss.initClass = function ss$initClass(ctor, asm, members, baseType, interfaces) {
  ctor.__class = true;
  ctor.__assembly = asm;
  if (!ctor.__typeArguments)
    asm.__types[ctor.__typeName] = ctor;
  if (baseType && baseType !== Object) {
    var f = function(){};
    f.prototype = baseType.prototype;
    ctor.prototype = new f();
    ctor.prototype.constructor = ctor;
  }
  ss.shallowCopy(members, ctor.prototype);
  if (interfaces)
    ctor.__interfaces = interfaces;
};

ss.initGenericClass = function ss$initGenericClass(ctor, asm, typeArgumentCount) {
  ctor.__class = true;
  ctor.__assembly = asm;
  asm.__types[ctor.__typeName] = ctor;
  ctor.__typeArgumentCount = typeArgumentCount;
  ctor.__isGenericTypeDefinition = true;
};

ss.initInterface = function ss$initInterface(ctor, asm, members, baseInterfaces) {
  ctor.__interface = true;
  ctor.__assembly = asm;
  if (!ctor.__typeArguments)
    asm.__types[ctor.__typeName] = ctor;
  if (baseInterfaces)
    ctor.__interfaces = baseInterfaces;
  ss.shallowCopy(members, ctor.prototype);
  ctor.isAssignableFrom = function(type) { return ss.contains(ss.getInterfaces(type), this); };
};

ss.initGenericInterface = function ss$initGenericClass(ctor, asm, typeArgumentCount) {
  ctor.__interface = true;
  ctor.__assembly = asm;
  asm.__types[ctor.__typeName] = ctor;
  ctor.__typeArgumentCount = typeArgumentCount;
  ctor.__isGenericTypeDefinition = true;
};

ss.initEnum = function ss$initEnum(ctor, asm, members, namedValues) {
  ctor.__enum = true;
  ctor.__assembly = asm;
  asm.__types[ctor.__typeName] = ctor;
  ss.shallowCopy(members, ctor.prototype);
  ctor.getDefaultValue = ctor.createInstance = function() { return namedValues ? null : 0; };
  ctor.isInstanceOfType = function(instance) { return typeof(instance) == (namedValues ? 'string' : 'number'); };
};

ss.getBaseType = function ss$getBaseType(type) {
  if (type === Object || type.__interface) {
    return null;
  }
  else if (Object.getPrototypeOf) {
    return Object.getPrototypeOf(type.prototype).constructor;
  }
  else {
    var p = type.prototype;
    if (Object.prototype.hasOwnProperty.call(p, 'constructor')) {
      try {
        var ownValue = p.constructor;
        delete p.constructor;
        return p.constructor;
      }
      finally {
        p.constructor = ownValue;
      }
    }
    return p.constructor;
  }
};

ss.getTypeFullName = function ss$getTypeFullName(type) {
  return type.__typeName || type.name || (type.toString().match(/^\s*function\s*([^\s(]+)/) || [])[1] || 'Object';
};

ss.getTypeQName = function ss$getTypeFullName(type) {
  return ss.getTypeFullName(type) + (type.__assembly ? ', ' + type.__assembly.name : '');
};

ss.getTypeName = function ss$getTypeName(type) {
  var fullName = ss.getTypeFullName(type);
  var bIndex = fullName.indexOf('[');
  var nsIndex = fullName.lastIndexOf('.', bIndex >= 0 ? bIndex : fullName.length);
  return nsIndex > 0 ? fullName.substr(nsIndex + 1) : fullName;
};

ss.getTypeNamespace = function ss$getTypeNamespace(type) {
  var fullName = ss.getTypeFullName(type);
  var bIndex = fullName.indexOf('[');
  var nsIndex = fullName.lastIndexOf('.', bIndex >= 0 ? bIndex : fullName.length);
  return nsIndex > 0 ? fullName.substr(0, nsIndex) : '';
};

ss.getTypeAssembly = function ss$getTypeAssembly(type) {
  if (ss.contains([Date, Number, Boolean, String, Function, Array], type))
    return ss;
  else
    return type.__assembly || null;
};

ss._getAssemblyType = function ss$_getAssemblyType(asm, name) {
  var result = [];
  if (asm.__types) {
    return asm.__types[name] || null;
  }
  else {
    var a = name.split('.');
    for (var i = 0; i < a.length; i++) {
      asm = asm[a[i]];
      if (!ss.isValue(asm))
        return null;
    }
    if (typeof asm !== 'function')
      return null;
    return asm;
  }
};

ss.getAssemblyTypes = function ss$getAssemblyTypes(asm) {
  var result = [];
  if (asm.__types) {
    for (var t in asm.__types) {
      if (asm.__types.hasOwnProperty(t))
        result.push(asm.__types[t]);
    }
  }
  else {
    var traverse = function(s, n) {
      for (var c in s) {
        if (s.hasOwnProperty(c))
          traverse(s[c], c);
      }
      if (typeof(s) === 'function' && ss.isUpper(n.charCodeAt(0)))
        result.push(s);
    };
    traverse(asm, '');
  }
  return result;
};

ss.createAssemblyInstance = function ss$createAssemblyInstance(asm, typeName) {
  var t = ss.getType(typeName, asm);
  return t ? ss.createInstance(t) : null;
};

ss.getInterfaces = function ss$getInterfaces(type) {
  if (type.__interfaces)
    return type.__interfaces;
  else if (type === Date || type === Number)
    return [ ss_IEquatable, ss_IComparable, ss_IFormattable ];
  else if (type === Boolean || type === String)
    return [ ss_IEquatable, ss_IComparable ];
  else if (type === Array || ss.isTypedArrayType(type))
    return [ ss_IEnumerable, ss_ICollection, ss_IList ];
  else
    return [];
};

ss.isInstanceOfType = function ss$isInstanceOfType(instance, type) {
  if (ss.isNullOrUndefined(instance))
    return false;

  if (typeof(type.isInstanceOfType) === 'function')
    return type.isInstanceOfType(instance);

  return ss.isAssignableFrom(type, ss.getInstanceType(instance));
};

ss.isAssignableFrom = function ss$isAssignableFrom(target, type) {
  return target === type || (typeof(target.isAssignableFrom) === 'function' && target.isAssignableFrom(type)) || type.prototype instanceof target;
};

ss.isClass = function Type$isClass(type) {
  return (type.__class == true || type === Array || type === Function || type === RegExp || type === String || type === Error || type === Object);
};

ss.isEnum = function Type$isEnum(type) {
  return !!type.__enum;
};

ss.isFlags = function Type$isFlags(type) {
  return type.__metadata && type.__metadata.enumFlags || false;
};

ss.isInterface = function Type$isInterface(type) {
  return !!type.__interface;
};

ss.safeCast = function ss$safeCast(instance, type) {
  if (type === true)
    return instance;
  else if (type === false)
    return null;
  else
    return ss.isInstanceOfType(instance, type) ? instance : null;
};

ss.cast = function ss$cast(instance, type) {
  if (instance === null || typeof(instance) === 'undefined')
    return instance;
  else if (type === true || (type !== false && ss.isInstanceOfType(instance, type)))
    return instance;
  throw new ss_InvalidCastException('Cannot cast object to type ' + ss.getTypeFullName(type));
};

ss.getInstanceType = function ss$getInstanceType(instance) {
  if (!ss.isValue(instance))
    throw new ss_NullReferenceException('Cannot get type of null');

  // NOTE: We have to catch exceptions because the constructor
  //       cannot be looked up on native COM objects
  try {
    return instance.constructor;
  }
  catch (ex) {
    return Object;
  }
};

ss._getType = function (typeName, asm, re) {
  var outer = !re;
  re = re || /[[,\]]/g;
  var last = re.lastIndex, m = re.exec(typeName), tname, targs = [];
  if (m) {
    tname = typeName.substring(last, m.index);
    switch (m[0]) {
      case '[':
        if (typeName[m.index + 1] != '[')
          return null;
        for (;;) {
          re.exec(typeName);
          var t = ss._getType(typeName, global, re);
          if (!t)
            return null;
          targs.push(t);
          m = re.exec(typeName);
          if (m[0] === ']')
            break;
          else if (m[0] !== ',')
            return null;
        }
        m = re.exec(typeName);
        if (m && m[0] === ',') {
          re.exec(typeName);
          if (!(asm = ss.__assemblies[(re.lastIndex > 0 ? typeName.substring(m.index + 1, re.lastIndex - 1) : typeName.substring(m.index + 1)).trim()]))
            return null;
        }
        break;

      case ']':
        break;

      case ',':
        re.exec(typeName);
        if (!(asm = ss.__assemblies[(re.lastIndex > 0 ? typeName.substring(m.index + 1, re.lastIndex - 1) : typeName.substring(m.index + 1)).trim()]))
          return null;
        break;
    }
  }
  else {
    tname = typeName.substring(last);
  }

  if (outer && re.lastIndex)
    return null;

  var t = ss._getAssemblyType(asm, tname.trim());
  return targs.length ? ss.makeGenericType(t, targs) : t;
}

ss.getType = function ss$getType(typeName, asm) {
  return typeName ? ss._getType(typeName, asm || global) : null;
};

ss.getDefaultValue = function ss$getDefaultValue(type) {
  if (typeof(type.getDefaultValue) === 'function')
    return type.getDefaultValue();
  else if (type === Boolean)
    return false;
  else if (type === Date)
    return new Date(0);
  else if (type === Number)
    return 0;
  return null;
};

ss.createInstance = function ss$createInstance(type) {
  if (typeof(type.createInstance) === 'function')
    return type.createInstance();
  else if (type === Boolean)
    return false;
  else if (type === Date)
    return new Date(0);
  else if (type === Number)
    return 0;
  else if (type === String)
    return '';
  else
    return new type();
};


///////////////////////////////////////////////////////////////////////////////
// IFormattable

var ss_IFormattable = function IFormattable$() { };

ss_IFormattable.__typeName = 'ss.IFormattable';
ss.IFormattable = ss_IFormattable;
ss.initInterface(ss_IFormattable, ss, { format: null });


///////////////////////////////////////////////////////////////////////////////
// IComparable

var ss_IComparable = function IComparable$() { };

ss_IComparable.__typeName = 'ss.IComparable';
ss.IComparable = ss_IComparable;
ss.initInterface(ss_IComparable, ss, { compareTo: null });

///////////////////////////////////////////////////////////////////////////////
// IEquatable

var ss_IEquatable = function IEquatable$() { };

ss_IEquatable.__typeName = 'ss.IEquatable';
ss.IEquatable = ss_IEquatable;
ss.initInterface(ss_IEquatable, ss, { equalsT: null });

///////////////////////////////////////////////////////////////////////////////
// Number Extensions


///////////////////////////////////////////////////////////////////////////////
// String Extensions


ss.isNullOrEmptyString = function ss$isNullOrEmptyString(s) {
  return !s || !s.length;
};


if (!String.prototype.trim) {
  String.prototype.trim = function String$trim() {
    return ss.trimStartString(ss.trimEndString(this));
  };
}

ss.trimEndString = function ss$trimEndString(s, chars) {
  return s.replace(chars ? new RegExp('[' + String.fromCharCode.apply(null, chars) + ']+$') : /\s*$/, '');
};

ss.trimStartString = function ss$trimStartString(s, chars) {
  return s.replace(chars ? new RegExp('^[' + String.fromCharCode.apply(null, chars) + ']+') : /^\s*/, '');
};

ss.trimString = function ss$trimString(s, chars) {
  return ss.trimStartString(ss.trimEndString(s, chars), chars);
};


///////////////////////////////////////////////////////////////////////////////
// Math Extensions


///////////////////////////////////////////////////////////////////////////////
// IFormatProvider

///////////////////////////////////////////////////////////////////////////////
// NumberFormatInfo

///////////////////////////////////////////////////////////////////////////////
// DateTimeFormatInfo

///////////////////////////////////////////////////////////////////////////////
// Array Extensions


ss.arrayClone = function ss$arrayClone(arr) {
    if (arr.length === 1) {
        return [arr[0]];
    }
    else {
        return Array.apply(null, arr);
    }
};


if (!Array.prototype.map) {
  Array.prototype.map = function Array$map(callback, instance) {
    var length = this.length;
    var mapped = new Array(length);
    for (var i = 0; i < length; i++) {
      if (i in this) {
        mapped[i] = callback.call(instance, this[i], i, this);
      }
    }
    return mapped;
  };
}


if (!Array.prototype.some) {
  Array.prototype.some = function Array$some(callback, instance) {
    var length = this.length;
    for (var i = 0; i < length; i++) {
      if (i in this && callback.call(instance, this[i], i, this)) {
        return true;
      }
    }
    return false;
  };
}

// Production steps of ECMA-262, Edition 5, 15.4.4.18
// Reference: http://es5.github.io/#x15.4.4.18
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
if (!Array.prototype.forEach) {

  Array.prototype.forEach = function(callback, thisArg) {

      var T, k;

      if (this == null) {
          throw new TypeError(' this is null or not defined');
      }

      // 1. Let O be the result of calling ToObject passing the |this| value as the argument.
      var O = Object(this);

      // 2. Let lenValue be the result of calling the Get internal method of O with the argument "length".
      // 3. Let len be ToUint32(lenValue).
      var len = O.length >>> 0;

      // 4. If IsCallable(callback) is false, throw a TypeError exception.
      // See: http://es5.github.com/#x9.11
      if (typeof callback !== "function") {
          throw new TypeError(callback + ' is not a function');
      }

      // 5. If thisArg was supplied, let T be thisArg; else let T be undefined.
      if (arguments.length > 1) {
          T = thisArg;
      }

      // 6. Let k be 0
      k = 0;

      // 7. Repeat, while k < len
      while (k < len) {

          var kValue;

          // a. Let Pk be ToString(k).
          //   This is implicit for LHS operands of the in operator
          // b. Let kPresent be the result of calling the HasProperty internal method of O with argument Pk.
          //   This step can be combined with c
          // c. If kPresent is true, then
          if (k in O) {

              // i. Let kValue be the result of calling the Get internal method of O with argument Pk.
              kValue = O[k];

              // ii. Call the Call internal method of callback with T as the this value and
              // argument list containing kValue, k, and O.
              callback.call(T, kValue, k, O);
          }
          // d. Increase k by 1.
          k++;
      }
      // 8. return undefined
  };
}

// Production steps of ECMA-262, Edition 5
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
if (!Array.prototype.filter) {
    Array.prototype.filter = function(fun/*, thisArg*/) {

        if (this === void 0 || this === null) {
            throw new TypeError();
        }

        var t = Object(this);
        var len = t.length >>> 0;
        if (typeof fun !== 'function') {
            throw new TypeError();
        }

        var res = [];
        var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
        for (var i = 0; i < len; i++) {
            if (i in t) {
                var val = t[i];

                // NOTE: Technically this should Object.defineProperty at
                //       the next index, as push can be affected by
                //       properties on Object.prototype and Array.prototype.
                //       But that method's new, and collisions should be
                //       rare, so use the more-compatible alternative.
                if (fun.call(thisArg, val, i, t)) {
                    res.push(val);
                }
            }
        }

        return res;
    };
}


///////////////////////////////////////////////////////////////////////////////
// Date Extensions


///////////////////////////////////////////////////////////////////////////////
// Function Extensions

ss._delegateContains = function ss$_delegateContains(targets, object, method) {
  for (var i = 0; i < targets.length; i += 2) {
    if (targets[i] === object && targets[i + 1] === method) {
      return true;
    }
  }
  return false;
};

ss._mkdel = function ss$_mkdel(targets) {
  var delegate = function() {
    if (targets.length == 2) {
      return targets[1].apply(targets[0], arguments);
    }
    else {
      var clone = ss.arrayClone(targets);
      for (var i = 0; i < clone.length; i += 2) {
        if (ss._delegateContains(targets, clone[i], clone[i + 1])) {
          clone[i + 1].apply(clone[i], arguments);
        }
      }
      return null;
    }
  };
  delegate._targets = targets;

  return delegate;
};

ss.mkdel = function ss$mkdel(object, method) {
  if (!object) {
    return method;
  }
  return ss._mkdel([object, method]);
};

ss.delegateCombine = function ss$delegateCombine(delegate1, delegate2) {
  if (!delegate1) {
    if (!delegate2._targets) {
      return ss.mkdel(null, delegate2);
    }
    return delegate2;
  }
  if (!delegate2) {
    if (!delegate1._targets) {
      return ss.mkdel(null, delegate1);
    }
    return delegate1;
  }

  var targets1 = delegate1._targets ? delegate1._targets : [null, delegate1];
  var targets2 = delegate2._targets ? delegate2._targets : [null, delegate2];

  return ss._mkdel(targets1.concat(targets2));
};

ss.delegateRemove = function ss$delegateRemove(delegate1, delegate2) {
  if (!delegate1 || (delegate1 === delegate2)) {
    return null;
  }
  if (!delegate2) {
    return delegate1;
  }

  var targets = delegate1._targets;
  var object = null;
  var method;
  if (delegate2._targets) {
    object = delegate2._targets[0];
    method = delegate2._targets[1];
  }
  else {
    method = delegate2;
  }

  for (var i = 0; i < targets.length; i += 2) {
    if ((targets[i] === object) && (targets[i + 1] === method)) {
      if (targets.length == 2) {
        return null;
      }
      var t = ss.arrayClone(targets);
      t.splice(i, 2);
      return ss._mkdel(t);
    }
  }

  return delegate1;
};

ss.delegateEquals = function ss$delegateEquals(a, b) {
    if (a === b)
        return true;
    if (!a._targets && !b._targets)
        return false;
    var ta = a._targets || [null, a], tb = b._targets || [null, b];
    if (ta.length != tb.length)
        return false;
    for (var i = 0; i < ta.length; i++) {
        if (ta[i] !== tb[i])
            return false;
    }
    return true;
};


///////////////////////////////////////////////////////////////////////////////
// RegExp Extensions


///////////////////////////////////////////////////////////////////////////////
// Debug Extensions


///////////////////////////////////////////////////////////////////////////////
// Enum

var ss_Enum = function Enum$() {
};
ss_Enum.__typeName = 'ss.Enum';
ss.Enum = ss_Enum;
ss.initClass(ss_Enum, ss, {});


ss_Enum.getValues = function Enum$getValues(enumType) {
  var parts = [];
  var values = enumType.prototype;
  for (var i in values) {
    if (values.hasOwnProperty(i))
      parts.push(values[i]);
  }
  return parts;
};

///////////////////////////////////////////////////////////////////////////////
// CultureInfo


///////////////////////////////////////////////////////////////////////////////
// IEnumerator

var ss_IEnumerator = function IEnumerator$() { };

ss_IEnumerator.__typeName = 'ss.IEnumerator';
ss.IEnumerator = ss_IEnumerator;
ss.initInterface(ss_IEnumerator, ss, { current: null, moveNext: null, reset: null }, [ss_IDisposable]);

///////////////////////////////////////////////////////////////////////////////
// IEnumerable

var ss_IEnumerable = function IEnumerable$() { };

ss_IEnumerable.__typeName = 'ss.IEnumerable';
ss.IEnumerable = ss_IEnumerable;
ss.initInterface(ss_IEnumerable, ss, { getEnumerator: null });

ss.getEnumerator = function ss$getEnumerator(obj) {
  return obj.getEnumerator ? obj.getEnumerator() : new ss_ArrayEnumerator(obj);
};

///////////////////////////////////////////////////////////////////////////////
// ICollection

var ss_ICollection = function ICollection$() { };

ss_ICollection.__typeName = 'ss.ICollection';
ss.ICollection = ss_ICollection;
ss.initInterface(ss_ICollection, ss, { get_count: null, add: null, clear: null, contains: null, remove: null });

ss.count = function ss$count(obj) {
  return obj.get_count ? obj.get_count() : obj.length;
};

ss.add = function ss$add(obj, item) {
  if (obj.add)
    obj.add(item);
  else if (ss.isArray(obj))
    obj.push(item);
  else
    throw new ss_NotSupportedException();
};

ss.clear = function ss$clear(obj) {
  if (obj.clear)
    obj.clear();
  else if (ss.isArray(obj))
    obj.length = 0;
  else
    throw new ss_NotSupportedException();
};

ss.remove = function ss$remove(obj, item) {
  if (obj.remove)
    return obj.remove(item);
  else if (ss.isArray(obj)) {
    var index = ss.indexOf(obj, item);
    if (index >= 0) {
      obj.splice(index, 1);
      return true;
    }
    return false;
  }
  else
    throw new ss_NotSupportedException();
};

ss.contains = function ss$contains(obj, item) {
  if (obj.contains)
    return obj.contains(item);
  else
    return ss.indexOf(obj, item) >= 0;
};

///////////////////////////////////////////////////////////////////////////////
// TimeSpan


///////////////////////////////////////////////////////////////////////////////
// IEqualityComparer

var ss_IEqualityComparer = function IEqualityComparer$() { };

ss_IEqualityComparer.__typeName = 'ss.IEqualityComparer';
ss.IEqualityComparer = ss_IEqualityComparer;
ss.initInterface(ss_IEqualityComparer, ss, { areEqual: null, getObjectHashCode: null });

///////////////////////////////////////////////////////////////////////////////
// IComparer

var ss_IComparer = function IComparer$() { };

ss_IComparer.__typeName = 'ss.IComparer';
ss.IComparer = ss_IComparer;
ss.initInterface(ss_IComparer, ss, { compare: null });

///////////////////////////////////////////////////////////////////////////////
// Nullable

ss.unbox = function ss$unbox(instance) {
  if (!ss.isValue(instance))
    throw new ss_InvalidOperationException('Nullable object must have a value.');
  return instance;
};

var ss_Nullable$1 = function Nullable$1$(T) {
  var $type = function() {
  };
  $type.isInstanceOfType = function(instance) {
    return ss.isInstanceOfType(instance, T);
  };
  ss.registerGenericClassInstance($type, ss_Nullable$1, [T], {}, function() { return null; }, function() { return []; });
  return $type;
};

ss_Nullable$1.__typeName = 'ss.Nullable$1';
ss.Nullable$1 = ss_Nullable$1;
ss.initGenericClass(ss_Nullable$1, ss, 1);

ss_Nullable$1.eq = function Nullable$eq(a, b) {
  return !ss.isValue(a) ? !ss.isValue(b) : (a === b);
};

ss_Nullable$1.ne = function Nullable$eq(a, b) {
  return !ss.isValue(a) ? ss.isValue(b) : (a !== b);
};

ss_Nullable$1.le = function Nullable$le(a, b) {
  return ss.isValue(a) && ss.isValue(b) && a <= b;
};

ss_Nullable$1.ge = function Nullable$ge(a, b) {
  return ss.isValue(a) && ss.isValue(b) && a >= b;
};

ss_Nullable$1.lt = function Nullable$lt(a, b) {
  return ss.isValue(a) && ss.isValue(b) && a < b;
};

ss_Nullable$1.gt = function Nullable$gt(a, b) {
  return ss.isValue(a) && ss.isValue(b) && a > b;
};

ss_Nullable$1.sub = function Nullable$sub(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a - b : null;
};

ss_Nullable$1.add = function Nullable$add(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a + b : null;
};

ss_Nullable$1.mod = function Nullable$mod(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a % b : null;
};

ss_Nullable$1.div = function Nullable$divf(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a / b : null;
};

ss_Nullable$1.mul = function Nullable$mul(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a * b : null;
};

ss_Nullable$1.band = function Nullable$band(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a & b : null;
};

ss_Nullable$1.bor = function Nullable$bor(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a | b : null;
};

ss_Nullable$1.xor = function Nullable$xor(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a ^ b : null;
};

ss_Nullable$1.shl = function Nullable$shl(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a << b : null;
};

ss_Nullable$1.srs = function Nullable$srs(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a >> b : null;
};

ss_Nullable$1.sru = function Nullable$sru(a, b) {
  return ss.isValue(a) && ss.isValue(b) ? a >>> b : null;
};

ss_Nullable$1.and = function Nullable$and(a, b) {
  if (a === true && b === true)
    return true;
  else if (a === false || b === false)
    return false;
  else
    return null;
};

ss_Nullable$1.or = function Nullable$or(a, b) {
  if (a === true || b === true)
    return true;
  else if (a === false && b === false)
    return false;
  else
    return null;
};

ss_Nullable$1.not = function Nullable$not(a) {
  return ss.isValue(a) ? !a : null;
};

ss_Nullable$1.neg = function Nullable$neg(a) {
  return ss.isValue(a) ? -a : null;
};

ss_Nullable$1.pos = function Nullable$pos(a) {
  return ss.isValue(a) ? +a : null;
};

ss_Nullable$1.cpl = function Nullable$cpl(a) {
  return ss.isValue(a) ? ~a : null;
};

ss_Nullable$1.lift = function Nullable$lift() {
  for (var i = 0; i < arguments.length; i++) {
    if (!ss.isValue(arguments[i]))
      return null;
  }
  return arguments[0].apply(null, Array.prototype.slice.call(arguments, 1));
};

///////////////////////////////////////////////////////////////////////////////
// IList

var ss_IList = function IList$() { };

ss_IList.__typeName = 'ss.IList';
ss.IList = ss_IList;
ss.initInterface(ss_IList, ss, { get_item: null, set_item: null, indexOf: null, insert: null, removeAt: null }, [ss_ICollection, ss_IEnumerable]);

ss.getItem = function ss$getItem(obj, index) {
  return obj.get_item ? obj.get_item(index) : obj[index];
}

ss.setItem = function ss$setItem(obj, index, value) {
  obj.set_item ? obj.set_item(index, value) : (obj[index] = value);
}

ss.indexOf = function ss$indexOf(obj, item) {
  var itemType = typeof(item);
  if ((!item || typeof(item.equals) !== 'function') && typeof(obj.indexOf) === 'function') {
    // use indexOf if item is null or if item does not implement an equals function
    return obj.indexOf(item);
  } else if (ss.isArrayOrTypedArray(obj)) {
    for (var i = 0; i < obj.length; i++) {
      if (ss.staticEquals(obj[i], item)) {
        return i;
      }
    }
    return -1;
  }
  else
    return obj.indexOf(item);
};

ss.insert = function ss$insert(obj, index, item) {
  if (obj.insert)
    obj.insert(index, item);
  else if (ss.isArray(obj))
    obj.splice(index, 0, item);
  else
    throw new ss_NotSupportedException();
};

ss.removeAt = function ss$removeAt(obj, index) {
  if (obj.removeAt)
    obj.removeAt(index);
  else if (ss.isArray(obj))
    obj.splice(index, 1);
  else
    throw new ss_NotSupportedException();
};

///////////////////////////////////////////////////////////////////////////////
// IDictionary

var ss_IDictionary = function IDictionary$() { };

ss_IDictionary.__typeName = 'ss.IDictionary';
ss.IDictionary = ss_IDictionary;
ss.initInterface(ss_IDictionary, ss, { get_item: null, set_item: null, get_keys: null, get_values: null, containsKey: null, add: null, remove: null, tryGetValue: null }, [ss_IEnumerable]);

///////////////////////////////////////////////////////////////////////////////
// Int32

var ss_Int32 = function Int32$() { };

ss_Int32.__typeName = 'ss.Int32';
ss.Int32 = ss_Int32;
ss.initClass(ss_Int32, ss, {}, Object, [ ss_IEquatable, ss_IComparable, ss_IFormattable ]);
ss_Int32.__class = false;

ss_Int32.isInstanceOfType = function Int32$isInstanceOfType(instance) {
  return typeof(instance) === 'number' && isFinite(instance) && Math.round(instance, 0) == instance;
};

ss_Int32.getDefaultValue = ss_Int32.createInstance = function Int32$getDefaultValue() {
  return 0;
};

ss_Int32.div = function Int32$div(a, b) {
  if (!ss.isValue(a) || !ss.isValue(b)) return null;
  if (b === 0) throw new ss_DivideByZeroException();
  return ss_Int32.trunc(a / b);
};

ss_Int32.trunc = function Int32$trunc(n) {
  return ss.isValue(n) ? (n > 0 ? Math.floor(n) : Math.ceil(n)) : null;
};

ss_Int32.tryParse = function Int32$tryParse(s, result, min, max) {
  result.$ = 0;
  if (!/^[+-]?[0-9]+$/.test(s))
    return 0;
  var n = parseInt(s, 10);
  if (n < min || n > max)
    return false;
  result.$ = n;
  return true;
};

///////////////////////////////////////////////////////////////////////////////
// MutableDateTime

var ss_JsDate = function JsDate$() { };

ss_JsDate.__typeName = 'ss.JsDate';
ss.JsDate = ss_JsDate;
ss.initClass(ss_JsDate, ss, {}, Object, [ ss_IEquatable, ss_IComparable ]);

ss_JsDate.createInstance = function JsDate$createInstance() {
    return new Date();
};

ss_JsDate.isInstanceOfType = function JsDate$isInstanceOfType(instance) {
   return instance instanceof Date;
};

///////////////////////////////////////////////////////////////////////////////
// ArrayEnumerator

var ss_ArrayEnumerator = function ArrayEnumerator$(array) {
  this._array = array;
  this._index = -1;
};
ss_ArrayEnumerator.__typeName = 'ss.ArrayEnumerator';
ss.ArrayEnumerator = ss_ArrayEnumerator;
ss.initClass(ss_ArrayEnumerator, ss, {
  moveNext: function ArrayEnumerator$moveNext() {
    this._index++;
    return (this._index < this._array.length);
  },
  reset: function ArrayEnumerator$reset() {
    this._index = -1;
  },
  current: function ArrayEnumerator$current() {
    if (this._index < 0 || this._index >= this._array.length)
      throw 'Invalid operation';
    return this._array[this._index];
  },
  dispose: function ArrayEnumerator$dispose() {
  }
}, null, [ss_IEnumerator, ss_IDisposable]);

///////////////////////////////////////////////////////////////////////////////
// ObjectEnumerator

var ss_ObjectEnumerator = function ObjectEnumerator$(o) {
  this._keys = Object.keys(o);
  this._index = -1;
  this._object = o;
};

ss_ObjectEnumerator.__typeName = 'ss.ObjectEnumerator';
ss.ObjectEnumerator = ss_ObjectEnumerator;
ss.initClass(ss_ObjectEnumerator, ss, {
  moveNext: function ObjectEnumerator$moveNext() {
    this._index++;
    return (this._index < this._keys.length);
  },
  reset: function ObjectEnumerator$reset() {
    this._index = -1;
  },
  current: function ObjectEnumerator$current() {
    if (this._index < 0 || this._index >= this._keys.length)
      throw new ss_InvalidOperationException('Invalid operation');
    var k = this._keys[this._index];
    return { key: k, value: this._object[k] };
  },
  dispose: function ObjectEnumerator$dispose() {
  }
}, null, [ss_IEnumerator, ss_IDisposable]);

///////////////////////////////////////////////////////////////////////////////
// EqualityComparer

var ss_EqualityComparer = function EqualityComparer$() {
};
ss_EqualityComparer.__typeName = 'ss.EqualityComparer';
ss.EqualityComparer = ss_EqualityComparer;
ss.initClass(ss_EqualityComparer, ss, {
  areEqual: function EqualityComparer$areEqual(x, y) {
    return ss.staticEquals(x, y);
  },
  getObjectHashCode: function EqualityComparer$getObjectHashCode(obj) {
    return ss.isValue(obj) ? ss.getHashCode(obj) : 0;
  }
}, null, [ss_IEqualityComparer]);
ss_EqualityComparer.def = new ss_EqualityComparer();


///////////////////////////////////////////////////////////////////////////////
// Comparer

var ss_Comparer = function Comparer$(f) {
  this.f = f;
};

ss_Comparer.__typeName = 'ss.Comparer';
ss.Comparer = ss_Comparer;
ss.initClass(ss_Comparer, ss, {
  compare: function Comparer$compare(x, y) {
    return this.f(x, y);
  }
}, null, [ss_IComparer]);
ss_Comparer.def = new ss_Comparer(function Comparer$defaultCompare(a, b) {
  if (!ss.isValue(a))
    return !ss.isValue(b)? 0 : -1;
  else if (!ss.isValue(b))
    return 1;
  else
    return ss.compare(a, b);
});


//#include "Dictionary.js"

///////////////////////////////////////////////////////////////////////////////
// IDisposable

var ss_IDisposable = function IDisposable$() { };
ss_IDisposable.__typeName = 'ss.IDisposable';
ss.IDisposable = ss_IDisposable;
ss.initInterface(ss_IDisposable, ss, { dispose: null });

///////////////////////////////////////////////////////////////////////////////
// StringBuilder

var ss_StringBuilder = function StringBuilder$(s) {
  this._parts = (ss.isValue(s) && s != '') ? [s] : [];
  this.length = ss.isValue(s) ? s.length : 0;
}

ss_StringBuilder.__typeName = 'ss.StringBuilder';
ss.StringBuilder = ss_StringBuilder;
ss.initClass(ss_StringBuilder, ss, {
  append: function StringBuilder$append(o) {
    if (ss.isValue(o)) {
      var s = o.toString();
      ss.add(this._parts, s);
      this.length += s.length;
    }
    return this;
  },

  appendChar: function StringBuilder$appendChar(c) {
    return this.append(String.fromCharCode(c));
  },

  appendLine: function StringBuilder$appendLine(s) {
    this.append(s);
    this.append('\r\n');
    return this;
  },

  appendLineChar: function StringBuilder$appendLineChar(c) {
    return this.appendLine(String.fromCharCode(c));
  },

  clear: function StringBuilder$clear() {
    this._parts = [];
    this.length = 0;
  },

  toString: function StringBuilder$toString() {
    return this._parts.join('');
  }
});

///////////////////////////////////////////////////////////////////////////////
// Random


///////////////////////////////////////////////////////////////////////////////
// EventArgs

var ss_EventArgs = function EventArgs$() {
}
ss_EventArgs.__typeName = 'ss.EventArgs';
ss.EventArgs = ss_EventArgs;
ss.initClass(ss_EventArgs, ss, {});

ss_EventArgs.Empty = new ss_EventArgs();

///////////////////////////////////////////////////////////////////////////////
// Exception

var ss_Exception = function Exception$(message, innerException) {
  this._message = message || 'An error occurred.';
  this._innerException = innerException || null;
  this._error = new Error();
}

ss_Exception.__typeName = 'ss.Exception';
ss.Exception = ss_Exception;
ss.initClass(ss_Exception, ss, {
  get_message: function Exception$get_message() {
    return this._message;
  },
  get_innerException: function Exception$get_innerException() {
    return this._innerException;
  },
  get_stack: function Exception$get_stack() {
    return this._error.stack;
  },
  toString: function Exception$toString() {
    var message = this._message;
    var exception = this;
    if (ss.isNullOrEmptyString(message)) {
      if (ss.isValue(ss.getInstanceType(exception)) && ss.isValue(ss.getTypeFullName(ss.getInstanceType(exception)))) {
        message = ss.getTypeFullName(ss.getInstanceType(exception));
      }
      else {
        message = '[object Exception]';
      }
    }
    return message;
  }
});

ss_Exception.wrap = function Exception$wrap(o) {
  if (ss.isInstanceOfType(o, ss_Exception)) {
    return o;
  }
  else if (o instanceof TypeError) {
    // TypeError can either be 'cannot read property blah of null/undefined' (proper NullReferenceException), or it can be eg. accessing a non-existent method of an object.
    // As long as all code is compiled, they should with a very high probability indicate the use of a null reference.
    return new ss_NullReferenceException(o.message, new ss_JsErrorException(o));
  }
  else if (o instanceof RangeError) {
    return new ss_ArgumentOutOfRangeException(null, o.message, new ss_JsErrorException(o));
  }
  else if (o instanceof Error) {
    return new ss_JsErrorException(o);
  }
  else {
    return new ss_Exception(o.toString());
  }
};

////////////////////////////////////////////////////////////////////////////////
// NotImplementedException

var ss_NotImplementedException = function NotImplementedException$(message, innerException) {
  ss_Exception.call(this, message || 'The method or operation is not implemented.', innerException);
};
ss_NotImplementedException.__typeName = 'ss.NotImplementedException';
ss.NotImplementedException = ss_NotImplementedException;
ss.initClass(ss_NotImplementedException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// NotSupportedException

var ss_NotSupportedException = function NotSupportedException$(message, innerException) {
  ss_Exception.call(this, message || 'Specified method is not supported.', innerException);
};
ss_NotSupportedException.__typeName = 'ss.NotSupportedException';
ss.NotSupportedException = ss_NotSupportedException;
ss.initClass(ss_NotSupportedException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// AggregateException

var ss_AggregateException = function AggregateException$(message, innerExceptions) {
  this.innerExceptions = ss.isValue(innerExceptions) ? ss.arrayFromEnumerable(innerExceptions) : [];
  ss_Exception.call(this, message || 'One or more errors occurred.', this.innerExceptions.length ? this.innerExceptions[0] : null);
};

ss_AggregateException.__typeName = 'ss.AggregateException';
ss.AggregateException = ss_AggregateException;
ss.initClass(ss_AggregateException, ss, {
  flatten: function  AggregateException$flatten() {
    var inner = [];
    for (var i = 0; i < this.innerExceptions.length; i++) {
      var e = this.innerExceptions[i];
      if (ss.isInstanceOfType(e, ss_AggregateException)) {
        inner.push.apply(inner, e.flatten().innerExceptions);
      }
      else {
        inner.push(e);
      }
    }
    return new ss_AggregateException(this._message, inner);
  }
}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// PromiseException

var ss_PromiseException = function PromiseException(args, message, innerException) {
  ss_Exception.call(this, message || (args.length && args[0] ? args[0].toString() : 'An error occurred'), innerException);
  this.arguments = ss.arrayClone(args);
};

ss_PromiseException.__typeName = 'ss.PromiseException';
ss.PromiseException = ss_PromiseException;
ss.initClass(ss_PromiseException, ss, {
  get_arguments: function PromiseException$get_arguments() {
    return this._arguments;
  }
}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// JsErrorException

var ss_JsErrorException = function JsErrorException$(error, message, innerException) {
  ss_Exception.call(this, message || error.message, innerException);
  this.error = error;
};
ss_JsErrorException.__typeName = 'ss.JsErrorException';
ss.JsErrorException = ss_JsErrorException;
ss.initClass(ss_JsErrorException, ss, {
  get_stack: function Exception$get_stack() {
    return this.error.stack;
  }
}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// ArgumentException

var ss_ArgumentException = function ArgumentException$(message, paramName, innerException) {
  ss_Exception.call(this, message || 'Value does not fall within the expected range.', innerException);
  this.paramName = paramName || null;
};

ss_ArgumentException.__typeName = 'ss.ArgumentException';
ss.ArgumentException = ss_ArgumentException;
ss.initClass(ss_ArgumentException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// ArgumentNullException

var ss_ArgumentNullException = function ArgumentNullException$(paramName, message, innerException) {
  if (!message) {
    message = 'Value cannot be null.';
    if (paramName)
      message += '\nParameter name: ' + paramName;
  }

  ss_ArgumentException.call(this, message, paramName, innerException);
};

ss_ArgumentNullException.__typeName = 'ss.ArgumentNullException';
ss.ArgumentNullException = ss_ArgumentNullException;
ss.initClass(ss_ArgumentNullException, ss, {}, ss_ArgumentException);

////////////////////////////////////////////////////////////////////////////////
// ArgumentNullException

var ss_ArgumentOutOfRangeException = function ArgumentOutOfRangeException$(paramName, message, innerException, actualValue) {
  if (!message) {
    message = 'Value is out of range.';
    if (paramName)
      message += '\nParameter name: ' + paramName;
  }

  ss_ArgumentException.call(this, message, paramName, innerException);
  this.actualValue = actualValue || null;
};

ss_ArgumentOutOfRangeException.__typeName = 'ss.ArgumentOutOfRangeException';
ss.ArgumentOutOfRangeException = ss_ArgumentOutOfRangeException;
ss.initClass(ss_ArgumentOutOfRangeException, ss, {}, ss_ArgumentException);

////////////////////////////////////////////////////////////////////////////////
// FormatException

var ss_FormatException = function FormatException$(message, innerException) {
  ss_Exception.call(this, message || 'Invalid format.', innerException);
};
ss_FormatException.__typeName = 'ss.FormatException';
ss.FormatException = ss_FormatException;
ss.initClass(ss_FormatException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// DivideByZeroException

var ss_DivideByZeroException = function DivideByZeroException$(message, innerException) {
  ss_Exception.call(this, message || 'Division by 0.', innerException);
};
ss_DivideByZeroException.__typeName = 'ss.DivideByZeroException';
ss.DivideByZeroException = ss_DivideByZeroException;
ss.initClass(ss_DivideByZeroException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// InvalidCastException

var ss_InvalidCastException = function InvalidCastException$(message, innerException) {
  ss_Exception.call(this, message || 'The cast is not valid.', innerException);
};
ss_InvalidCastException.__typeName = 'ss.InvalidCastException';
ss.InvalidCastException = ss_InvalidCastException;
ss.initClass(ss_InvalidCastException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// InvalidOperationException

var ss_InvalidOperationException = function InvalidOperationException$(message, innerException) {
  ss_Exception.call(this, message || 'Operation is not valid due to the current state of the object.', innerException);
};
ss_InvalidOperationException.__typeName = 'ss.InvalidOperationException';
ss.InvalidOperationException = ss_InvalidOperationException;
ss.initClass(ss_InvalidOperationException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// NullReferenceException

var ss_NullReferenceException = function NullReferenceException$(message, innerException) {
  ss_Exception.call(this, message || 'Object is null.', innerException);
};
ss_NullReferenceException.__typeName = 'ss.NullReferenceException';
ss.NullReferenceException = ss_NullReferenceException;
ss.initClass(ss_NullReferenceException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// KeyNotFoundException

var ss_KeyNotFoundException = function KeyNotFoundException$(message, innerException) {
  ss_Exception.call(this, message || 'Key not found.', innerException);
};
ss_KeyNotFoundException.__typeName = 'ss.KeyNotFoundException';
ss.KeyNotFoundException = ss_KeyNotFoundException;
ss.initClass(ss_KeyNotFoundException, ss, {}, ss_Exception);

////////////////////////////////////////////////////////////////////////////////
// InvalidOperationException

var ss_AmbiguousMatchException = function AmbiguousMatchException$(message, innerException) {
  ss_Exception.call(this, message || 'Ambiguous match.', innerException);
};
ss_AmbiguousMatchException.__typeName = 'ss.AmbiguousMatchException';
ss.AmbiguousMatchException = ss_AmbiguousMatchException;
ss.initClass(ss_AmbiguousMatchException, ss, {}, ss_Exception);

///////////////////////////////////////////////////////////////////////////////
// IteratorBlockEnumerable

var ss_IteratorBlockEnumerable = function IteratorBlockEnumerable$(getEnumerator, $this) {
  this._getEnumerator = getEnumerator;
  this._this = $this;
};

ss_IteratorBlockEnumerable.__typeName = 'ss.IteratorBlockEnumerable';
ss.IteratorBlockEnumerable = ss_IteratorBlockEnumerable;
ss.initClass(ss_IteratorBlockEnumerable, ss, {
  getEnumerator: function IteratorBlockEnumerable$getEnumerator() {
    return this._getEnumerator.call(this._this);
  }
}, null, [ss_IEnumerable]);

///////////////////////////////////////////////////////////////////////////////
// IteratorBlockEnumerator

var ss_IteratorBlockEnumerator = function IteratorBlockEnumerator$(moveNext, getCurrent, dispose, $this) {
  this._moveNext = moveNext;
  this._getCurrent = getCurrent;
  this._dispose = dispose;
  this._this = $this;
};

ss_IteratorBlockEnumerator.__typeName = 'ss.IteratorBlockEnumerator';
ss.IteratorBlockEnumerator = ss_IteratorBlockEnumerator;
ss.initClass(ss_IteratorBlockEnumerator, ss, {
  moveNext: function IteratorBlockEnumerator$moveNext() {
    try {
      return this._moveNext.call(this._this);
    }
    catch (ex) {
      if (this._dispose)
        this._dispose.call(this._this);
      throw ex;
    }
  },
  current: function IteratorBlockEnumerator$current() {
    return this._getCurrent.call(this._this);
  },
  reset: function IteratorBlockEnumerator$reset() {
    throw new ss_NotSupportedException('Reset is not supported.');
  },
  dispose: function IteratorBlockEnumerator$dispose() {
    if (this._dispose)
      this._dispose.call(this._this);
  }
}, null, [ss_IEnumerator, ss_IDisposable]);


///////////////////////////////////////////////////////////////////////////////
// Lazy

var ss_Lazy = function Lazy$(valueFactory) {
  this._valueFactory = valueFactory;
  this.isValueCreated = false;
};
ss_Lazy.__typeName = 'ss.Lazy';
ss.Lazy = ss_Lazy;
ss.initClass(ss_Lazy, ss, {
  value: function Lazy$value() {
    if (!this.isValueCreated) {
      this._value = this._valueFactory();
      delete this._valueFactory;
      this.isValueCreated = true;
    }
    return this._value;
  }
});


///////////////////////////////////////////////////////////////////////////////
// Task


////////////////////////////////////////////////////////////////////////////////
// TaskStatus


///////////////////////////////////////////////////////////////////////////////
// TaskCompletionSource


///////////////////////////////////////////////////////////////////////////////
// CancelEventArgs


///////////////////////////////////////////////////////////////////////////////
// Guid


////////////////////////////////////////////////////////////////////////////////
// IE8 shims
////////////////////////////////////////////////////////////////////////////////

if (typeof(global.HTMLElement) === 'undefined') {
  global.HTMLElement = Element;
}

if (typeof(global.MessageEvent) === 'undefined') {
  global.MessageEvent = Event;
}

// polyfill for IE8 not having Date.now.
Date.now = Date.now || function() { return +new Date; };

////////////////////////////////////////////////////////////////////////////////
// Global Registration
////////////////////////////////////////////////////////////////////////////////

global.ss = ss;
})(global);

var ss = global.ss;
var HTMLElement = global.HTMLElement;
var MessageEvent = global.MessageEvent;

/*! BEGIN CoreSlim */


(function() {
	'dont use strict';
	var $asm = {};
	global.tab = global.tab || {};
	ss.initAssembly($asm, 'tabcoreslim');
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.CoreSlim.EscapingUtil
	var $tab_EscapingUtil = function() {
	};
	$tab_EscapingUtil.__typeName = 'tab.EscapingUtil';
	$tab_EscapingUtil.escapeHtml = function EscapingUtil$EscapeHtml(html) {
		var escaped = ss.coalesce(html, '');
		escaped = escaped.replace(new RegExp('&', 'g'), '&amp;');
		escaped = escaped.replace(new RegExp('<', 'g'), '&lt;');
		escaped = escaped.replace(new RegExp('>', 'g'), '&gt;');
		escaped = escaped.replace(new RegExp('"', 'g'), '&quot;');
		escaped = escaped.replace(new RegExp("'", 'g'), '&#39;');
		escaped = escaped.replace(new RegExp('/', 'g'), '&#47;');
		return escaped;
	};
	global.tab.EscapingUtil = $tab_EscapingUtil;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Core.ScriptEx
	var $tab_ScriptEx = function() {
	};
	$tab_ScriptEx.__typeName = 'tab.ScriptEx';
	global.tab.ScriptEx = $tab_ScriptEx;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.CoreSlim.WindowHelper
	var $tab_WindowHelper = function(window) {
		this.$window = null;
		this.$window = window;
	};
	$tab_WindowHelper.__typeName = 'tab.WindowHelper';
	$tab_WindowHelper.get_windowSelf = function WindowHelper$get_WindowSelf() {
		return window.self;
	};
	$tab_WindowHelper.get_selection = function WindowHelper$get_Selection() {
		if (typeof(window['getSelection']) === 'function') {
			return window.getSelection();
		}
		else if (typeof(document['getSelection']) === 'function') {
			return document.getSelection();
		}
		return null;
	};
	$tab_WindowHelper.close = function WindowHelper$Close(window) {
		window.close();
	};
	$tab_WindowHelper.getOpener = function WindowHelper$GetOpener(window) {
		return window.opener;
	};
	$tab_WindowHelper.getLocation = function WindowHelper$GetLocation(window) {
		return window.location;
	};
	$tab_WindowHelper.getPathAndSearch = function WindowHelper$GetPathAndSearch(window) {
		return window.location.pathname + window.location.search;
	};
	$tab_WindowHelper.setLocationHref = function WindowHelper$SetLocationHref(window, href) {
		window.location.href = href;
	};
	$tab_WindowHelper.locationReplace = function WindowHelper$LocationReplace(window, url) {
		window.location.replace(url);
	};
	$tab_WindowHelper.open = function WindowHelper$Open(href, target, options) {
		return window.open(href, target, options);
	};
	$tab_WindowHelper.reload = function WindowHelper$Reload(w, forceGet) {
		w.location.reload(forceGet);
	};
	$tab_WindowHelper.requestAnimationFrame = function WindowHelper$RequestAnimationFrame(action) {
		return $tab_WindowHelper.$requestAnimationFrameFunc(action);
	};
	$tab_WindowHelper.cancelAnimationFrame = function WindowHelper$CancelAnimationFrame(animationId) {
		if (ss.isValue(animationId)) {
			$tab_WindowHelper.$cancelAnimationFrameFunc(animationId);
		}
	};
	$tab_WindowHelper.setTimeout = function WindowHelper$SetTimeout(callback, milliseconds) {
		return window.setTimeout(callback, milliseconds);
	};
	$tab_WindowHelper.addListener = function WindowHelper$AddListener(windowParam, eventName, messageListener) {
		if ('addEventListener' in windowParam) {
			windowParam.addEventListener(eventName, messageListener, false);
		}
		else {
			windowParam.attachEvent('on' + eventName, messageListener);
		}
	};
	$tab_WindowHelper.removeListener = function WindowHelper$RemoveListener(window, eventName, messageListener) {
		if ('removeEventListener' in window) {
			window.removeEventListener(eventName, messageListener, false);
		}
		else {
			window.detachEvent('on' + eventName, messageListener);
		}
	};
	$tab_WindowHelper.$setDefaultRequestAnimationFrameImpl = function WindowHelper$SetDefaultRequestAnimationFrameImpl() {
		var lastTime = 0;
		$tab_WindowHelper.$requestAnimationFrameFunc = function(callback) {
			var curTime = (new Date()).getTime();
			var timeToCall = Math.max(0, 16 - (curTime - lastTime));
			lastTime = curTime + timeToCall;
			var id = window.setTimeout(callback, timeToCall);
			return id;
		};
	};
	$tab_WindowHelper.clearSelection = function WindowHelper$ClearSelection() {
		var selection = $tab_WindowHelper.get_selection();
		if (ss.isValue(selection)) {
			if (typeof(selection['removeAllRanges']) === 'function') {
				selection.removeAllRanges();
			}
			else if (typeof(selection['empty']) === 'function') {
				selection['empty']();
			}
		}
	};
	global.tab.WindowHelper = $tab_WindowHelper;
	ss.initClass($tab_EscapingUtil, $asm, {});
	ss.initClass($tab_ScriptEx, $asm, {});
	ss.initClass($tab_WindowHelper, $asm, {
		get_pageXOffset: function WindowHelper$get_PageXOffset() {
			return $tab_WindowHelper.$pageXOffsetFunc(this.$window);
		},
		get_pageYOffset: function WindowHelper$get_PageYOffset() {
			return $tab_WindowHelper.$pageYOffsetFunc(this.$window);
		},
		get_clientWidth: function WindowHelper$get_ClientWidth() {
			return $tab_WindowHelper.$clientWidthFunc(this.$window);
		},
		get_clientHeight: function WindowHelper$get_ClientHeight() {
			return $tab_WindowHelper.$clientHeightFunc(this.$window);
		},
		get_innerWidth: function WindowHelper$get_InnerWidth() {
			return $tab_WindowHelper.$innerWidthFunc(this.$window);
		},
		get_outerWidth: function WindowHelper$get_OuterWidth() {
			return $tab_WindowHelper.$outerWidthFunc(this.$window);
		},
		get_innerHeight: function WindowHelper$get_InnerHeight() {
			return $tab_WindowHelper.$innerHeightFunc(this.$window);
		},
		get_outerHeight: function WindowHelper$get_OuterHeight() {
			return $tab_WindowHelper.$outerHeightFunc(this.$window);
		},
		get_screenLeft: function WindowHelper$get_ScreenLeft() {
			return $tab_WindowHelper.$screenLeftFunc(this.$window);
		},
		get_screenTop: function WindowHelper$get_ScreenTop() {
			return $tab_WindowHelper.$screenTopFunc(this.$window);
		},
		isQuirksMode: function WindowHelper$IsQuirksMode() {
			return document.compatMode === 'BackCompat';
		}
	});
	(function() {
		$tab_WindowHelper.$innerWidthFunc = null;
		$tab_WindowHelper.$innerHeightFunc = null;
		$tab_WindowHelper.$clientWidthFunc = null;
		$tab_WindowHelper.$clientHeightFunc = null;
		$tab_WindowHelper.$pageXOffsetFunc = null;
		$tab_WindowHelper.$pageYOffsetFunc = null;
		$tab_WindowHelper.$screenLeftFunc = null;
		$tab_WindowHelper.$screenTopFunc = null;
		$tab_WindowHelper.$outerWidthFunc = null;
		$tab_WindowHelper.$outerHeightFunc = null;
		$tab_WindowHelper.$requestAnimationFrameFunc = null;
		$tab_WindowHelper.$cancelAnimationFrameFunc = null;
		if ('innerWidth' in window) {
			$tab_WindowHelper.$innerWidthFunc = function(w) {
				return w.innerWidth;
			};
		}
		else {
			$tab_WindowHelper.$innerWidthFunc = function(w1) {
				return w1.document.documentElement.offsetWidth;
			};
		}
		if ('outerWidth' in window) {
			$tab_WindowHelper.$outerWidthFunc = function(w2) {
				return w2.outerWidth;
			};
		}
		else {
			$tab_WindowHelper.$outerWidthFunc = $tab_WindowHelper.$innerWidthFunc;
		}
		if ('innerHeight' in window) {
			$tab_WindowHelper.$innerHeightFunc = function(w3) {
				return w3.innerHeight;
			};
		}
		else {
			$tab_WindowHelper.$innerHeightFunc = function(w4) {
				return w4.document.documentElement.offsetHeight;
			};
		}
		if ('outerHeight' in window) {
			$tab_WindowHelper.$outerHeightFunc = function(w5) {
				return w5.outerHeight;
			};
		}
		else {
			$tab_WindowHelper.$outerHeightFunc = $tab_WindowHelper.$innerHeightFunc;
		}
		if ('clientWidth' in window) {
			$tab_WindowHelper.$clientWidthFunc = function(w6) {
				return w6['clientWidth'];
			};
		}
		else {
			$tab_WindowHelper.$clientWidthFunc = function(w7) {
				return w7.document.documentElement.clientWidth;
			};
		}
		if ('clientHeight' in window) {
			$tab_WindowHelper.$clientHeightFunc = function(w8) {
				return w8['clientHeight'];
			};
		}
		else {
			$tab_WindowHelper.$clientHeightFunc = function(w9) {
				return w9.document.documentElement.clientHeight;
			};
		}
		if (ss.isValue(window.self.pageXOffset)) {
			$tab_WindowHelper.$pageXOffsetFunc = function(w10) {
				return w10.pageXOffset;
			};
		}
		else {
			$tab_WindowHelper.$pageXOffsetFunc = function(w11) {
				return w11.document.documentElement.scrollLeft;
			};
		}
		if (ss.isValue(window.self.pageYOffset)) {
			$tab_WindowHelper.$pageYOffsetFunc = function(w12) {
				return w12.pageYOffset;
			};
		}
		else {
			$tab_WindowHelper.$pageYOffsetFunc = function(w13) {
				return w13.document.documentElement.scrollTop;
			};
		}
		if ('screenLeft' in window) {
			$tab_WindowHelper.$screenLeftFunc = function(w14) {
				return ss.unbox(ss.cast(w14.screenLeft, ss.Int32));
			};
		}
		else {
			$tab_WindowHelper.$screenLeftFunc = function(w15) {
				return w15.screenX;
			};
		}
		if ('screenTop' in window) {
			$tab_WindowHelper.$screenTopFunc = function(w16) {
				return ss.unbox(ss.cast(w16.screenTop, ss.Int32));
			};
		}
		else {
			$tab_WindowHelper.$screenTopFunc = function(w17) {
				return w17.screenY;
			};
		}
		{
			var DefaultRequestName = 'requestAnimationFrame';
			var DefaultCancelName = 'cancelAnimationFrame';
			var vendors = ['ms', 'moz', 'webkit', 'o'];
			var requestFuncName = null;
			var cancelFuncName = null;
			if (DefaultRequestName in window) {
				requestFuncName = DefaultRequestName;
			}
			if (DefaultCancelName in window) {
				cancelFuncName = DefaultCancelName;
			}
			for (var ii = 0; ii < vendors.length && (ss.isNullOrUndefined(requestFuncName) || ss.isNullOrUndefined(cancelFuncName)); ++ii) {
				var vendor = vendors[ii];
				var funcName = vendor + 'RequestAnimationFrame';
				if (ss.isNullOrUndefined(requestFuncName) && funcName in window) {
					requestFuncName = funcName;
				}
				if (ss.isNullOrUndefined(cancelFuncName)) {
					funcName = vendor + 'CancelAnimationFrame';
					if (funcName in window) {
						cancelFuncName = funcName;
					}
					funcName = vendor + 'CancelRequestAnimationFrame';
					if (funcName in window) {
						cancelFuncName = funcName;
					}
				}
			}
			if (ss.isValue(requestFuncName)) {
				$tab_WindowHelper.$requestAnimationFrameFunc = function(callback) {
					return window[requestFuncName](callback);
				};
			}
			else {
				$tab_WindowHelper.$setDefaultRequestAnimationFrameImpl();
			}
			if (ss.isValue(cancelFuncName)) {
				$tab_WindowHelper.$cancelAnimationFrameFunc = function(animationId) {
					window[cancelFuncName](animationId);
				};
			}
			else {
				$tab_WindowHelper.$cancelAnimationFrameFunc = function(id) {
					window.clearTimeout(id);
				};
			}
		}
	})();
})();

// END CoreSlim

var tab = global.tab;


/*! API */
(function() {
	'dont use strict';
	var $asm = {};
	global.tab = global.tab || {};
	global.tableauSoftware = global.tableauSoftware || {};
	ss.initAssembly($asm, 'Tableau.JavaScript.Vql.Api');
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.CrossDomainMessageRouter
	var $tab_$CrossDomainMessageRouter = function() {
		this.$nextHandlerId = 0;
		this.$handlers = {};
		this.$commandCallbacks = {};
		this.$customViewLoadCallbacks = {};
		this.$commandReturnAfterStateReadyQueues = {};
		if ($tab__Utility.hasWindowAddEventListener()) {
			window.addEventListener('message', ss.mkdel(this, this.$handleCrossDomainMessage), false);
		}
		else if ($tab__Utility.hasDocumentAttachEvent()) {
			var handler = ss.mkdel(this, this.$handleCrossDomainMessage);
			document.attachEvent('onmessage', handler);
			window.attachEvent('onmessage', handler);
		}
		else {
			window.onmessage = ss.mkdel(this, this.$handleCrossDomainMessage);
		}
		this.$nextHandlerId = 0;
	};
	$tab_$CrossDomainMessageRouter.__typeName = 'tab.$CrossDomainMessageRouter';
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.CustomViewEventContext
	var $tab_$CustomViewEventContext = function(workbook, customViewImpl) {
		this.$customViewImpl = null;
		$tab_EventContext.call(this, workbook, null);
		this.$customViewImpl = customViewImpl;
	};
	$tab_$CustomViewEventContext.__typeName = 'tab.$CustomViewEventContext';
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DashboardZoneInfo
	var $tab_$DashboardZoneInfo = function() {
	};
	$tab_$DashboardZoneInfo.__typeName = 'tab.$DashboardZoneInfo';
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DeferredUtil
	var $tab_$DeferredUtil = function() {
	};
	$tab_$DeferredUtil.__typeName = 'tab.$DeferredUtil';
	$tab_$DeferredUtil.$coerceToTrustedPromise = function DeferredUtil$CoerceToTrustedPromise(promiseOrValue) {
		var promise;
		if (promiseOrValue instanceof tableauSoftware.Promise) {
			promise = ss.cast(promiseOrValue, $tab__PromiseImpl);
		}
		else {
			if (ss.isValue(promiseOrValue) && typeof(promiseOrValue['valueOf']) === 'function') {
				promiseOrValue = promiseOrValue['valueOf']();
			}
			if ($tab_$DeferredUtil.$isPromise(promiseOrValue)) {
				var deferred = new $tab__DeferredImpl();
				ss.cast(promiseOrValue, $tab__PromiseImpl).then(ss.mkdel(deferred, deferred.resolve), ss.mkdel(deferred, deferred.reject));
				promise = deferred.get_promise();
			}
			else {
				promise = $tab_$DeferredUtil.$resolved(promiseOrValue);
			}
		}
		return promise;
	};
	$tab_$DeferredUtil.$reject = function DeferredUtil$Reject(promiseOrValue) {
		return $tab_$DeferredUtil.$coerceToTrustedPromise(promiseOrValue).then(function(value) {
			return $tab_$DeferredUtil.$rejected(ss.cast(value, ss.Exception));
		}, null);
	};
	$tab_$DeferredUtil.$resolved = function DeferredUtil$Resolved(value) {
		var p = new $tab__PromiseImpl(function(callback, errback) {
			try {
				return $tab_$DeferredUtil.$coerceToTrustedPromise((ss.isValue(callback) ? callback(value) : value));
			}
			catch ($t1) {
				var e = ss.Exception.wrap($t1);
				return $tab_$DeferredUtil.$rejected(e);
			}
		});
		return p;
	};
	$tab_$DeferredUtil.$rejected = function DeferredUtil$Rejected(reason) {
		var p = new $tab__PromiseImpl(function(callback, errback) {
			try {
				return (ss.isValue(errback) ? $tab_$DeferredUtil.$coerceToTrustedPromise(errback(reason)) : $tab_$DeferredUtil.$rejected(reason));
			}
			catch ($t1) {
				var e = ss.Exception.wrap($t1);
				return $tab_$DeferredUtil.$rejected(e);
			}
		});
		return p;
	};
	$tab_$DeferredUtil.$isPromise = function DeferredUtil$IsPromise(promiseOrValue) {
		return ss.isValue(promiseOrValue) && typeof(promiseOrValue['then']) === 'function';
	};
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DoNothingCrossDomainHandler
	var $tab_$DoNothingCrossDomainHandler = function() {
		this.$hostId = null;
		this.$1$CustomViewsListLoadField = null;
		this.$1$StateReadyForQueryField = null;
	};
	$tab_$DoNothingCrossDomainHandler.__typeName = 'tab.$DoNothingCrossDomainHandler';
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.FilterEventContext
	var $tab_$FilterEventContext = function(workbookImpl, worksheetImpl, fieldFieldName, filterCaption) {
		this.$fieldFieldName = null;
		this.$filterCaption = null;
		$tab_EventContext.call(this, workbookImpl, worksheetImpl);
		this.$fieldFieldName = fieldFieldName;
		this.$filterCaption = filterCaption;
	};
	$tab_$FilterEventContext.__typeName = 'tab.$FilterEventContext';
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.HighlightEventContext
	var $tab_$HighlightEventContext = function(workbookImpl, worksheetImpl) {
		$tab_EventContext.call(this, workbookImpl, worksheetImpl);
	};
	$tab_$HighlightEventContext.__typeName = 'tab.$HighlightEventContext';
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.MarkImpl
	var $tab_$MarkImpl = function(tupleIdOrPairs) {
		this.$clonedPairs = null;
		this.$collection = new tab._Collection();
		this.$tupleId = 0;
		if ($tab__jQueryShim.isArray(tupleIdOrPairs)) {
			var pairArr = tupleIdOrPairs;
			for (var i = 0; i < pairArr.length; i++) {
				var pair = pairArr[i];
				if (!ss.isValue(pair.fieldName)) {
					throw $tab__TableauException.createInvalidParameter('pair.fieldName');
				}
				if (!ss.isValue(pair.value)) {
					throw $tab__TableauException.createInvalidParameter('pair.value');
				}
				var p = new $tableauSoftware_Pair(pair.fieldName, pair.value);
				this.$collection._add(p.fieldName, p);
			}
		}
		else {
			this.$tupleId = tupleIdOrPairs;
		}
	};
	$tab_$MarkImpl.__typeName = 'tab.$MarkImpl';
	$tab_$MarkImpl.$processActiveMarks = function MarkImpl$ProcessActiveMarks(marksPresModel) {
		var marks = new tab._Collection();
		if (ss.isNullOrUndefined(marksPresModel) || $tab__Utility.isNullOrEmpty(marksPresModel.marks)) {
			return marks;
		}
		for (var $t1 = 0; $t1 < marksPresModel.marks.length; $t1++) {
			var markPresModel = marksPresModel.marks[$t1];
			var tupleId = markPresModel.tupleId;
			var mark = new $tableauSoftware_Mark(tupleId);
			marks._add(tupleId.toString(), mark);
			for (var $t2 = 0; $t2 < markPresModel.pairs.length; $t2++) {
				var pairPresModel = markPresModel.pairs[$t2];
				var value = $tab__Utility.convertRawValue(pairPresModel.value, pairPresModel.valueDataType);
				var pair = new $tableauSoftware_Pair(pairPresModel.fieldName, value);
				pair.formattedValue = pairPresModel.formattedValue;
				if (!mark.$impl.get_$pairs()._has(pair.fieldName)) {
					mark.$impl.$addPair(pair);
				}
			}
		}
		return marks;
	};
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.MarksEventContext
	var $tab_$MarksEventContext = function(workbookImpl, worksheetImpl) {
		$tab_EventContext.call(this, workbookImpl, worksheetImpl);
	};
	$tab_$MarksEventContext.__typeName = 'tab.$MarksEventContext';
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ParameterEventContext
	var $tab_$ParameterEventContext = function(workbookImpl, parameterName) {
		this.$parameterName = null;
		$tab_EventContext.call(this, workbookImpl, null);
		this.$parameterName = parameterName;
	};
	$tab_$ParameterEventContext.__typeName = 'tab.$ParameterEventContext';
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ParameterImpl
	var $tab_$ParameterImpl = function(pm) {
		this.$parameter = null;
		this.$name = null;
		this.$currentValue = null;
		this.$dataType = null;
		this.$allowableValuesType = null;
		this.$allowableValues = null;
		this.$minValue = null;
		this.$maxValue = null;
		this.$stepSize = null;
		this.$dateStepPeriod = null;
		this.$name = pm.name;
		this.$currentValue = $tab__Utility.getDataValue(pm.currentValue);
		this.$dataType = $tab_ApiEnumConverter.convertParameterDataType(pm.dataType);
		this.$allowableValuesType = $tab_ApiEnumConverter.convertParameterAllowableValuesType(pm.allowableValuesType);
		if (ss.isValue(pm.allowableValues) && this.$allowableValuesType === 'list') {
			this.$allowableValues = [];
			for (var $t1 = 0; $t1 < pm.allowableValues.length; $t1++) {
				var adv = pm.allowableValues[$t1];
				this.$allowableValues.push($tab__Utility.getDataValue(adv));
			}
		}
		if (this.$allowableValuesType === 'range') {
			this.$minValue = $tab__Utility.getDataValue(pm.minValue);
			this.$maxValue = $tab__Utility.getDataValue(pm.maxValue);
			this.$stepSize = pm.stepSize;
			if ((this.$dataType === 'date' || this.$dataType === 'datetime') && ss.isValue(this.$stepSize) && ss.isValue(pm.dateStepPeriod)) {
				this.$dateStepPeriod = $tab_ApiEnumConverter.convertPeriodType(pm.dateStepPeriod);
			}
		}
	};
	$tab_$ParameterImpl.__typeName = 'tab.$ParameterImpl';
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.PublicEnums
	var $tab_$PublicEnums = function() {
	};
	$tab_$PublicEnums.__typeName = 'tab.$PublicEnums';
	$tab_$PublicEnums.$tryNormalizeEnum = function(T) {
		return function PublicEnums$TryNormalizeEnum(rawValue, value) {
			if (ss.isValue(rawValue)) {
				var lookup = rawValue.toString().toUpperCase();
				var $t1 = ss.Enum.getValues(T);
				for (var $t2 = 0; $t2 < $t1.length; $t2++) {
					var name = $t1[$t2];
					var compareValue = name.toUpperCase();
					if (ss.referenceEquals(lookup, compareValue)) {
						value.$ = name;
						return true;
					}
				}
			}
			value.$ = ss.getDefaultValue(T);
			return false;
		};
	};
	$tab_$PublicEnums.$normalizeEnum = function(T) {
		return function PublicEnums$NormalizeEnum(rawValue, paramName) {
			var value = {};
			if (!$tab_$PublicEnums.$tryNormalizeEnum(T).call(null, rawValue, value)) {
				throw $tab__TableauException.createInvalidParameter(paramName);
			}
			return value.$;
		};
	};
	$tab_$PublicEnums.$isValidEnum = function(T) {
		return function PublicEnums$IsValidEnum(rawValue) {
			var value = {};
			var valid = $tab_$PublicEnums.$tryNormalizeEnum(T).call(null, rawValue, value);
			return valid;
		};
	};
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiBootstrap
	var $tab__ApiBootstrap = function() {
	};
	$tab__ApiBootstrap.__typeName = 'tab._ApiBootstrap';
	$tab__ApiBootstrap.initialize = function ApiBootstrap$Initialize() {
		$tab__ApiObjectRegistry.registerCrossDomainMessageRouter(function() {
			return new $tab_$CrossDomainMessageRouter();
		});
	};
	global.tab._ApiBootstrap = $tab__ApiBootstrap;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiCommand
	var $tab__ApiCommand = function(name, commandId, hostId, parameters) {
		this.$1$NameField = null;
		this.$1$HostIdField = null;
		this.$1$CommandIdField = null;
		this.$1$ParametersField = null;
		this.set_name(name);
		this.set_commandId(commandId);
		this.set_hostId(hostId);
		this.set_parameters(parameters);
	};
	$tab__ApiCommand.__typeName = 'tab._ApiCommand';
	$tab__ApiCommand.generateNextCommandId = function ApiCommand$GenerateNextCommandId() {
		var commandId = 'cmd' + $tab__ApiCommand.$nextCommandId;
		$tab__ApiCommand.$nextCommandId++;
		return commandId;
	};
	$tab__ApiCommand.parse = function ApiCommand$Parse(serialized) {
		var name;
		var index = serialized.indexOf(String.fromCharCode(44));
		if (index < 0) {
			name = ss.cast(serialized, String);
			return new $tab__ApiCommand(name, null, null, null);
		}
		name = ss.cast(serialized.substr(0, index), String);
		var sourceId;
		var secondPart = serialized.substr(index + 1);
		index = secondPart.indexOf(String.fromCharCode(44));
		if (index < 0) {
			sourceId = secondPart;
			return new $tab__ApiCommand(name, sourceId, null, null);
		}
		sourceId = secondPart.substr(0, index);
		var hostId;
		var thirdPart = secondPart.substr(index + 1);
		index = thirdPart.indexOf(String.fromCharCode(44));
		if (index < 0) {
			hostId = thirdPart;
			return new $tab__ApiCommand(name, sourceId, hostId, null);
		}
		hostId = thirdPart.substr(0, index);
		var parameters = thirdPart.substr(index + 1);
		$tab__ApiCommand.lastResponseMessage = serialized;
		if (name === 'api.GetClientInfoCommand') {
			$tab__ApiCommand.lastClientInfoResponseMessage = serialized;
		}
		return new $tab__ApiCommand(name, sourceId, hostId, parameters);
	};
	global.tab._ApiCommand = $tab__ApiCommand;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiObjectRegistry
	var $tab__ApiObjectRegistry = function() {
	};
	$tab__ApiObjectRegistry.__typeName = 'tab._ApiObjectRegistry';
	$tab__ApiObjectRegistry.registerCrossDomainMessageRouter = function ApiObjectRegistry$RegisterCrossDomainMessageRouter(objectCreationFunc) {
		return $tab__ApiObjectRegistry.$registerType($tab_ICrossDomainMessageRouter).call(null, objectCreationFunc);
	};
	$tab__ApiObjectRegistry.getCrossDomainMessageRouter = function ApiObjectRegistry$GetCrossDomainMessageRouter() {
		return $tab__ApiObjectRegistry.$getSingleton($tab_ICrossDomainMessageRouter).call(null);
	};
	$tab__ApiObjectRegistry.disposeCrossDomainMessageRouter = function ApiObjectRegistry$DisposeCrossDomainMessageRouter() {
		$tab__ApiObjectRegistry.$clearSingletonInstance($tab_ICrossDomainMessageRouter).call(null);
	};
	$tab__ApiObjectRegistry.$registerType = function(T) {
		return function ApiObjectRegistry$RegisterType(objectCreationFunc) {
			if (ss.isNullOrUndefined($tab__ApiObjectRegistry.$creationRegistry)) {
				$tab__ApiObjectRegistry.$creationRegistry = {};
			}
			var interfaceTypeName = ss.getTypeFullName(T);
			var previousType = $tab__ApiObjectRegistry.$creationRegistry[interfaceTypeName];
			$tab__ApiObjectRegistry.$creationRegistry[interfaceTypeName] = objectCreationFunc;
			return previousType;
		};
	};
	$tab__ApiObjectRegistry.$createType = function(T) {
		return function ApiObjectRegistry$CreateType() {
			if (ss.isNullOrUndefined($tab__ApiObjectRegistry.$creationRegistry)) {
				throw $tab__TableauException.createInternalError('No types registered');
			}
			var interfaceTypeName = ss.getTypeFullName(T);
			var creationFunc = $tab__ApiObjectRegistry.$creationRegistry[interfaceTypeName];
			if (ss.isNullOrUndefined(creationFunc)) {
				throw $tab__TableauException.createInternalError("No creation function has been registered for interface type '" + interfaceTypeName + "'.");
			}
			var instance = creationFunc();
			return instance;
		};
	};
	$tab__ApiObjectRegistry.$getSingleton = function(T) {
		return function ApiObjectRegistry$GetSingleton() {
			if (ss.isNullOrUndefined($tab__ApiObjectRegistry.$singletonInstanceRegistry)) {
				$tab__ApiObjectRegistry.$singletonInstanceRegistry = {};
			}
			var interfaceTypeName = ss.getTypeFullName(T);
			var instance = ss.cast($tab__ApiObjectRegistry.$singletonInstanceRegistry[interfaceTypeName], T);
			if (ss.isNullOrUndefined(instance)) {
				instance = $tab__ApiObjectRegistry.$createType(T).call(null);
				$tab__ApiObjectRegistry.$singletonInstanceRegistry[interfaceTypeName] = instance;
			}
			return instance;
		};
	};
	$tab__ApiObjectRegistry.$clearSingletonInstance = function(T) {
		return function ApiObjectRegistry$ClearSingletonInstance() {
			if (ss.isNullOrUndefined($tab__ApiObjectRegistry.$singletonInstanceRegistry)) {
				return null;
			}
			var interfaceTypeName = ss.getTypeFullName(T);
			var instance = ss.cast($tab__ApiObjectRegistry.$singletonInstanceRegistry[interfaceTypeName], T);
			delete $tab__ApiObjectRegistry.$singletonInstanceRegistry[interfaceTypeName];
			return instance;
		};
	};
	global.tab._ApiObjectRegistry = $tab__ApiObjectRegistry;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiServerNotification
	var $tab__ApiServerNotification = function(workbookName, worksheetName, data) {
		this.$workbookName = null;
		this.$worksheetName = null;
		this.$data = null;
		this.$workbookName = workbookName;
		this.$worksheetName = worksheetName;
		this.$data = data;
	};
	$tab__ApiServerNotification.__typeName = 'tab._ApiServerNotification';
	$tab__ApiServerNotification.deserialize = function ApiServerNotification$Deserialize(json) {
		var param = JSON.parse(json);
		var workbookName = ss.cast(param['api.workbookName'], String);
		var worksheetName = ss.cast(param['api.worksheetName'], String);
		var data = param['api.commandData'];
		return new $tab__ApiServerNotification(workbookName, worksheetName, data);
	};
	global.tab._ApiServerNotification = $tab__ApiServerNotification;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiServerResultParser
	var $tab__ApiServerResultParser = function(serverResult) {
		this.$commandResult = null;
		this.$commandData = null;
		var param = JSON.parse(serverResult);
		this.$commandResult = ss.cast(param['api.commandResult'], String);
		this.$commandData = param['api.commandData'];
	};
	$tab__ApiServerResultParser.__typeName = 'tab._ApiServerResultParser';
	global.tab._ApiServerResultParser = $tab__ApiServerResultParser;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DoNotUseCollection
	var $tab__CollectionImpl = function() {
		this.$items = [];
		this.$itemMap = {};
	};
	$tab__CollectionImpl.__typeName = 'tab._CollectionImpl';
	global.tab._CollectionImpl = $tab__CollectionImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ColumnImpl
	var $tab__ColumnImpl = function(fieldName, dataType, isReferenced, index) {
		this.$fieldName = null;
		this.$dataType = null;
		this.$isReferenced = false;
		this.$index = 0;
		$tab__Param.verifyString(fieldName, 'Column Field Name');
		this.$fieldName = fieldName;
		this.$dataType = dataType;
		this.$isReferenced = ss.coalesce(isReferenced, false);
		this.$index = index;
	};
	$tab__ColumnImpl.__typeName = 'tab._ColumnImpl';
	global.tab._ColumnImpl = $tab__ColumnImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.CustomViewImpl
	var $tab__CustomViewImpl = function(workbookImpl, name, messagingOptions) {
		this.$customView = null;
		this.$presModel = null;
		this.$workbookImpl = null;
		this.$messagingOptions = null;
		this.$name = null;
		this.$ownerName = null;
		this.$url = null;
		this.$isPublic = false;
		this.$isDefault = false;
		this.$isStale = false;
		this.$workbookImpl = workbookImpl;
		this.$name = name;
		this.$messagingOptions = messagingOptions;
		this.$isPublic = false;
		this.$isDefault = false;
		this.$isStale = false;
	};
	$tab__CustomViewImpl.__typeName = 'tab._CustomViewImpl';
	$tab__CustomViewImpl._getAsync = function CustomViewImpl$GetAsync(eventContext) {
		var deferred = new tab._Deferred();
		deferred.resolve(eventContext.get__customViewImpl().get_$customView());
		return deferred.get_promise();
	};
	$tab__CustomViewImpl._createNew = function CustomViewImpl$CreateNew(workbookImpl, messagingOptions, apiPresModel, defaultId) {
		var cv = new $tab__CustomViewImpl(workbookImpl, apiPresModel.name, messagingOptions);
		cv.$isPublic = apiPresModel.isPublic;
		cv.$url = apiPresModel.url;
		cv.$ownerName = apiPresModel.owner.friendlyName;
		cv.$isDefault = ss.isValue(defaultId) && ss.unbox(defaultId) === apiPresModel.id;
		cv.$presModel = apiPresModel;
		return cv;
	};
	$tab__CustomViewImpl._saveNewAsync = function CustomViewImpl$SaveNewAsync(workbookImpl, messagingOptions, name) {
		var deferred = new tab._Deferred();
		var param = {};
		param['api.customViewName'] = name;
		var returnHandler = $tab__CustomViewImpl.$createCustomViewCommandReturnHandler('api.SaveNewCustomViewCommand', deferred, function(result) {
			$tab__CustomViewImpl._processCustomViewUpdate(workbookImpl, messagingOptions, result, true);
			var newView = null;
			if (ss.isValue(workbookImpl.get_$updatedCustomViews())) {
				newView = workbookImpl.get_$updatedCustomViews().get_item(0);
			}
			deferred.resolve(newView);
		});
		messagingOptions.sendCommand(Object).call(messagingOptions, param, returnHandler);
		return deferred.get_promise();
	};
	$tab__CustomViewImpl._showCustomViewAsync = function CustomViewImpl$ShowCustomViewAsync(workbookImpl, messagingOptions, serverCustomizedView) {
		var deferred = new tab._Deferred();
		var param = {};
		if (ss.isValue(serverCustomizedView)) {
			param['api.customViewParam'] = serverCustomizedView;
		}
		var returnHandler = $tab__CustomViewImpl.$createCustomViewCommandReturnHandler('api.ShowCustomViewCommand', deferred, function(result) {
			var cv = workbookImpl.get_activeCustomView();
			deferred.resolve(cv);
		});
		messagingOptions.sendCommand(Object).call(messagingOptions, param, returnHandler);
		return deferred.get_promise();
	};
	$tab__CustomViewImpl._makeCurrentCustomViewDefaultAsync = function CustomViewImpl$MakeCurrentCustomViewDefaultAsync(workbookImpl, messagingOptions) {
		var deferred = new tab._Deferred();
		var param = {};
		var returnHandler = $tab__CustomViewImpl.$createCustomViewCommandReturnHandler('api.MakeCurrentCustomViewDefaultCommand', deferred, function(result) {
			var cv = workbookImpl.get_activeCustomView();
			deferred.resolve(cv);
		});
		messagingOptions.sendCommand(Object).call(messagingOptions, param, returnHandler);
		return deferred.get_promise();
	};
	$tab__CustomViewImpl._getCustomViewsAsync = function CustomViewImpl$GetCustomViewsAsync(workbookImpl, messagingOptions) {
		var deferred = new tab._Deferred();
		var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.FetchCustomViewsCommand', 0, function(result) {
			$tab__CustomViewImpl._processCustomViews(workbookImpl, messagingOptions, result);
			deferred.resolve(workbookImpl.get_$customViews()._toApiCollection());
		}, function(remoteError, message) {
			deferred.reject($tab__TableauException.create('serverError', message));
		});
		messagingOptions.sendCommand(Object).call(messagingOptions, null, returnHandler);
		return deferred.get_promise();
	};
	$tab__CustomViewImpl._processCustomViews = function CustomViewImpl$ProcessCustomViews(workbookImpl, messagingOptions, info) {
		$tab__CustomViewImpl._processCustomViewUpdate(workbookImpl, messagingOptions, info, false);
	};
	$tab__CustomViewImpl._processCustomViewUpdate = function CustomViewImpl$ProcessCustomViewUpdate(workbookImpl, messagingOptions, info, doUpdateList) {
		if (doUpdateList) {
			workbookImpl.set_$updatedCustomViews(new tab._Collection());
		}
		workbookImpl.set_$currentCustomView(null);
		var currentViewName = null;
		if (ss.isValue(info.currentView)) {
			currentViewName = info.currentView.name;
		}
		var defaultId = info.defaultCustomViewId;
		if (doUpdateList && ss.isValue(info.newView)) {
			var newViewImpl = $tab__CustomViewImpl._createNew(workbookImpl, messagingOptions, info.newView, defaultId);
			workbookImpl.get_$updatedCustomViews()._add(newViewImpl.get_$name(), newViewImpl.get_$customView());
		}
		workbookImpl.set_$removedCustomViews(workbookImpl.get_$customViews());
		workbookImpl.set_$customViews(new tab._Collection());
		if (ss.isValue(info.customViews)) {
			var list = info.customViews;
			if (list.length > 0) {
				for (var i = 0; i < list.length; i++) {
					var customViewImpl = $tab__CustomViewImpl._createNew(workbookImpl, messagingOptions, list[i], defaultId);
					workbookImpl.get_$customViews()._add(customViewImpl.get_$name(), customViewImpl.get_$customView());
					if (workbookImpl.get_$removedCustomViews()._has(customViewImpl.get_$name())) {
						workbookImpl.get_$removedCustomViews()._remove(customViewImpl.get_$name());
					}
					else if (doUpdateList) {
						if (!workbookImpl.get_$updatedCustomViews()._has(customViewImpl.get_$name())) {
							workbookImpl.get_$updatedCustomViews()._add(customViewImpl.get_$name(), customViewImpl.get_$customView());
						}
					}
					if (ss.isValue(currentViewName) && ss.referenceEquals(customViewImpl.get_$name(), currentViewName)) {
						workbookImpl.set_$currentCustomView(customViewImpl.get_$customView());
					}
				}
			}
		}
	};
	$tab__CustomViewImpl.$createCustomViewCommandReturnHandler = function CustomViewImpl$CreateCustomViewCommandReturnHandler(commandName, deferred, successCallback) {
		var errorCallback = function(remoteError, message) {
			deferred.reject($tab__TableauException.create('serverError', message));
		};
		return new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))(commandName, 0, successCallback, errorCallback);
	};
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DashboardImpl
	var $tab__DashboardImpl = function(sheetInfoImpl, workbookImpl, messagingOptions) {
		this.$dashboard = null;
		this.$worksheets = new tab._Collection();
		this.$dashboardObjects = new tab._Collection();
		$tab__SheetImpl.call(this, sheetInfoImpl, workbookImpl, messagingOptions);
	};
	$tab__DashboardImpl.__typeName = 'tab._DashboardImpl';
	global.tab._DashboardImpl = $tab__DashboardImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DataSourceImpl
	var $tab__DataSourceImpl = function(name, isPrimary) {
		this.$name = null;
		this.$fields = new tab._Collection();
		this.$isPrimary = false;
		this.$dataSource = null;
		$tab__Param.verifyString(name, 'name');
		this.$name = name;
		this.$isPrimary = isPrimary;
	};
	$tab__DataSourceImpl.__typeName = 'tab._DataSourceImpl';
	$tab__DataSourceImpl.processDataSource = function DataSourceImpl$ProcessDataSource(dataSourcePm) {
		var dataSourceImpl = new $tab__DataSourceImpl(dataSourcePm.name, dataSourcePm.isPrimary);
		var fields = ss.coalesce(dataSourcePm.fields, []);
		for (var $t1 = 0; $t1 < fields.length; $t1++) {
			var fieldPm = fields[$t1];
			var fieldRole = $tab_ApiEnumConverter.convertFieldRole(fieldPm.role);
			var fieldAggregation = $tab_ApiEnumConverter.convertFieldAggregation(fieldPm.aggregation);
			var field = new $tableauSoftware_Field(dataSourceImpl.get_dataSource(), fieldPm.name, fieldRole, fieldAggregation);
			dataSourceImpl.addField(field);
		}
		return dataSourceImpl;
	};
	$tab__DataSourceImpl.processDataSourcesForWorksheet = function DataSourceImpl$ProcessDataSourcesForWorksheet(pm) {
		var dataSources = new tab._Collection();
		var primaryDataSourceImpl = null;
		for (var $t1 = 0; $t1 < pm.dataSources.length; $t1++) {
			var dataSourcePm = pm.dataSources[$t1];
			var dataSourceImpl = $tab__DataSourceImpl.processDataSource(dataSourcePm);
			if (dataSourcePm.isPrimary) {
				primaryDataSourceImpl = dataSourceImpl;
			}
			else {
				dataSources._add(dataSourcePm.name, dataSourceImpl.get_dataSource());
			}
		}
		if (ss.isValue(primaryDataSourceImpl)) {
			dataSources._addToFirst(primaryDataSourceImpl.get_name(), primaryDataSourceImpl.get_dataSource());
		}
		return dataSources;
	};
	global.tab._DataSourceImpl = $tab__DataSourceImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DataTableImpl
	var $tab__DataTableImpl = function(rows, isSummaryData, totalRowCount, columns) {
		this.$name = null;
		this.$rows = null;
		this.$totalRowCount = 0;
		this.$columns = null;
		this.$isSummaryData = false;
		this.$rows = rows;
		this.$totalRowCount = totalRowCount;
		this.$columns = columns;
		this.$isSummaryData = isSummaryData;
		this.$name = (isSummaryData ? 'Summary Data Table' : 'Underlying Data Table');
	};
	$tab__DataTableImpl.__typeName = 'tab._DataTableImpl';
	$tab__DataTableImpl.processGetDataPresModel = function DataTableImpl$ProcessGetDataPresModel(model) {
		var clientTable = $tab__DataTableImpl.$processUnderlyingTable(model.dataTable);
		var clientColumns = $tab__DataTableImpl.$processUnderlyingColumns(model.headers);
		var clientDataTableImpl = new $tab__DataTableImpl(clientTable, model.isSummary, clientTable.length, clientColumns);
		return new $tableauSoftware_DataTable(clientDataTableImpl);
	};
	$tab__DataTableImpl.$processUnderlyingTable = function DataTableImpl$ProcessUnderlyingTable(apiTable) {
		var clientTable = [];
		for (var $t1 = 0; $t1 < apiTable.length; $t1++) {
			var row = apiTable[$t1];
			var clientRow = [];
			for (var $t2 = 0; $t2 < row.length; $t2++) {
				var apiValue = row[$t2];
				clientRow.push($tab__Utility.getDataValue(apiValue));
			}
			clientTable.push(clientRow);
		}
		return clientTable;
	};
	$tab__DataTableImpl.$processUnderlyingColumns = function DataTableImpl$ProcessUnderlyingColumns(apiColumns) {
		var clientColumns = [];
		for (var $t1 = 0; $t1 < apiColumns.length; $t1++) {
			var apiColumn = apiColumns[$t1];
			var clientColumn = new $tab__ColumnImpl(apiColumn.fieldName, $tab_ApiEnumConverter.convertDataType(apiColumn.dataType), apiColumn.isReferenced, apiColumn.index);
			clientColumns.push(new $tableauSoftware_Column(clientColumn));
		}
		return clientColumns;
	};
	global.tab._DataTableImpl = $tab__DataTableImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DoNotUseDeferred
	var $tab__DeferredImpl = function() {
		this.$promise = null;
		this.$thenFunc = null;
		this.$listeners = [];
		this.$resolveFunc = null;
		this.$promise = new $tab__PromiseImpl(ss.mkdel(this, this.then));
		this.$thenFunc = ss.mkdel(this, this.$preResolutionThen);
		this.$resolveFunc = ss.mkdel(this, this.$transitionToFulfilled);
	};
	$tab__DeferredImpl.__typeName = 'tab._DeferredImpl';
	global.tab._DeferredImpl = $tab__DeferredImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Core.jQueryInterface
	var $tab__jQueryShim = function() {
	};
	$tab__jQueryShim.__typeName = 'tab._jQueryShim';
	$tab__jQueryShim.isFunction = function jQueryInterface$IsFunction(obj) {
		return ss.referenceEquals($tab__jQueryShim.type(obj), $tab__jQueryShim.$functionType);
	};
	$tab__jQueryShim.isArray = function jQueryInterface$IsArray(obj) {
		if (ss.isValue(Array['isArray'])) {
			return ss.unbox(ss.cast(Array['isArray'](obj), Boolean));
		}
		return ss.referenceEquals($tab__jQueryShim.type(obj), $tab__jQueryShim.$arrayType);
	};
	$tab__jQueryShim.type = function jQueryInterface$Type(obj) {
		return (ss.isNullOrUndefined(obj) ? String(obj) : ($tab__jQueryShim.$class2type[ss.cast($tab__jQueryShim.$toString.call(obj), String)] || $tab__jQueryShim.$objectType));
	};
	$tab__jQueryShim.trim = function jQueryInterface$Trim(text) {
		if (ss.isValue($tab__jQueryShim.$trim)) {
			return (ss.isNullOrUndefined(text) ? '' : ss.cast($tab__jQueryShim.$trim.call(text), String));
		}
		return (ss.isNullOrUndefined(text) ? '' : text.toString().replace($tab__jQueryShim.$trimLeft, '').replace($tab__jQueryShim.$trimRight, ''));
	};
	$tab__jQueryShim.parseJSON = function jQueryInterface$ParseJson(data) {
		if (typeof(data) !== 'string' || ss.isNullOrUndefined(data)) {
			return null;
		}
		data = $tab__jQueryShim.trim(data);
		if (ss.isValue(JSON) && ss.isValue(JSON['parse'])) {
			return JSON.parse(data);
		}
		if ($tab__jQueryShim.$rvalidchars.test(data.replace($tab__jQueryShim.$rvalidescape, '@').replace($tab__jQueryShim.$rvalidtokens, ']').replace($tab__jQueryShim.$rvalidbraces, ''))) {
			return (new Function('return ' + data))();
		}
		throw new ss.Exception('Invalid JSON: ' + data);
	};
	global.tab._jQueryShim = $tab__jQueryShim;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.Param
	var $tab__Param = function() {
	};
	$tab__Param.__typeName = 'tab._Param';
	$tab__Param.verifyString = function Param$VerifyString(argumentValue, argumentName) {
		if (ss.isNullOrUndefined(argumentValue) || argumentValue.length === 0) {
			throw $tab__TableauException.createInternalStringArgumentException(argumentName);
		}
	};
	$tab__Param.verifyValue = function Param$VerifyValue(argumentValue, argumentName) {
		if (ss.isNullOrUndefined(argumentValue)) {
			throw $tab__TableauException.createInternalNullArgumentException(argumentName);
		}
	};
	global.tab._Param = $tab__Param;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.DoNotUsePromise
	var $tab__PromiseImpl = function(thenFunc) {
		this.then = null;
		this.then = thenFunc;
	};
	$tab__PromiseImpl.__typeName = 'tab._PromiseImpl';
	global.tab._PromiseImpl = $tab__PromiseImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.TabRect
	var $tab__Rect = function(left, top, width, height) {
		this.left = 0;
		this.top = 0;
		this.width = 0;
		this.height = 0;
		this.left = left;
		this.top = top;
		this.width = width;
		this.height = height;
	};
	$tab__Rect.__typeName = 'tab._Rect';
	global.tab._Rect = $tab__Rect;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.SheetImpl
	var $tab__SheetImpl = function(sheetInfoImpl, workbookImpl, messagingOptions) {
		this.$name = null;
		this.$index = 0;
		this.$isActive = false;
		this.$isHidden = false;
		this.$sheetType = null;
		this.$size = null;
		this.$url = null;
		this.$workbookImpl = null;
		this.$messagingOptions = null;
		this.$parentStoryPointImpl = null;
		this.$zoneId = 0;
		$tab__Param.verifyValue(sheetInfoImpl, 'sheetInfoImpl');
		$tab__Param.verifyValue(workbookImpl, 'workbookImpl');
		$tab__Param.verifyValue(messagingOptions, 'messagingOptions');
		this.$name = sheetInfoImpl.name;
		this.$index = sheetInfoImpl.index;
		this.$isActive = sheetInfoImpl.isActive;
		this.$isHidden = sheetInfoImpl.isHidden;
		this.$sheetType = sheetInfoImpl.sheetType;
		this.$size = sheetInfoImpl.size;
		this.$url = sheetInfoImpl.url;
		this.$workbookImpl = workbookImpl;
		this.$messagingOptions = messagingOptions;
		this.$zoneId = sheetInfoImpl.zoneId;
	};
	$tab__SheetImpl.__typeName = 'tab._SheetImpl';
	$tab__SheetImpl.$convertValueToIntIfValid = function SheetImpl$ConvertValueToIntIfValid(value) {
		if (ss.isValue(value)) {
			return $tab__Utility.toInt(value);
		}
		return value;
	};
	$tab__SheetImpl.$normalizeSheetSize = function SheetImpl$NormalizeSheetSize(size) {
		var behavior = $tab_$PublicEnums.$normalizeEnum($tab_ApiSheetSizeBehavior).call(null, size.behavior, 'size.behavior');
		var minSize = size.minSize;
		if (ss.isValue(minSize)) {
			minSize = $tab_Size.$ctor($tab__SheetImpl.$convertValueToIntIfValid(size.minSize.width), $tab__SheetImpl.$convertValueToIntIfValid(size.minSize.height));
		}
		var maxSize = size.maxSize;
		if (ss.isValue(maxSize)) {
			maxSize = $tab_Size.$ctor($tab__SheetImpl.$convertValueToIntIfValid(size.maxSize.width), $tab__SheetImpl.$convertValueToIntIfValid(size.maxSize.height));
		}
		return $tab_SheetSize.$ctor(behavior, minSize, maxSize);
	};
	global.tab._SheetImpl = $tab__SheetImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiSheetInfoImpl
	var $tab__SheetInfoImpl = function() {
	};
	$tab__SheetInfoImpl.__typeName = 'tab._SheetInfoImpl';
	$tab__SheetInfoImpl.$ctor = function(name, sheetType, index, size, workbook, url, isActive, isHidden, zoneId) {
		var $this = new Object();
		$this.name = null;
		$this.index = 0;
		$this.workbook = null;
		$this.url = null;
		$this.isHidden = false;
		$this.sheetType = null;
		$this.zoneId = 0;
		$this.size = null;
		$this.isActive = false;
		$this.name = name;
		$this.sheetType = sheetType;
		$this.index = index;
		$this.size = size;
		$this.workbook = workbook;
		$this.url = url;
		$this.isActive = isActive;
		$this.isHidden = isHidden;
		$this.zoneId = zoneId;
		return $this;
	};
	global.tab._SheetInfoImpl = $tab__SheetInfoImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.StoryImpl
	var $tab__StoryImpl = function(sheetInfoImpl, workbookImpl, messagingOptions, storyPm, findSheetFunc) {
		this.$activeStoryPointImpl = null;
		this.$findSheetFunc = null;
		this.$story = null;
		this.$storyPointsInfo = null;
		this.$2$ActiveStoryPointChangeField = null;
		$tab__SheetImpl.call(this, sheetInfoImpl, workbookImpl, messagingOptions);
		$tab__Param.verifyValue(storyPm, 'storyPm');
		$tab__Param.verifyValue(findSheetFunc, 'findSheetFunc');
		this.$findSheetFunc = findSheetFunc;
		this.update(storyPm);
	};
	$tab__StoryImpl.__typeName = 'tab._StoryImpl';
	global.tab._StoryImpl = $tab__StoryImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.StoryPointImpl
	var $tab__StoryPointImpl = function(storyPointInfoImpl, containedSheetImpl) {
		this.$caption = null;
		this.$index = 0;
		this.$isActive = false;
		this.$isUpdated = false;
		this.$containedSheetImpl = null;
		this.$parentStoryImpl = null;
		this.$storyPoint = null;
		this.$storyPointId = 0;
		this.$isActive = storyPointInfoImpl.isActive;
		this.$isUpdated = storyPointInfoImpl.isUpdated;
		this.$caption = storyPointInfoImpl.caption;
		this.$index = storyPointInfoImpl.index;
		this.$parentStoryImpl = storyPointInfoImpl.parentStoryImpl;
		this.$storyPointId = storyPointInfoImpl.storyPointId;
		this.$containedSheetImpl = containedSheetImpl;
		if (ss.isValue(containedSheetImpl)) {
			this.$containedSheetImpl.set_parentStoryPointImpl(this);
			if (containedSheetImpl.get_sheetType() === 'dashboard') {
				var containedDashboardImpl = ss.cast(this.$containedSheetImpl, $tab__DashboardImpl);
				for (var i = 0; i < containedDashboardImpl.get_worksheets().get__length(); i++) {
					var worksheet = containedDashboardImpl.get_worksheets().get_item(i);
					worksheet._impl.set_parentStoryPointImpl(this);
				}
			}
		}
	};
	$tab__StoryPointImpl.__typeName = 'tab._StoryPointImpl';
	$tab__StoryPointImpl.createContainedSheet = function StoryPointImpl$CreateContainedSheet(containedSheetInfo, workbookImpl, messagingOptions, findSheetFunc) {
		var containedSheetType = $tab_ApiEnumConverter.convertSheetType(containedSheetInfo.sheetType);
		var index = -1;
		var size = $tab_SheetSizeFactory.createAutomatic();
		var isActive = false;
		var publishedSheetInfo = findSheetFunc(containedSheetInfo.name);
		var isHidden = ss.isNullOrUndefined(publishedSheetInfo);
		var url = (isHidden ? '' : publishedSheetInfo.getUrl());
		var sheetInfoImpl = $tab__SheetInfoImpl.$ctor(containedSheetInfo.name, containedSheetType, index, size, workbookImpl.get_workbook(), url, isActive, isHidden, containedSheetInfo.zoneId);
		if (containedSheetInfo.sheetType === 'worksheet') {
			var parentDashboardImpl = null;
			var worksheetImpl = new $tab__WorksheetImpl(sheetInfoImpl, workbookImpl, messagingOptions, parentDashboardImpl);
			return worksheetImpl;
		}
		else if (containedSheetInfo.sheetType === 'dashboard') {
			var dashboardImpl = new $tab__DashboardImpl(sheetInfoImpl, workbookImpl, messagingOptions);
			var dashboardZones = $tab__WorkbookImpl.$createDashboardZones(containedSheetInfo.dashboardZones);
			dashboardImpl.$addObjects(dashboardZones, findSheetFunc);
			return dashboardImpl;
		}
		else if (containedSheetInfo.sheetType === 'story') {
			throw $tab__TableauException.createInternalError('Cannot have a story embedded within another story.');
		}
		else {
			throw $tab__TableauException.createInternalError("Unknown sheet type '" + containedSheetInfo.sheetType + "'");
		}
	};
	global.tab._StoryPointImpl = $tab__StoryPointImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.StoryPointInfoImpl
	var $tab__StoryPointInfoImpl = function() {
	};
	$tab__StoryPointInfoImpl.__typeName = 'tab._StoryPointInfoImpl';
	$tab__StoryPointInfoImpl.$ctor = function(caption, index, storyPointId, isActive, isUpdated, parentStoryImpl) {
		var $this = new Object();
		$this.storyPointId = 0;
		$this.parentStoryImpl = null;
		$this.caption = null;
		$this.index = 0;
		$this.isActive = false;
		$this.isUpdated = false;
		$this.caption = caption;
		$this.index = index;
		$this.storyPointId = storyPointId;
		$this.isActive = isActive;
		$this.isUpdated = isUpdated;
		$this.parentStoryImpl = parentStoryImpl;
		return $this;
	};
	global.tab._StoryPointInfoImpl = $tab__StoryPointInfoImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.TableauException
	var $tab__TableauException = function() {
	};
	$tab__TableauException.__typeName = 'tab._TableauException';
	$tab__TableauException.create = function TableauException$Create(id, message) {
		var x = new ss.Exception(message);
		x['tableauSoftwareErrorCode'] = id;
		return x;
	};
	$tab__TableauException.createInternalError = function TableauException$CreateInternalError(details) {
		if (ss.isValue(details)) {
			return $tab__TableauException.create('internalError', 'Internal error. Please contact Tableau support with the following information: ' + details);
		}
		else {
			return $tab__TableauException.create('internalError', 'Internal error. Please contact Tableau support');
		}
	};
	$tab__TableauException.createInternalNullArgumentException = function TableauException$CreateInternalNullArgumentException(argumentName) {
		return $tab__TableauException.createInternalError("Null/undefined argument '" + argumentName + "'.");
	};
	$tab__TableauException.createInternalStringArgumentException = function TableauException$CreateInternalStringArgumentException(argumentName) {
		return $tab__TableauException.createInternalError("Invalid string argument '" + argumentName + "'.");
	};
	$tab__TableauException.createServerError = function TableauException$CreateServerError(message) {
		return $tab__TableauException.create('serverError', message);
	};
	$tab__TableauException.createNotActiveSheet = function TableauException$CreateNotActiveSheet() {
		return $tab__TableauException.create('notActiveSheet', 'Operation not allowed on non-active sheet');
	};
	$tab__TableauException.createInvalidCustomViewName = function TableauException$CreateInvalidCustomViewName(customViewName) {
		return $tab__TableauException.create('invalidCustomViewName', 'Invalid custom view name: ' + customViewName);
	};
	$tab__TableauException.createInvalidParameter = function TableauException$CreateInvalidParameter(paramName) {
		return $tab__TableauException.create('invalidParameter', 'Invalid parameter: ' + paramName);
	};
	$tab__TableauException.createInvalidFilterFieldNameOrValue = function TableauException$CreateInvalidFilterFieldNameOrValue(fieldName) {
		return $tab__TableauException.create('invalidFilterFieldNameOrValue', 'Invalid filter field name or value: ' + fieldName);
	};
	$tab__TableauException.createInvalidDateParameter = function TableauException$CreateInvalidDateParameter(paramName) {
		return $tab__TableauException.create('invalidDateParameter', 'Invalid date parameter: ' + paramName);
	};
	$tab__TableauException.createNullOrEmptyParameter = function TableauException$CreateNullOrEmptyParameter(paramName) {
		return $tab__TableauException.create('nullOrEmptyParameter', 'Parameter cannot be null or empty: ' + paramName);
	};
	$tab__TableauException.createMissingMaxSize = function TableauException$CreateMissingMaxSize() {
		return $tab__TableauException.create('missingMaxSize', 'Missing maxSize for SheetSizeBehavior.ATMOST');
	};
	$tab__TableauException.createMissingMinSize = function TableauException$CreateMissingMinSize() {
		return $tab__TableauException.create('missingMinSize', 'Missing minSize for SheetSizeBehavior.ATLEAST');
	};
	$tab__TableauException.createMissingMinMaxSize = function TableauException$CreateMissingMinMaxSize() {
		return $tab__TableauException.create('missingMinMaxSize', 'Missing minSize or maxSize for SheetSizeBehavior.RANGE');
	};
	$tab__TableauException.createInvalidRangeSize = function TableauException$CreateInvalidRangeSize() {
		return $tab__TableauException.create('invalidSize', 'Missing minSize or maxSize for SheetSizeBehavior.RANGE');
	};
	$tab__TableauException.createInvalidSizeValue = function TableauException$CreateInvalidSizeValue() {
		return $tab__TableauException.create('invalidSize', 'Size value cannot be less than zero');
	};
	$tab__TableauException.createInvalidSheetSizeParam = function TableauException$CreateInvalidSheetSizeParam() {
		return $tab__TableauException.create('invalidSize', 'Invalid sheet size parameter');
	};
	$tab__TableauException.createSizeConflictForExactly = function TableauException$CreateSizeConflictForExactly() {
		return $tab__TableauException.create('invalidSize', 'Conflicting size values for SheetSizeBehavior.EXACTLY');
	};
	$tab__TableauException.createInvalidSizeBehaviorOnWorksheet = function TableauException$CreateInvalidSizeBehaviorOnWorksheet() {
		return $tab__TableauException.create('invalidSizeBehaviorOnWorksheet', 'Only SheetSizeBehavior.AUTOMATIC is allowed on Worksheets');
	};
	$tab__TableauException.createNoUrlForHiddenWorksheet = function TableauException$CreateNoUrlForHiddenWorksheet() {
		return $tab__TableauException.create('noUrlForHiddenWorksheet', 'Hidden worksheets do not have a URL.');
	};
	$tab__TableauException.$createInvalidAggregationFieldName = function TableauException$CreateInvalidAggregationFieldName(fieldName) {
		return $tab__TableauException.create('invalidAggregationFieldName', "Invalid aggregation type for field '" + fieldName + "'");
	};
	$tab__TableauException.createIndexOutOfRange = function TableauException$CreateIndexOutOfRange(index) {
		return $tab__TableauException.create('indexOutOfRange', "Index '" + index + "' is out of range.");
	};
	$tab__TableauException.createUnsupportedEventName = function TableauException$CreateUnsupportedEventName(eventName) {
		return $tab__TableauException.create('unsupportedEventName', "Unsupported event '" + eventName + "'.");
	};
	$tab__TableauException.createBrowserNotCapable = function TableauException$CreateBrowserNotCapable() {
		return $tab__TableauException.create('browserNotCapable', 'This browser is incapable of supporting the Tableau JavaScript API.');
	};
	global.tab._TableauException = $tab__TableauException;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.Utility
	var $tab__Utility = function() {
	};
	$tab__Utility.__typeName = 'tab._Utility';
	$tab__Utility.isNullOrEmpty = function Utility$IsNullOrEmpty(value) {
		return ss.isNullOrUndefined(value) || (value['length'] || 0) <= 0;
	};
	$tab__Utility.isString = function Utility$IsString(value) {
		return typeof(value) === 'string';
	};
	$tab__Utility.isNumber = function Utility$IsNumber(value) {
		return typeof(value) === 'number';
	};
	$tab__Utility.isDate = function Utility$IsDate(value) {
		if (typeof(value) === 'object' && ss.isInstanceOfType(value, ss.JsDate)) {
			return true;
		}
		else if (!!(Object.prototype.toString.call(value) !== '[object Date]')) {
			return false;
		}
		return !isNaN(ss.cast(value, ss.JsDate).getTime());
	};
	$tab__Utility.isDateValid = function Utility$IsDateValid(dt) {
		return !isNaN(dt.getTime());
	};
	$tab__Utility.indexOf = function Utility$IndexOf(array, searchElement, fromIndex) {
		if (ss.isValue(Array.prototype['indexOf'])) {
			return ss.unbox(ss.cast(array['indexOf'](searchElement, fromIndex), ss.Int32));
		}
		fromIndex = fromIndex || 0;
		var length = array.length;
		if (length > 0) {
			for (var index = fromIndex; index < length; index++) {
				if (ss.referenceEquals(array[index], searchElement)) {
					return index;
				}
			}
		}
		return -1;
	};
	$tab__Utility.contains = function Utility$Contains(array, searchElement, fromIndex) {
		var index = $tab__Utility.indexOf(array, searchElement, fromIndex);
		return index >= 0;
	};
	$tab__Utility.getTopmostWindow = function Utility$GetTopmostWindow() {
		var win = window.self;
		while (ss.isValue(win.parent) && !ss.referenceEquals(win.parent, win)) {
			win = win.parent;
		}
		return win;
	};
	$tab__Utility.toInt = function Utility$ToInt(value) {
		if ($tab__Utility.isNumber(value)) {
			return ss.Int32.trunc(value);
		}
		var number = parseInt(value.toString(), 10);
		if (isNaN(number)) {
			return 0;
		}
		return number;
	};
	$tab__Utility.hasClass = function Utility$HasClass(element, className) {
		var regexClass = new RegExp('[\\n\\t\\r]', 'g');
		return ss.isValue(element) && (' ' + element.className + ' ').replace(regexClass, ' ').indexOf(' ' + className + ' ') > -1;
	};
	$tab__Utility.findParentWithClassName = function Utility$FindParentWithClassName(element, className, stopAtElement) {
		var parent = (ss.isValue(element) ? ss.cast(element.parentNode, HTMLElement) : null);
		stopAtElement = stopAtElement || document.body;
		while (ss.isValue(parent)) {
			if ($tab__Utility.hasClass(parent, className)) {
				return parent;
			}
			if (ss.referenceEquals(parent, stopAtElement)) {
				parent = null;
			}
			else {
				parent = ss.cast(parent.parentNode, HTMLElement);
			}
		}
		return parent;
	};
	$tab__Utility.hasJsonParse = function Utility$HasJsonParse() {
		return !!(ss.isValue(JSON) && ss.isValue(JSON.parse));
	};
	$tab__Utility.hasWindowPostMessage = function Utility$HasWindowPostMessage() {
		return !!ss.isValue(window.postMessage);
	};
	$tab__Utility.isPostMessageSynchronous = function Utility$IsPostMessageSynchronous() {
		if ($tab__Utility.isIE()) {
			var msieRegEx = new RegExp('(msie) ([\\w.]+)');
			var matches = msieRegEx.exec(window.navigator.userAgent.toLowerCase());
			var versionStr = matches[2] || '0';
			var version = parseInt(versionStr, 10);
			return version <= 8;
		}
		return false;
	};
	$tab__Utility.hasDocumentAttachEvent = function Utility$HasDocumentAttachEvent() {
		return !!ss.isValue(document.attachEvent);
	};
	$tab__Utility.hasWindowAddEventListener = function Utility$HasWindowAddEventListener() {
		return !!ss.isValue(window.addEventListener);
	};
	$tab__Utility.isElementOfTag = function Utility$IsElementOfTag(element, tagName) {
		return ss.isValue(element) && element.nodeType === 1 && ss.referenceEquals(element.tagName.toLowerCase(), tagName.toLowerCase());
	};
	$tab__Utility.elementToString = function Utility$ElementToString(element) {
		var str = new ss.StringBuilder();
		str.append(element.tagName.toLowerCase());
		if (!$tab__Utility.isNullOrEmpty(element.id)) {
			str.append('#').append(element.id);
		}
		if (!$tab__Utility.isNullOrEmpty(element.className)) {
			var classes = element.className.split(' ');
			str.append('.').append(classes.join('.'));
		}
		return str.toString();
	};
	$tab__Utility.tableauGCS = function Utility$TableauGCS(e) {
		if (typeof(window['getComputedStyle']) === 'function') {
			return window.getComputedStyle(e);
		}
		else {
			return e['currentStyle'];
		}
	};
	$tab__Utility.isIE = function Utility$IsIE() {
		return !!(window.navigator.userAgent.indexOf('MSIE') > -1 && ss.isNullOrUndefined(window.opera));
	};
	$tab__Utility.isSafari = function Utility$IsSafari() {
		var ua = window.navigator.userAgent;
		var isChrome = ua.indexOf('Chrome') >= 0;
		return ua.indexOf('Safari') >= 0 && !isChrome;
	};
	$tab__Utility.mobileDetect = function Utility$MobileDetect() {
		var ua = window.navigator.userAgent;
		if (ua.indexOf('iPad') !== -1) {
			return true;
		}
		if (ua.indexOf('Android') !== -1) {
			return true;
		}
		if (ua.indexOf('AppleWebKit') !== -1 && ua.indexOf('Mobile') !== -1) {
			return true;
		}
		return false;
	};
	$tab__Utility.visibleContentRectInDocumentCoordinates = function Utility$VisibleContentRectInDocumentCoordinates(element) {
		var visibleRect = $tab__Utility.contentRectInDocumentCoordinates(element);
		for (var currentElement = element.parentElement; ss.isValue(currentElement) && ss.isValue(currentElement.parentElement); currentElement = currentElement.parentElement) {
			var overflow = $tab__Utility.$getComputedStyle(currentElement).overflow;
			if (overflow === 'auto' || overflow === 'scroll' || overflow === 'hidden') {
				visibleRect = visibleRect.intersect($tab__Utility.contentRectInDocumentCoordinates(currentElement));
			}
		}
		var viewportRect = $tab__Utility.contentRectInDocumentCoordinates(document.documentElement);
		var win = new tab.WindowHelper(window.self);
		if (win.isQuirksMode()) {
			viewportRect.height = document.body.clientHeight - viewportRect.left;
			viewportRect.width = document.body.clientWidth - viewportRect.top;
		}
		viewportRect.left += win.get_pageXOffset();
		viewportRect.top += win.get_pageYOffset();
		return visibleRect.intersect(viewportRect);
	};
	$tab__Utility.contentRectInDocumentCoordinates = function Utility$ContentRectInDocumentCoordinates(element) {
		var boundingClientRect = $tab__Utility.getBoundingClientRect(element);
		var style = $tab__Utility.$getComputedStyle(element);
		var paddingLeft = $tab__Utility.toInt(style.paddingLeft);
		var paddingTop = $tab__Utility.toInt(style.paddingTop);
		var borderLeft = $tab__Utility.toInt(style.borderLeftWidth);
		var borderTop = $tab__Utility.toInt(style.borderTopWidth);
		var contentSize = $tab__Utility.computeContentSize(element);
		var win = new tab.WindowHelper(window.self);
		var left = boundingClientRect.left + paddingLeft + borderLeft + win.get_pageXOffset();
		var top = boundingClientRect.top + paddingTop + borderTop + win.get_pageYOffset();
		return new $tab__Rect(left, top, contentSize.width, contentSize.height);
	};
	$tab__Utility.getBoundingClientRect = function Utility$GetBoundingClientRect(element) {
		var rect = element.getBoundingClientRect();
		var top = ss.Int32.trunc(rect.top);
		var left = ss.Int32.trunc(rect.left);
		var right = ss.Int32.trunc(rect.right);
		var bottom = ss.Int32.trunc(rect.bottom);
		return new $tab__Rect(left, top, right - left, bottom - top);
	};
	$tab__Utility.convertRawValue = function Utility$ConvertRawValue(rawValue, dataType) {
		if (ss.isNullOrUndefined(rawValue)) {
			return null;
		}
		switch (dataType) {
			case 'bool': {
				return rawValue;
			}
			case 'date':
			case 'number': {
				if (ss.isNullOrUndefined(rawValue)) {
					return Number.NaN;
				}
				return rawValue;
			}
			default:
			case 'string': {
				return rawValue;
			}
		}
	};
	$tab__Utility.getDataValue = function Utility$GetDataValue(dv) {
		if (ss.isNullOrUndefined(dv)) {
			return $tab_DataValue.$ctor(null, null, null);
		}
		return $tab_DataValue.$ctor($tab__Utility.convertRawValue(dv.value, dv.type), dv.formattedValue, dv.aliasedValue);
	};
	$tab__Utility.serializeDateForServer = function Utility$SerializeDateForServer(date) {
		var serializedDate = '';
		if (ss.isValue(date) && $tab__Utility.isDate(date)) {
			var year = date.getUTCFullYear();
			var month = date.getUTCMonth() + 1;
			var day = date.getUTCDate();
			var hh = date.getUTCHours();
			var mm = date.getUTCMinutes();
			var sec = date.getUTCSeconds();
			serializedDate = year + '-' + month + '-' + day + ' ' + hh + ':' + mm + ':' + sec;
		}
		return serializedDate;
	};
	$tab__Utility.computeContentSize = function Utility$ComputeContentSize(element) {
		var style = $tab__Utility.$getComputedStyle(element);
		var paddingLeft = parseFloat(style.paddingLeft);
		var paddingTop = parseFloat(style.paddingTop);
		var paddingRight = parseFloat(style.paddingRight);
		var paddingBottom = parseFloat(style.paddingBottom);
		var width = element.clientWidth - Math.round(paddingLeft + paddingRight);
		var height = element.clientHeight - Math.round(paddingTop + paddingBottom);
		return $tab_Size.$ctor(width, height);
	};
	$tab__Utility.$getComputedStyle = function Utility$GetComputedStyle(element) {
		if (typeof(window['getComputedStyle']) === 'function') {
			if (ss.isValue(element.ownerDocument.defaultView.opener)) {
				return element.ownerDocument.defaultView.getComputedStyle(element);
			}
			return window.getComputedStyle(element);
		}
		else if (ss.isValue(element['currentStyle'])) {
			return element['currentStyle'];
		}
		return element.style;
	};
	$tab__Utility.roundVizSizeInPixels = function Utility$RoundVizSizeInPixels(size) {
		if (ss.isNullOrUndefined(size) || !(size.indexOf('px') !== -1)) {
			return size;
		}
		var sizeValue = parseFloat(size.split('px')[0]);
		return Math.round(sizeValue) + 'px';
	};
	global.tab._Utility = $tab__Utility;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.VizManagerImpl
	var $tab__VizManagerImpl = function() {
	};
	$tab__VizManagerImpl.__typeName = 'tab._VizManagerImpl';
	$tab__VizManagerImpl.get_$clonedVizs = function VizManagerImpl$get_ClonedVizs() {
		return $tab__VizManagerImpl.$vizs.concat();
	};
	$tab__VizManagerImpl.$registerViz = function VizManagerImpl$RegisterViz(viz) {
		$tab__VizManagerImpl.$verifyVizNotAlreadyParented(viz);
		$tab__VizManagerImpl.$vizs.push(viz);
	};
	$tab__VizManagerImpl.$unregisterViz = function VizManagerImpl$UnregisterViz(viz) {
		for (var i = 0, len = $tab__VizManagerImpl.$vizs.length; i < len; i++) {
			if (ss.referenceEquals($tab__VizManagerImpl.$vizs[i], viz)) {
				$tab__VizManagerImpl.$vizs.splice(i, 1);
				break;
			}
		}
	};
	$tab__VizManagerImpl.$sendVisibleRects = function VizManagerImpl$SendVisibleRects() {
		for (var i = 0, len = $tab__VizManagerImpl.$vizs.length; i < len; i++) {
			$tab__VizManagerImpl.$vizs[i]._impl.$sendVisibleRect();
		}
	};
	$tab__VizManagerImpl.$verifyVizNotAlreadyParented = function VizManagerImpl$VerifyVizNotAlreadyParented(viz) {
		var parent = viz.getParentElement();
		for (var i = 0, len = $tab__VizManagerImpl.$vizs.length; i < len; i++) {
			if (ss.referenceEquals($tab__VizManagerImpl.$vizs[i].getParentElement(), parent)) {
				var message = "Another viz is already present in element '" + $tab__Utility.elementToString(parent) + "'.";
				throw $tab__TableauException.create('vizAlreadyInManager', message);
			}
		}
	};
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.VizParameters
	var $tab__VizParameters = function(element, url, options) {
		this.name = '';
		this.host_url = null;
		this.tabs = false;
		this.toolbar = false;
		this.toolBarPosition = null;
		this.device = null;
		this.hostId = null;
		this.width = null;
		this.height = null;
		this.parentElement = null;
		this.userSuppliedParameters = null;
		this.staticImageUrl = null;
		this.fixedSize = false;
		this.displayStaticImage = false;
		this.$urlFromApi = null;
		this.$createOptions = null;
		if (ss.isNullOrUndefined(element) || ss.isNullOrUndefined(url)) {
			throw $tab__TableauException.create('noUrlOrParentElementNotFound', 'URL is empty or Parent element not found');
		}
		if (ss.isNullOrUndefined(options)) {
			options = new Object();
			options.hideTabs = false;
			options.hideToolbar = false;
			options.onFirstInteractive = null;
		}
		if (ss.isValue(options.height) || ss.isValue(options.width)) {
			this.fixedSize = true;
			if ($tab__Utility.isNumber(options.height)) {
				options.height = options.height.toString() + 'px';
			}
			if ($tab__Utility.isNumber(options.width)) {
				options.width = options.width.toString() + 'px';
			}
			this.height = (ss.isValue(options.height) ? $tab__Utility.roundVizSizeInPixels(options.height.toString()) : null);
			this.width = (ss.isValue(options.width) ? $tab__Utility.roundVizSizeInPixels(options.width.toString()) : null);
		}
		else {
			this.fixedSize = false;
		}
		this.displayStaticImage = options.displayStaticImage || false;
		this.staticImageUrl = options.staticImageUrl || '';
		this.tabs = !(options.hideTabs || false);
		this.toolbar = !(options.hideToolbar || false);
		this.device = options.device;
		this.parentElement = element;
		this.$createOptions = options;
		this.toolBarPosition = options.toolbarPosition;
		var urlParts = url.split('?');
		this.$urlFromApi = urlParts[0];
		if (urlParts.length === 2) {
			this.userSuppliedParameters = urlParts[1];
		}
		else {
			this.userSuppliedParameters = '';
		}
		var r = (new RegExp('.*?[^/:]/', '')).exec(this.$urlFromApi);
		if (ss.isNullOrUndefined(r) || r[0].toLowerCase().indexOf('http://') === -1 && r[0].toLowerCase().indexOf('https://') === -1) {
			throw $tab__TableauException.create('invalidUrl', 'Invalid url');
		}
		this.host_url = r[0].toLowerCase();
		this.name = this.$urlFromApi.replace(r[0], '');
		this.name = this.name.replace('views/', '');
	};
	$tab__VizParameters.__typeName = 'tab._VizParameters';
	global.tab._VizParameters = $tab__VizParameters;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.WorkbookImpl
	var $tab__WorkbookImpl = function(vizImpl, messagingOptions, callback) {
		this.$workbook = null;
		this.$vizImpl = null;
		this.$name = null;
		this.$activeSheetImpl = null;
		this.$activatingHiddenSheetImpl = null;
		this.$publishedSheetsInfo = new tab._Collection();
		this.$isDownloadAllowed = false;
		this.$messagingOptions = null;
		this.$currentCustomView = null;
		this.$customViews = new tab._Collection();
		this.$updatedCustomViews = new tab._Collection();
		this.$removedCustomViews = new tab._Collection();
		this.$parameters = null;
		this.$lastChangedParameterImpl = null;
		this.$vizImpl = vizImpl;
		this.$messagingOptions = messagingOptions;
		this.$getClientInfo(callback);
	};
	$tab__WorkbookImpl.__typeName = 'tab._WorkbookImpl';
	$tab__WorkbookImpl.$createDashboardZones = function WorkbookImpl$CreateDashboardZones(zones) {
		zones = ss.coalesce(zones, []);
		var zonesInfo = [];
		for (var i = 0; i < zones.length; i++) {
			var zone = zones[i];
			var objectType = $tab_ApiEnumConverter.convertDashboardObjectType(zone.zoneType);
			var size = $tab_Size.$ctor(zone.width, zone.height);
			var position = $tab_Point.$ctor(zone.x, zone.y);
			var name = zone.name;
			var zoneInfo = { name: name, objectType: objectType, position: position, size: size, zoneId: zone.zoneId };
			zonesInfo.push(zoneInfo);
		}
		return zonesInfo;
	};
	$tab__WorkbookImpl.$extractSheetName = function WorkbookImpl$ExtractSheetName(sheetOrInfoOrName) {
		if (ss.isNullOrUndefined(sheetOrInfoOrName)) {
			return null;
		}
		if ($tab__Utility.isString(sheetOrInfoOrName)) {
			return sheetOrInfoOrName;
		}
		var sheet = ss.safeCast(sheetOrInfoOrName, $tableauSoftware_Sheet);
		if (ss.isValue(sheet)) {
			return sheet.getName();
		}
		var info = ss.safeCast(sheetOrInfoOrName, $tableauSoftware_SheetInfo);
		if (ss.isValue(info)) {
			return info.getName();
		}
		return null;
	};
	$tab__WorkbookImpl.$createSheetSize = function WorkbookImpl$CreateSheetSize(sheetInfo) {
		if (ss.isNullOrUndefined(sheetInfo)) {
			return $tab_SheetSizeFactory.createAutomatic();
		}
		return $tab_SheetSizeFactory.fromSizeConstraints(sheetInfo.sizeConstraints);
	};
	$tab__WorkbookImpl.$processParameters = function WorkbookImpl$ProcessParameters(paramList) {
		var parameters = new tab._Collection();
		for (var $t1 = 0; $t1 < paramList.parameters.length; $t1++) {
			var model = paramList.parameters[$t1];
			var paramImpl = new $tab_$ParameterImpl(model);
			parameters._add(paramImpl.get_$name(), paramImpl.get_$parameter());
		}
		return parameters;
	};
	$tab__WorkbookImpl.$findAndCreateParameterImpl = function WorkbookImpl$FindAndCreateParameterImpl(parameterName, paramList) {
		for (var $t1 = 0; $t1 < paramList.parameters.length; $t1++) {
			var model = paramList.parameters[$t1];
			if (ss.referenceEquals(model.name, parameterName)) {
				return new $tab_$ParameterImpl(model);
			}
		}
		return null;
	};
	global.tab._WorkbookImpl = $tab__WorkbookImpl;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.WorksheetImpl
	var $tab__WorksheetImpl = function(sheetInfoImpl, workbookImpl, messagingOptions, parentDashboardImpl) {
		this.$worksheet = null;
		this.$parentDashboardImpl = null;
		this.$filters = new tab._Collection();
		this.$selectedMarks = new tab._Collection();
		this.highlightedMarks = null;
		$tab__SheetImpl.call(this, sheetInfoImpl, workbookImpl, messagingOptions);
		this.$parentDashboardImpl = parentDashboardImpl;
	};
	$tab__WorksheetImpl.__typeName = 'tab._WorksheetImpl';
	$tab__WorksheetImpl.$filterCommandError = function WorksheetImpl$FilterCommandError(rawPm) {
		var commandError = rawPm;
		if (ss.isValue(commandError) && ss.isValue(commandError.errorCode)) {
			var additionalInfo = (ss.isValue(commandError.additionalInformation) ? commandError.additionalInformation.toString() : '');
			switch (commandError.errorCode) {
				case 'invalidFilterFieldName': {
					return $tab__TableauException.create('invalidFilterFieldName', additionalInfo);
				}
				case 'invalidFilterFieldValue': {
					return $tab__TableauException.create('invalidFilterFieldValue', additionalInfo);
				}
				case 'invalidAggregationFieldName': {
					return $tab__TableauException.$createInvalidAggregationFieldName(additionalInfo);
				}
				default: {
					return $tab__TableauException.createServerError(additionalInfo);
				}
			}
		}
		return null;
	};
	$tab__WorksheetImpl.$normalizeRangeFilterOption = function WorksheetImpl$NormalizeRangeFilterOption(filterOptions) {
		if (ss.isNullOrUndefined(filterOptions)) {
			throw $tab__TableauException.createNullOrEmptyParameter('filterOptions');
		}
		if (ss.isNullOrUndefined(filterOptions.min) && ss.isNullOrUndefined(filterOptions.max)) {
			throw $tab__TableauException.create('invalidParameter', 'At least one of filterOptions.min or filterOptions.max must be specified.');
		}
		var fixedUpFilterOptions = new Object();
		if (ss.isValue(filterOptions.min)) {
			fixedUpFilterOptions.min = filterOptions.min;
		}
		if (ss.isValue(filterOptions.max)) {
			fixedUpFilterOptions.max = filterOptions.max;
		}
		if (ss.isValue(filterOptions.nullOption)) {
			fixedUpFilterOptions.nullOption = $tab_$PublicEnums.$normalizeEnum($tab_ApiNullOption).call(null, filterOptions.nullOption, 'filterOptions.nullOption');
		}
		return fixedUpFilterOptions;
	};
	$tab__WorksheetImpl.$normalizeRelativeDateFilterOptions = function WorksheetImpl$NormalizeRelativeDateFilterOptions(filterOptions) {
		if (ss.isNullOrUndefined(filterOptions)) {
			throw $tab__TableauException.createNullOrEmptyParameter('filterOptions');
		}
		var fixedUpFilterOptions = new Object();
		fixedUpFilterOptions.rangeType = $tab_$PublicEnums.$normalizeEnum($tab_ApiDateRangeType).call(null, filterOptions.rangeType, 'filterOptions.rangeType');
		fixedUpFilterOptions.periodType = $tab_$PublicEnums.$normalizeEnum($tab_ApiPeriodType).call(null, filterOptions.periodType, 'filterOptions.periodType');
		if (fixedUpFilterOptions.rangeType === 'lastn' || fixedUpFilterOptions.rangeType === 'nextn') {
			if (ss.isNullOrUndefined(filterOptions.rangeN)) {
				throw $tab__TableauException.create('missingRangeNForRelativeDateFilters', 'Missing rangeN field for a relative date filter of LASTN or NEXTN.');
			}
			fixedUpFilterOptions.rangeN = $tab__Utility.toInt(filterOptions.rangeN);
		}
		if (ss.isValue(filterOptions.anchorDate)) {
			if (!$tab__Utility.isDate(filterOptions.anchorDate) || !$tab__Utility.isDateValid(filterOptions.anchorDate)) {
				throw $tab__TableauException.createInvalidDateParameter('filterOptions.anchorDate');
			}
			fixedUpFilterOptions.anchorDate = filterOptions.anchorDate;
		}
		return fixedUpFilterOptions;
	};
	$tab__WorksheetImpl.$createFilterCommandReturnHandler = function WorksheetImpl$CreateFilterCommandReturnHandler(commandName, fieldName, deferred) {
		return new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))(commandName, 1, function(result) {
			var error = $tab__WorksheetImpl.$filterCommandError(result);
			if (ss.isNullOrUndefined(error)) {
				deferred.resolve(fieldName);
			}
			else {
				deferred.reject(error);
			}
		}, function(remoteError, message) {
			if (remoteError) {
				deferred.reject($tab__TableauException.createInvalidFilterFieldNameOrValue(fieldName));
			}
			else {
				var error1 = $tab__TableauException.create('filterCannotBePerformed', message);
				deferred.reject(error1);
			}
		});
	};
	$tab__WorksheetImpl.$createSelectionCommandError = function WorksheetImpl$CreateSelectionCommandError(rawPm) {
		var commandError = rawPm;
		if (ss.isValue(commandError) && ss.isValue(commandError.errorCode)) {
			var additionalInfo = (ss.isValue(commandError.additionalInformation) ? commandError.additionalInformation.toString() : '');
			switch (commandError.errorCode) {
				case 'invalidSelectionFieldName': {
					return $tab__TableauException.create('invalidSelectionFieldName', additionalInfo);
				}
				case 'invalidSelectionValue': {
					return $tab__TableauException.create('invalidSelectionValue', additionalInfo);
				}
				case 'invalidSelectionDate': {
					return $tab__TableauException.create('invalidSelectionDate', additionalInfo);
				}
			}
		}
		return null;
	};
	global.tab._WorksheetImpl = $tab__WorksheetImpl;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiDashboardObjectType
	var $tab_ApiDashboardObjectType = function() {
	};
	$tab_ApiDashboardObjectType.__typeName = 'tab.ApiDashboardObjectType';
	global.tab.ApiDashboardObjectType = $tab_ApiDashboardObjectType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiDateRangeType
	var $tab_ApiDateRangeType = function() {
	};
	$tab_ApiDateRangeType.__typeName = 'tab.ApiDateRangeType';
	global.tab.ApiDateRangeType = $tab_ApiDateRangeType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiDeviceType
	var $tab_ApiDeviceType = function() {
	};
	$tab_ApiDeviceType.__typeName = 'tab.ApiDeviceType';
	global.tab.ApiDeviceType = $tab_ApiDeviceType;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ApiEnumConverter
	var $tab_ApiEnumConverter = function() {
	};
	$tab_ApiEnumConverter.__typeName = 'tab.ApiEnumConverter';
	$tab_ApiEnumConverter.convertDashboardObjectType = function ApiEnumConverter$ConvertDashboardObjectType(crossDomainType) {
		switch (crossDomainType) {
			case 'blank': {
				return 'blank';
			}
			case 'image': {
				return 'image';
			}
			case 'legend': {
				return 'legend';
			}
			case 'pageFilter': {
				return 'pageFilter';
			}
			case 'parameterControl': {
				return 'parameterControl';
			}
			case 'quickFilter': {
				return 'quickFilter';
			}
			case 'text': {
				return 'text';
			}
			case 'title': {
				return 'title';
			}
			case 'webPage': {
				return 'webPage';
			}
			case 'worksheet': {
				return 'worksheet';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainDashboardObjectType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertDateRange = function ApiEnumConverter$ConvertDateRange(crossDomainType) {
		switch (crossDomainType) {
			case 'curr': {
				return 'curr';
			}
			case 'last': {
				return 'last';
			}
			case 'lastn': {
				return 'lastn';
			}
			case 'next': {
				return 'next';
			}
			case 'nextn': {
				return 'nextn';
			}
			case 'todate': {
				return 'todate';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainDateRangeType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertFieldAggregation = function ApiEnumConverter$ConvertFieldAggregation(crossDomainType) {
		switch (crossDomainType) {
			case 'ATTR': {
				return 'ATTR';
			}
			case 'AVG': {
				return 'AVG';
			}
			case 'COUNT': {
				return 'COUNT';
			}
			case 'COUNTD': {
				return 'COUNTD';
			}
			case 'DAY': {
				return 'DAY';
			}
			case 'END': {
				return 'END';
			}
			case 'HOUR': {
				return 'HOUR';
			}
			case 'INOUT': {
				return 'INOUT';
			}
			case 'KURTOSIS': {
				return 'KURTOSIS';
			}
			case 'MAX': {
				return 'MAX';
			}
			case 'MDY': {
				return 'MDY';
			}
			case 'MEDIAN': {
				return 'MEDIAN';
			}
			case 'MIN': {
				return 'MIN';
			}
			case 'MINUTE': {
				return 'MINUTE';
			}
			case 'MONTH': {
				return 'MONTH';
			}
			case 'MONTHYEAR': {
				return 'MONTHYEAR';
			}
			case 'NONE': {
				return 'NONE';
			}
			case 'PERCENTILE': {
				return 'PERCENTILE';
			}
			case 'QUART1': {
				return 'QUART1';
			}
			case 'QUART3': {
				return 'QUART3';
			}
			case 'QTR': {
				return 'QTR';
			}
			case 'SECOND': {
				return 'SECOND';
			}
			case 'SKEWNESS': {
				return 'SKEWNESS';
			}
			case 'STDEV': {
				return 'STDEV';
			}
			case 'STDEVP': {
				return 'STDEVP';
			}
			case 'SUM': {
				return 'SUM';
			}
			case 'SUM_XSQR': {
				return 'SUM_XSQR';
			}
			case 'TRUNC_DAY': {
				return 'TRUNC_DAY';
			}
			case 'TRUNC_HOUR': {
				return 'TRUNC_HOUR';
			}
			case 'TRUNC_MINUTE': {
				return 'TRUNC_MINUTE';
			}
			case 'TRUNC_MONTH': {
				return 'TRUNC_MONTH';
			}
			case 'TRUNC_QTR': {
				return 'TRUNC_QTR';
			}
			case 'TRUNC_SECOND': {
				return 'TRUNC_SECOND';
			}
			case 'TRUNC_WEEK': {
				return 'TRUNC_WEEK';
			}
			case 'TRUNC_YEAR': {
				return 'TRUNC_YEAR';
			}
			case 'USER': {
				return 'USER';
			}
			case 'VAR': {
				return 'VAR';
			}
			case 'VARP': {
				return 'VARP';
			}
			case 'WEEK': {
				return 'WEEK';
			}
			case 'WEEKDAY': {
				return 'WEEKDAY';
			}
			case 'YEAR': {
				return 'YEAR';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainFieldAggregationType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertFieldRole = function ApiEnumConverter$ConvertFieldRole(crossDomainType) {
		switch (crossDomainType) {
			case 'dimension': {
				return 'dimension';
			}
			case 'measure': {
				return 'measure';
			}
			case 'unknown': {
				return 'unknown';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainFieldRoleType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertFilterType = function ApiEnumConverter$ConvertFilterType(crossDomainType) {
		switch (crossDomainType) {
			case 'categorical': {
				return 'categorical';
			}
			case 'hierarchical': {
				return 'hierarchical';
			}
			case 'quantitative': {
				return 'quantitative';
			}
			case 'relativedate': {
				return 'relativedate';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainFilterType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertParameterAllowableValuesType = function ApiEnumConverter$ConvertParameterAllowableValuesType(crossDomainType) {
		switch (crossDomainType) {
			case 'all': {
				return 'all';
			}
			case 'list': {
				return 'list';
			}
			case 'range': {
				return 'range';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainParameterAllowableValuesType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertParameterDataType = function ApiEnumConverter$ConvertParameterDataType(crossDomainType) {
		switch (crossDomainType) {
			case 'boolean': {
				return 'boolean';
			}
			case 'date': {
				return 'date';
			}
			case 'datetime': {
				return 'datetime';
			}
			case 'float': {
				return 'float';
			}
			case 'integer': {
				return 'integer';
			}
			case 'string': {
				return 'string';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainParameterDataType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertPeriodType = function ApiEnumConverter$ConvertPeriodType(crossDomainType) {
		switch (crossDomainType) {
			case 'year': {
				return 'year';
			}
			case 'quarter': {
				return 'quarter';
			}
			case 'month': {
				return 'month';
			}
			case 'week': {
				return 'week';
			}
			case 'day': {
				return 'day';
			}
			case 'hour': {
				return 'hour';
			}
			case 'minute': {
				return 'minute';
			}
			case 'second': {
				return 'second';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainPeriodType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertSheetType = function ApiEnumConverter$ConvertSheetType(crossDomainType) {
		switch (crossDomainType) {
			case 'worksheet': {
				return 'worksheet';
			}
			case 'dashboard': {
				return 'dashboard';
			}
			case 'story': {
				return 'story';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainSheetType: ' + crossDomainType);
			}
		}
	};
	$tab_ApiEnumConverter.convertDataType = function ApiEnumConverter$ConvertDataType(crossDomainType) {
		switch (crossDomainType) {
			case 'boolean': {
				return 'boolean';
			}
			case 'date': {
				return 'date';
			}
			case 'datetime': {
				return 'datetime';
			}
			case 'float': {
				return 'float';
			}
			case 'integer': {
				return 'integer';
			}
			case 'string': {
				return 'string';
			}
			default: {
				throw $tab__TableauException.createInternalError('Unknown ApiCrossDomainParameterDataType: ' + crossDomainType);
			}
		}
	};
	global.tab.ApiEnumConverter = $tab_ApiEnumConverter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiErrorCode
	var $tab_ApiErrorCode = function() {
	};
	$tab_ApiErrorCode.__typeName = 'tab.ApiErrorCode';
	global.tab.ApiErrorCode = $tab_ApiErrorCode;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiFieldAggregationType
	var $tab_ApiFieldAggregationType = function() {
	};
	$tab_ApiFieldAggregationType.__typeName = 'tab.ApiFieldAggregationType';
	global.tab.ApiFieldAggregationType = $tab_ApiFieldAggregationType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiFieldRoleType
	var $tab_ApiFieldRoleType = function() {
	};
	$tab_ApiFieldRoleType.__typeName = 'tab.ApiFieldRoleType';
	global.tab.ApiFieldRoleType = $tab_ApiFieldRoleType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiFilterType
	var $tab_ApiFilterType = function() {
	};
	$tab_ApiFilterType.__typeName = 'tab.ApiFilterType';
	global.tab.ApiFilterType = $tab_ApiFilterType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiFilterUpdateType
	var $tab_ApiFilterUpdateType = function() {
	};
	$tab_ApiFilterUpdateType.__typeName = 'tab.ApiFilterUpdateType';
	global.tab.ApiFilterUpdateType = $tab_ApiFilterUpdateType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiNullOption
	var $tab_ApiNullOption = function() {
	};
	$tab_ApiNullOption.__typeName = 'tab.ApiNullOption';
	global.tab.ApiNullOption = $tab_ApiNullOption;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiParameterAllowableValuesType
	var $tab_ApiParameterAllowableValuesType = function() {
	};
	$tab_ApiParameterAllowableValuesType.__typeName = 'tab.ApiParameterAllowableValuesType';
	global.tab.ApiParameterAllowableValuesType = $tab_ApiParameterAllowableValuesType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiParameterDataType
	var $tab_ApiParameterDataType = function() {
	};
	$tab_ApiParameterDataType.__typeName = 'tab.ApiParameterDataType';
	global.tab.ApiParameterDataType = $tab_ApiParameterDataType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiPeriodType
	var $tab_ApiPeriodType = function() {
	};
	$tab_ApiPeriodType.__typeName = 'tab.ApiPeriodType';
	global.tab.ApiPeriodType = $tab_ApiPeriodType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiSelectionUpdateType
	var $tab_ApiSelectionUpdateType = function() {
	};
	$tab_ApiSelectionUpdateType.__typeName = 'tab.ApiSelectionUpdateType';
	global.tab.ApiSelectionUpdateType = $tab_ApiSelectionUpdateType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiSheetSizeBehavior
	var $tab_ApiSheetSizeBehavior = function() {
	};
	$tab_ApiSheetSizeBehavior.__typeName = 'tab.ApiSheetSizeBehavior';
	global.tab.ApiSheetSizeBehavior = $tab_ApiSheetSizeBehavior;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiSheetType
	var $tab_ApiSheetType = function() {
	};
	$tab_ApiSheetType.__typeName = 'tab.ApiSheetType';
	global.tab.ApiSheetType = $tab_ApiSheetType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiTableauEventName
	var $tab_ApiTableauEventName = function() {
	};
	$tab_ApiTableauEventName.__typeName = 'tab.ApiTableauEventName';
	global.tab.ApiTableauEventName = $tab_ApiTableauEventName;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiToolbarPosition
	var $tab_ApiToolbarPosition = function() {
	};
	$tab_ApiToolbarPosition.__typeName = 'tab.ApiToolbarPosition';
	global.tab.ApiToolbarPosition = $tab_ApiToolbarPosition;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.CommandReturnHandler
	var $tab_CommandReturnHandler$1 = function(T) {
		var $type = function(commandName, successCallbackTiming, successCallback, errorCallback) {
			this.$commandName = null;
			this.$successCallbackTiming = 0;
			this.$successCallback = null;
			this.$errorCallback = null;
			this.$commandName = commandName;
			this.$successCallback = successCallback;
			this.$successCallbackTiming = successCallbackTiming;
			this.$errorCallback = errorCallback;
		};
		ss.registerGenericClassInstance($type, $tab_CommandReturnHandler$1, [T], {
			get_commandName: function CommandReturnHandler$get_CommandName() {
				return this.$commandName;
			},
			get_successCallback: function CommandReturnHandler$get_SuccessCallback() {
				return this.$successCallback;
			},
			get_successCallbackTiming: function CommandReturnHandler$get_SuccessCallbackTiming() {
				return this.$successCallbackTiming;
			},
			get_errorCallback: function CommandReturnHandler$get_ErrorCallback() {
				return this.$errorCallback;
			}
		}, function() {
			return null;
		}, function() {
			return [];
		});
		return $type;
	};
	$tab_CommandReturnHandler$1.__typeName = 'tab.CommandReturnHandler$1';
	ss.initGenericClass($tab_CommandReturnHandler$1, $asm, 1);
	global.tab.CommandReturnHandler$1 = $tab_CommandReturnHandler$1;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.CrossDomainMessagingOptions
	var $tab_CrossDomainMessagingOptions = function(router, handler) {
		this.$router = null;
		this.$handler = null;
		$tab__Param.verifyValue(router, 'router');
		$tab__Param.verifyValue(handler, 'handler');
		this.$router = router;
		this.$handler = handler;
	};
	$tab_CrossDomainMessagingOptions.__typeName = 'tab.CrossDomainMessagingOptions';
	global.tab.CrossDomainMessagingOptions = $tab_CrossDomainMessagingOptions;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.CustomViewEvent
	var $tab_CustomViewEvent = function(eventName, viz, customViewImpl) {
		this.$context = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$context = new $tab_$CustomViewEventContext(viz._impl.get__workbookImpl(), customViewImpl);
	};
	$tab_CustomViewEvent.__typeName = 'tab.CustomViewEvent';
	global.tab.CustomViewEvent = $tab_CustomViewEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.DataType
	var $tab_DataType = function() {
	};
	$tab_DataType.__typeName = 'tab.DataType';
	global.tab.DataType = $tab_DataType;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.DataValue
	var $tab_DataValue = function() {
	};
	$tab_DataValue.__typeName = 'tab.DataValue';
	$tab_DataValue.$ctor = function(value, formattedValue, aliasedValue) {
		var $this = new Object();
		$this.value = null;
		$this.formattedValue = null;
		$this.value = value;
		if ($tab__Utility.isNullOrEmpty(aliasedValue)) {
			$this.formattedValue = formattedValue;
		}
		else {
			$this.formattedValue = aliasedValue;
		}
		return $this;
	};
	global.tab.DataValue = $tab_DataValue;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.EventContext
	var $tab_EventContext = function(workbookImpl, worksheetImpl) {
		this.$workbookImpl = null;
		this.$worksheetImpl = null;
		this.$workbookImpl = workbookImpl;
		this.$worksheetImpl = worksheetImpl;
	};
	$tab_EventContext.__typeName = 'tab.EventContext';
	global.tab.EventContext = $tab_EventContext;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.FilterEvent
	var $tab_FilterEvent = function(eventName, viz, worksheetImpl, fieldName, filterCaption) {
		this.$filterCaption = null;
		this.$context = null;
		$tab_WorksheetEvent.call(this, eventName, viz, worksheetImpl);
		this.$filterCaption = filterCaption;
		this.$context = new $tab_$FilterEventContext(viz._impl.get__workbookImpl(), worksheetImpl, fieldName, filterCaption);
	};
	$tab_FilterEvent.__typeName = 'tab.FilterEvent';
	global.tab.FilterEvent = $tab_FilterEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.FirstVizSizeKnownEvent
	var $tab_FirstVizSizeKnownEvent = function(eventName, viz, vizSize) {
		this.$vizSize = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$vizSize = vizSize;
	};
	$tab_FirstVizSizeKnownEvent.__typeName = 'tab.FirstVizSizeKnownEvent';
	global.tab.FirstVizSizeKnownEvent = $tab_FirstVizSizeKnownEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.HighlightEvent
	var $tab_HighlightEvent = function(eventName, viz, worksheetImpl) {
		this.$context = null;
		$tab_WorksheetEvent.call(this, eventName, viz, worksheetImpl);
		this.$context = new $tab_$HighlightEventContext(viz._impl.get__workbookImpl(), worksheetImpl);
	};
	$tab_HighlightEvent.__typeName = 'tab.HighlightEvent';
	global.tab.HighlightEvent = $tab_HighlightEvent;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ICrossDomainMessageHandler
	var $tab_ICrossDomainMessageHandler = function() {
	};
	$tab_ICrossDomainMessageHandler.__typeName = 'tab.ICrossDomainMessageHandler';
	global.tab.ICrossDomainMessageHandler = $tab_ICrossDomainMessageHandler;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.ICrossDomainMessageRouter
	var $tab_ICrossDomainMessageRouter = function() {
	};
	$tab_ICrossDomainMessageRouter.__typeName = 'tab.ICrossDomainMessageRouter';
	global.tab.ICrossDomainMessageRouter = $tab_ICrossDomainMessageRouter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.MarksEvent
	var $tab_MarksEvent = function(eventName, viz, worksheetImpl) {
		this.$context = null;
		$tab_WorksheetEvent.call(this, eventName, viz, worksheetImpl);
		this.$context = new $tab_$MarksEventContext(viz._impl.get__workbookImpl(), worksheetImpl);
	};
	$tab_MarksEvent.__typeName = 'tab.MarksEvent';
	global.tab.MarksEvent = $tab_MarksEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ParameterEvent
	var $tab_ParameterEvent = function(eventName, viz, parameterName) {
		this.$context = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$context = new $tab_$ParameterEventContext(viz._impl.get__workbookImpl(), parameterName);
	};
	$tab_ParameterEvent.__typeName = 'tab.ParameterEvent';
	global.tab.ParameterEvent = $tab_ParameterEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Point
	var $tab_Point = function() {
	};
	$tab_Point.__typeName = 'tab.Point';
	$tab_Point.$ctor = function(x, y) {
		var $this = new Object();
		$this.x = 0;
		$this.y = 0;
		$this.x = x;
		$this.y = y;
		return $this;
	};
	global.tab.Point = $tab_Point;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.SheetSize
	var $tab_SheetSize = function() {
	};
	$tab_SheetSize.__typeName = 'tab.SheetSize';
	$tab_SheetSize.$ctor = function(behavior, minSize, maxSize) {
		var $this = new Object();
		$this.behavior = null;
		$this.minSize = null;
		$this.maxSize = null;
		$this.behavior = ss.coalesce(behavior, 'automatic');
		if (ss.isValue(minSize)) {
			$this.minSize = minSize;
		}
		else {
			delete $this['minSize'];
		}
		if (ss.isValue(maxSize)) {
			$this.maxSize = maxSize;
		}
		else {
			delete $this['maxSize'];
		}
		return $this;
	};
	global.tab.SheetSize = $tab_SheetSize;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.SheetSizeFactory
	var $tab_SheetSizeFactory = function() {
	};
	$tab_SheetSizeFactory.__typeName = 'tab.SheetSizeFactory';
	$tab_SheetSizeFactory.createAutomatic = function SheetSizeFactory$CreateAutomatic() {
		var size = $tab_SheetSize.$ctor('automatic', null, null);
		return size;
	};
	$tab_SheetSizeFactory.fromSizeConstraints = function SheetSizeFactory$FromSizeConstraints(vizSizePresModel) {
		var minHeight = vizSizePresModel.minHeight;
		var minWidth = vizSizePresModel.minWidth;
		var maxHeight = vizSizePresModel.maxHeight;
		var maxWidth = vizSizePresModel.maxWidth;
		var behavior = 'automatic';
		var minSize = null;
		var maxSize = null;
		if (minHeight === 0 && minWidth === 0) {
			if (maxHeight === 0 && maxWidth === 0) {
			}
			else {
				behavior = 'atmost';
				maxSize = $tab_Size.$ctor(maxWidth, maxHeight);
			}
		}
		else if (maxHeight === 0 && maxWidth === 0) {
			behavior = 'atleast';
			minSize = $tab_Size.$ctor(minWidth, minHeight);
		}
		else if (maxHeight === minHeight && maxWidth === minWidth && minWidth > 0) {
			behavior = 'exactly';
			minSize = $tab_Size.$ctor(minWidth, minHeight);
			maxSize = $tab_Size.$ctor(minWidth, minHeight);
		}
		else {
			behavior = 'range';
			if (minWidth === 0 && maxWidth === 0) {
				maxWidth = 2147483647;
			}
			minSize = $tab_Size.$ctor(minWidth, minHeight);
			maxSize = $tab_Size.$ctor(maxWidth, maxHeight);
		}
		return $tab_SheetSize.$ctor(behavior, minSize, maxSize);
	};
	global.tab.SheetSizeFactory = $tab_SheetSizeFactory;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Size
	var $tab_Size = function() {
	};
	$tab_Size.__typeName = 'tab.Size';
	$tab_Size.$ctor = function(width, height) {
		var $this = new Object();
		$this.width = 0;
		$this.height = 0;
		$this.width = width;
		$this.height = height;
		return $this;
	};
	global.tab.Size = $tab_Size;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.StoryPointInfoImplUtil
	var $tab_StoryPointInfoImplUtil = function() {
	};
	$tab_StoryPointInfoImplUtil.__typeName = 'tab.StoryPointInfoImplUtil';
	$tab_StoryPointInfoImplUtil.clone = function StoryPointInfoImplUtil$Clone(impl) {
		return $tab__StoryPointInfoImpl.$ctor(impl.caption, impl.index, impl.storyPointId, impl.isActive, impl.isUpdated, impl.parentStoryImpl);
	};
	global.tab.StoryPointInfoImplUtil = $tab_StoryPointInfoImplUtil;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.StoryPointSwitchEvent
	var $tab_StoryPointSwitchEvent = function(eventName, viz, oldStoryPointInfo, newStoryPoint) {
		this.$oldStoryPointInfo = null;
		this.$newStoryPoint = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$oldStoryPointInfo = oldStoryPointInfo;
		this.$newStoryPoint = newStoryPoint;
	};
	$tab_StoryPointSwitchEvent.__typeName = 'tab.StoryPointSwitchEvent';
	global.tab.StoryPointSwitchEvent = $tab_StoryPointSwitchEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.TableauEvent
	var $tab_TableauEvent = function(eventName, viz) {
		this.$viz = null;
		this.$eventName = null;
		this.$viz = viz;
		this.$eventName = eventName;
	};
	$tab_TableauEvent.__typeName = 'tab.TableauEvent';
	global.tab.TableauEvent = $tab_TableauEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.TabSwitchEvent
	var $tab_TabSwitchEvent = function(eventName, viz, oldName, newName) {
		this.$oldName = null;
		this.$newName = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$oldName = oldName;
		this.$newName = newName;
	};
	$tab_TabSwitchEvent.__typeName = 'tab.TabSwitchEvent';
	global.tab.TabSwitchEvent = $tab_TabSwitchEvent;
	////////////////////////////////////////////////////////////////////////////////
	// Tableau.JavaScript.Vql.Api.VizImpl
	var $tab_VizImpl = function(messageRouter, viz, parentElement, url, options) {
		this.$workbookTabSwitchHandler = null;
		this.$viz = null;
		this.$iframe = null;
		this.$staticImage = null;
		this.$parameters = null;
		this.$initialAvailableSize = null;
		this.$instanceId = null;
		this.$workbookImpl = null;
		this.$onFirstInteractiveCallback = null;
		this.$onFirstVizSizeKnownCallback = null;
		this.$onFirstInteractiveAlreadyCalled = false;
		this.$areTabsHidden = false;
		this.$isToolbarHidden = false;
		this.$areAutomaticUpdatesPaused = false;
		this.$messagingOptions = null;
		this.$vizSize = null;
		this.$windowResizeHandler = null;
		this.$initializingWorkbookImpl = false;
		this.$1$CustomViewsListLoadField = null;
		this.$1$StateReadyForQueryField = null;
		this.$1$MarksSelectionField = null;
		this.$1$MarksHighlightField = null;
		this.$1$FilterChangeField = null;
		this.$1$ParameterValueChangeField = null;
		this.$1$CustomViewLoadField = null;
		this.$1$CustomViewSaveField = null;
		this.$1$CustomViewRemoveField = null;
		this.$1$CustomViewSetDefaultField = null;
		this.$1$TabSwitchField = null;
		this.$1$StoryPointSwitchField = null;
		this.$1$VizResizeField = null;
		if (!$tab__Utility.hasWindowPostMessage() || !$tab__Utility.hasJsonParse()) {
			throw $tab__TableauException.createBrowserNotCapable();
		}
		this.$messagingOptions = new $tab_CrossDomainMessagingOptions(messageRouter, this);
		this.$viz = viz;
		if (ss.isNullOrUndefined(parentElement) || parentElement.nodeType !== 1) {
			parentElement = document.body;
		}
		this.$parameters = new $tab__VizParameters(parentElement, url, options);
		if (ss.isValue(options)) {
			this.$onFirstInteractiveCallback = options.onFirstInteractive;
			this.$onFirstVizSizeKnownCallback = options.onFirstVizSizeKnown;
		}
	};
	$tab_VizImpl.__typeName = 'tab.VizImpl';
	global.tab.VizImpl = $tab_VizImpl;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.VizResizeEvent
	var $tab_VizResizeEvent = function(eventName, viz, availableSize) {
		this.$availableSize = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$availableSize = availableSize;
	};
	$tab_VizResizeEvent.__typeName = 'tab.VizResizeEvent';
	global.tab.VizResizeEvent = $tab_VizResizeEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.VizSize
	var $tab_VizSize = function() {
	};
	$tab_VizSize.__typeName = 'tab.VizSize';
	$tab_VizSize.$ctor = function(sheetSize, chromeHeight) {
		var $this = new Object();
		$this.sheetSize = null;
		$this.chromeHeight = 0;
		$this.sheetSize = sheetSize;
		$this.chromeHeight = chromeHeight;
		return $this;
	};
	global.tab.VizSize = $tab_VizSize;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.WorksheetEvent
	var $tab_WorksheetEvent = function(eventName, viz, worksheetImpl) {
		this.$worksheetImpl = null;
		$tab_TableauEvent.call(this, eventName, viz);
		this.$worksheetImpl = worksheetImpl;
	};
	$tab_WorksheetEvent.__typeName = 'tab.WorksheetEvent';
	global.tab.WorksheetEvent = $tab_WorksheetEvent;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.CategoricalFilter
	var $tableauSoftware_CategoricalFilter = function(worksheetImpl, pm) {
		this.$isExclude = false;
		this.$appliedValues = null;
		$tableauSoftware_Filter.call(this, worksheetImpl, pm);
		this.$initializeFromJson$1(pm);
	};
	$tableauSoftware_CategoricalFilter.__typeName = 'tableauSoftware.CategoricalFilter';
	global.tableauSoftware.CategoricalFilter = $tableauSoftware_CategoricalFilter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Column
	var $tableauSoftware_Column = function(impl) {
		this.$impl = null;
		this.$impl = impl;
	};
	$tableauSoftware_Column.__typeName = 'tableauSoftware.Column';
	global.tableauSoftware.Column = $tableauSoftware_Column;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.CustomView
	var $tableauSoftware_CustomView = function(customViewImpl) {
		this._impl = null;
		this._impl = customViewImpl;
	};
	$tableauSoftware_CustomView.__typeName = 'tableauSoftware.CustomView';
	global.tableauSoftware.CustomView = $tableauSoftware_CustomView;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Dashboard
	var $tableauSoftware_Dashboard = function(dashboardImpl) {
		this._impl = null;
		$tableauSoftware_Sheet.call(this, dashboardImpl);
	};
	$tableauSoftware_Dashboard.__typeName = 'tableauSoftware.Dashboard';
	global.tableauSoftware.Dashboard = $tableauSoftware_Dashboard;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.DashboardObject
	var $tableauSoftware_DashboardObject = function(frameInfo, dashboard, worksheet) {
		this.$zoneInfo = null;
		this.$dashboard = null;
		this.$worksheet = null;
		if (frameInfo.objectType === 'worksheet' && ss.isNullOrUndefined(worksheet)) {
			throw $tab__TableauException.createInternalError('worksheet parameter is required for WORKSHEET objects');
		}
		else if (frameInfo.objectType !== 'worksheet' && ss.isValue(worksheet)) {
			throw $tab__TableauException.createInternalError('worksheet parameter should be undefined for non-WORKSHEET objects');
		}
		this.$zoneInfo = frameInfo;
		this.$dashboard = dashboard;
		this.$worksheet = worksheet;
	};
	$tableauSoftware_DashboardObject.__typeName = 'tableauSoftware.DashboardObject';
	global.tableauSoftware.DashboardObject = $tableauSoftware_DashboardObject;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.DataSource
	var $tableauSoftware_DataSource = function(impl) {
		this.$impl = null;
		this.$impl = impl;
	};
	$tableauSoftware_DataSource.__typeName = 'tableauSoftware.DataSource';
	global.tableauSoftware.DataSource = $tableauSoftware_DataSource;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.DataTable
	var $tableauSoftware_DataTable = function(impl) {
		this.$impl = null;
		this.$impl = impl;
	};
	$tableauSoftware_DataTable.__typeName = 'tableauSoftware.DataTable';
	global.tableauSoftware.DataTable = $tableauSoftware_DataTable;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Field
	var $tableauSoftware_Field = function(dataSource, name, fieldRoleType, fieldAggrType) {
		this.$dataSource = null;
		this.$name = null;
		this.$fieldRoleType = null;
		this.$fieldAggrType = null;
		this.$dataSource = dataSource;
		this.$name = name;
		this.$fieldRoleType = fieldRoleType;
		this.$fieldAggrType = fieldAggrType;
	};
	$tableauSoftware_Field.__typeName = 'tableauSoftware.Field';
	global.tableauSoftware.Field = $tableauSoftware_Field;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Filter
	var $tableauSoftware_Filter = function(worksheetImpl, pm) {
		this.$worksheetImpl = null;
		this.$type = null;
		this.$caption = null;
		this.$field = null;
		this.$dataSourceName = null;
		this.$fieldRole = null;
		this.$fieldAggregation = null;
		this.$worksheetImpl = worksheetImpl;
		this.$initializeFromJson(pm);
	};
	$tableauSoftware_Filter.__typeName = 'tableauSoftware.Filter';
	$tableauSoftware_Filter.$createFilter = function Filter$CreateFilter(worksheetImpl, pm) {
		switch (pm.filterType) {
			case 'categorical': {
				return new $tableauSoftware_CategoricalFilter(worksheetImpl, pm);
			}
			case 'relativedate': {
				return new $tableauSoftware_RelativeDateFilter(worksheetImpl, pm);
			}
			case 'hierarchical': {
				return new $tableauSoftware_HierarchicalFilter(worksheetImpl, pm);
			}
			case 'quantitative': {
				return new $tableauSoftware_QuantitativeFilter(worksheetImpl, pm);
			}
		}
		return null;
	};
	$tableauSoftware_Filter.processFiltersList = function Filter$ProcessFiltersList(worksheetImpl, filtersListDict) {
		var filterCaptions = new tab._Collection();
		for (var $t1 = 0; $t1 < filtersListDict.filters.length; $t1++) {
			var filterPm = filtersListDict.filters[$t1];
			if (!filterCaptions._has(filterPm.caption)) {
				filterCaptions._add(filterPm.caption, filterPm.caption);
			}
		}
		var filters = new tab._Collection();
		for (var $t2 = 0; $t2 < filtersListDict.filters.length; $t2++) {
			var filterPm1 = filtersListDict.filters[$t2];
			var filter = $tableauSoftware_Filter.$createFilter(worksheetImpl, filterPm1);
			if (!filters._has(filterPm1.caption)) {
				filters._add(filterPm1.caption, filter);
				continue;
			}
			var filterCollectionKey = filterPm1.caption.toString() + '_' + filterPm1.filterType.toString();
			var filterCollectionKeyNumbered = filterCollectionKey;
			var numberLabel = 1;
			while (filterCaptions._has(filterCollectionKeyNumbered)) {
				filterCollectionKeyNumbered = filterCollectionKey + '_' + numberLabel;
				numberLabel++;
			}
			filters._add(filterCollectionKeyNumbered, filter);
		}
		return filters;
	};
	global.tableauSoftware.Filter = $tableauSoftware_Filter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.HierarchicalFilter
	var $tableauSoftware_HierarchicalFilter = function(worksheetImpl, pm) {
		this.$levels = 0;
		$tableauSoftware_Filter.call(this, worksheetImpl, pm);
		this.$initializeFromJson$1(pm);
	};
	$tableauSoftware_HierarchicalFilter.__typeName = 'tableauSoftware.HierarchicalFilter';
	global.tableauSoftware.HierarchicalFilter = $tableauSoftware_HierarchicalFilter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Mark
	var $tableauSoftware_Mark = function(tupleId) {
		this.$impl = null;
		this.$impl = new $tab_$MarkImpl(tupleId);
	};
	$tableauSoftware_Mark.__typeName = 'tableauSoftware.Mark';
	global.tableauSoftware.Mark = $tableauSoftware_Mark;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Pair
	var $tableauSoftware_Pair = function(fieldName, value) {
		this.fieldName = null;
		this.value = null;
		this.formattedValue = null;
		this.fieldName = fieldName;
		this.value = value;
		this.formattedValue = (ss.isValue(value) ? value.toString() : '');
	};
	$tableauSoftware_Pair.__typeName = 'tableauSoftware.Pair';
	global.tableauSoftware.Pair = $tableauSoftware_Pair;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Parameter
	var $tableauSoftware_Parameter = function(impl) {
		this._impl = null;
		this._impl = impl;
	};
	$tableauSoftware_Parameter.__typeName = 'tableauSoftware.Parameter';
	global.tableauSoftware.Parameter = $tableauSoftware_Parameter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.QuantitativeFilter
	var $tableauSoftware_QuantitativeFilter = function(worksheetImpl, pm) {
		this.$domainMin = null;
		this.$domainMax = null;
		this.$min = null;
		this.$max = null;
		this.$includeNullValues = false;
		$tableauSoftware_Filter.call(this, worksheetImpl, pm);
		this.$initializeFromJson$1(pm);
	};
	$tableauSoftware_QuantitativeFilter.__typeName = 'tableauSoftware.QuantitativeFilter';
	global.tableauSoftware.QuantitativeFilter = $tableauSoftware_QuantitativeFilter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.RelativeDateFilter
	var $tableauSoftware_RelativeDateFilter = function(worksheetImpl, pm) {
		this.$periodType = null;
		this.$rangeType = null;
		this.$rangeN = 0;
		$tableauSoftware_Filter.call(this, worksheetImpl, pm);
		this.$initializeFromJson$1(pm);
	};
	$tableauSoftware_RelativeDateFilter.__typeName = 'tableauSoftware.RelativeDateFilter';
	global.tableauSoftware.RelativeDateFilter = $tableauSoftware_RelativeDateFilter;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Sheet
	var $tableauSoftware_Sheet = function(sheetImpl) {
		this._impl = null;
		$tab__Param.verifyValue(sheetImpl, 'sheetImpl');
		this._impl = sheetImpl;
	};
	$tableauSoftware_Sheet.__typeName = 'tableauSoftware.Sheet';
	global.tableauSoftware.Sheet = $tableauSoftware_Sheet;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.ApiSheetInfo
	var $tableauSoftware_SheetInfo = function(impl) {
		this.$impl = null;
		this.$impl = impl;
	};
	$tableauSoftware_SheetInfo.__typeName = 'tableauSoftware.SheetInfo';
	global.tableauSoftware.SheetInfo = $tableauSoftware_SheetInfo;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Story
	var $tableauSoftware_Story = function(storyImpl) {
		this._impl = null;
		$tableauSoftware_Sheet.call(this, storyImpl);
	};
	$tableauSoftware_Story.__typeName = 'tableauSoftware.Story';
	global.tableauSoftware.Story = $tableauSoftware_Story;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.StoryPoint
	var $tableauSoftware_StoryPoint = function(impl) {
		this.$impl = null;
		this.$impl = impl;
	};
	$tableauSoftware_StoryPoint.__typeName = 'tableauSoftware.StoryPoint';
	global.tableauSoftware.StoryPoint = $tableauSoftware_StoryPoint;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.StoryPointInfo
	var $tableauSoftware_StoryPointInfo = function(impl) {
		this._impl = null;
		this._impl = impl;
	};
	$tableauSoftware_StoryPointInfo.__typeName = 'tableauSoftware.StoryPointInfo';
	global.tableauSoftware.StoryPointInfo = $tableauSoftware_StoryPointInfo;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Version
	var $tableauSoftware_Version = function(major, minor, patch, metadata) {
		this.$major = 0;
		this.$minor = 0;
		this.$patch = 0;
		this.$metadata = null;
		this.$major = major;
		this.$minor = minor;
		this.$patch = patch;
		this.$metadata = ss.coalesce(metadata, null);
	};
	$tableauSoftware_Version.__typeName = 'tableauSoftware.Version';
	$tableauSoftware_Version.getCurrent = function Version$GetCurrent() {
		return $tableauSoftware_Version.$currentVersion;
	};
	global.tableauSoftware.Version = $tableauSoftware_Version;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Viz
	var $tableauSoftware_Viz = function(parentElement, url, options) {
		this._impl = null;
		var messageRouter = $tab__ApiObjectRegistry.getCrossDomainMessageRouter();
		this._impl = new $tab_VizImpl(messageRouter, this, parentElement, url, options);
		this._impl.$create();
	};
	$tableauSoftware_Viz.__typeName = 'tableauSoftware.Viz';
	$tableauSoftware_Viz.getLastRequestMessage = function Viz$GetLastRequestMessage() {
		return $tab__ApiCommand.lastRequestMessage;
	};
	$tableauSoftware_Viz.getLastResponseMessage = function Viz$GetLastResponseMessage() {
		return $tab__ApiCommand.lastResponseMessage;
	};
	$tableauSoftware_Viz.getLastClientInfoResponseMessage = function Viz$GetLastClientInfoResponseMessage() {
		return $tab__ApiCommand.lastClientInfoResponseMessage;
	};
	global.tableauSoftware.Viz = $tableauSoftware_Viz;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.VizManager
	var $tableauSoftware_VizManager = function() {
	};
	$tableauSoftware_VizManager.__typeName = 'tableauSoftware.VizManager';
	$tableauSoftware_VizManager.getVizs = function VizManager$GetVizs() {
		return $tab__VizManagerImpl.get_$clonedVizs();
	};
	global.tableauSoftware.VizManager = $tableauSoftware_VizManager;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Workbook
	var $tableauSoftware_Workbook = function(workbookImpl) {
		this.$workbookImpl = null;
		this.$workbookImpl = workbookImpl;
	};
	$tableauSoftware_Workbook.__typeName = 'tableauSoftware.Workbook';
	global.tableauSoftware.Workbook = $tableauSoftware_Workbook;
	////////////////////////////////////////////////////////////////////////////////
	// tableauSoftware.Worksheet
	var $tableauSoftware_Worksheet = function(impl) {
		this._impl = null;
		$tableauSoftware_Sheet.call(this, impl);
	};
	$tableauSoftware_Worksheet.__typeName = 'tableauSoftware.Worksheet';
	global.tableauSoftware.Worksheet = $tableauSoftware_Worksheet;
	ss.initInterface($tab_ICrossDomainMessageRouter, $asm, { registerHandler: null, unregisterHandler: null, sendCommand: null });
	ss.initClass($tab_$CrossDomainMessageRouter, $asm, {
		registerHandler: function CrossDomainMessageRouter$RegisterHandler(handler) {
			var uniqueId = 'host' + this.$nextHandlerId;
			if (ss.isValue(handler.get_hostId()) || ss.isValue(this.$handlers[handler.get_hostId()])) {
				throw $tab__TableauException.createInternalError("Host '" + handler.get_hostId() + "' is already registered.");
			}
			this.$nextHandlerId++;
			handler.set_hostId(uniqueId);
			this.$handlers[uniqueId] = handler;
			handler.add_customViewsListLoad(ss.mkdel(this, this.$handleCustomViewsListLoad));
			handler.add_stateReadyForQuery(ss.mkdel(this, this.$handleStateReadyForQuery));
		},
		unregisterHandler: function CrossDomainMessageRouter$UnregisterHandler(handler) {
			if (ss.isValue(handler.get_hostId()) || ss.isValue(this.$handlers[handler.get_hostId()])) {
				delete this.$handlers[handler.get_hostId()];
				handler.remove_customViewsListLoad(ss.mkdel(this, this.$handleCustomViewsListLoad));
				handler.remove_stateReadyForQuery(ss.mkdel(this, this.$handleStateReadyForQuery));
			}
		},
		sendCommand: function(T) {
			return function CrossDomainMessageRouter$SendCommand(source, commandParameters, returnHandler) {
				var iframe = source.get_iframe();
				var handlerId = source.get_hostId();
				if (!$tab__Utility.hasWindowPostMessage() || ss.isNullOrUndefined(iframe) || ss.isNullOrUndefined(iframe.contentWindow)) {
					return;
				}
				var commandId = $tab__ApiCommand.generateNextCommandId();
				var callbackMap = this.$commandCallbacks[handlerId];
				if (ss.isNullOrUndefined(callbackMap)) {
					callbackMap = {};
					this.$commandCallbacks[handlerId] = callbackMap;
				}
				callbackMap[commandId] = returnHandler;
				var commandName = returnHandler.get_commandName();
				if (commandName === 'api.ShowCustomViewCommand') {
					var customViewCallbacks = this.$customViewLoadCallbacks[handlerId];
					if (ss.isNullOrUndefined(customViewCallbacks)) {
						customViewCallbacks = [];
						this.$customViewLoadCallbacks[handlerId] = customViewCallbacks;
					}
					customViewCallbacks.push(returnHandler);
				}
				var serializedParams = null;
				if (ss.isValue(commandParameters)) {
					serializedParams = JSON.stringify(commandParameters);
				}
				var command = new $tab__ApiCommand(commandName, commandId, handlerId, serializedParams);
				var message = command.serialize();
				if ($tab__Utility.isPostMessageSynchronous()) {
					window.setTimeout(function() {
						iframe.contentWindow.postMessage(message, '*');
					}, 0);
				}
				else {
					iframe.contentWindow.postMessage(message, '*');
				}
			};
		},
		$handleCustomViewsListLoad: function CrossDomainMessageRouter$HandleCustomViewsListLoad(source) {
			var handlerId = source.get_hostId();
			var customViewCallbacks = this.$customViewLoadCallbacks[handlerId];
			if (ss.isNullOrUndefined(customViewCallbacks)) {
				return;
			}
			for (var $t1 = 0; $t1 < customViewCallbacks.length; $t1++) {
				var returnHandler = customViewCallbacks[$t1];
				if (!ss.staticEquals(returnHandler.get_successCallback(), null)) {
					returnHandler.get_successCallback()(null);
				}
			}
			delete this.$customViewLoadCallbacks[handlerId];
		},
		$handleStateReadyForQuery: function CrossDomainMessageRouter$HandleStateReadyForQuery(source) {
			var queue = this.$commandReturnAfterStateReadyQueues[source.get_hostId()];
			if ($tab__Utility.isNullOrEmpty(queue)) {
				return;
			}
			while (queue.length > 0) {
				var successCallback = queue.pop();
				if (ss.isValue(successCallback)) {
					successCallback();
				}
			}
		},
		$handleCrossDomainMessage: function CrossDomainMessageRouter$HandleCrossDomainMessage(e) {
			var messageEvent = ss.cast(e, MessageEvent);
			if (ss.isNullOrUndefined(messageEvent.data)) {
				return;
			}
			var command = $tab__ApiCommand.parse(messageEvent.data.toString());
			var rawName = command.get_rawName();
			var hostId = command.get_hostId();
			var handler = this.$handlers[hostId];
			if (ss.isNullOrUndefined(handler) || !ss.referenceEquals(handler.get_hostId(), command.get_hostId())) {
				handler = this.$findHostIdByDomComparison(messageEvent);
			}
			if (command.get_isApiCommandName()) {
				if (ss.referenceEquals(command.get_commandId(), $tab__ApiCommand.crossDomainEventNotificationId)) {
					handler.handleEventNotification(command.get_name(), command.get_parameters());
					if (command.get_name() === 'api.FirstVizSizeKnownEvent') {
						messageEvent.source.postMessage('tableau.bootstrap', '*');
					}
				}
				else {
					this.$handleCrossDomainResponse(command);
				}
			}
			else {
				this.$handleLegacyNotifications(rawName, handler);
			}
		},
		$handleCrossDomainResponse: function CrossDomainMessageRouter$HandleCrossDomainResponse(command) {
			var commandCallbackMap = this.$commandCallbacks[command.get_hostId()];
			var returnHandler = (ss.isValue(commandCallbackMap) ? commandCallbackMap[command.get_commandId()] : null);
			if (ss.isNullOrUndefined(returnHandler)) {
				return;
			}
			delete commandCallbackMap[command.get_commandId()];
			if (command.get_name() !== returnHandler.get_commandName()) {
				return;
			}
			var crossDomainResult = new $tab__ApiServerResultParser(command.get_parameters());
			var commandResult = crossDomainResult.get_data();
			if (crossDomainResult.get_result() === 'api.success') {
				switch (returnHandler.get_successCallbackTiming()) {
					case 0: {
						if (ss.isValue(returnHandler.get_successCallback())) {
							returnHandler.get_successCallback()(commandResult);
						}
						break;
					}
					case 1: {
						var postponedCallback = function() {
							if (ss.isValue(returnHandler.get_successCallback())) {
								returnHandler.get_successCallback()(commandResult);
							}
						};
						var queue = this.$commandReturnAfterStateReadyQueues[command.get_hostId()];
						if (ss.isNullOrUndefined(queue)) {
							queue = [];
							this.$commandReturnAfterStateReadyQueues[command.get_hostId()] = queue;
						}
						queue.push(postponedCallback);
						break;
					}
					default: {
						throw $tab__TableauException.createInternalError('Unknown timing value: ' + returnHandler.get_successCallbackTiming());
					}
				}
			}
			else if (ss.isValue(returnHandler.get_errorCallback())) {
				var remoteError = crossDomainResult.get_result() === 'api.remotefailed';
				var errorMessage = (ss.isValue(commandResult) ? commandResult.toString() : '');
				returnHandler.get_errorCallback()(remoteError, errorMessage);
			}
		},
		$handleLegacyNotifications: function CrossDomainMessageRouter$HandleLegacyNotifications(messageName, handler) {
			if (messageName === 'layoutInfoReq') {
				$tab__VizManagerImpl.$sendVisibleRects();
			}
			else if (messageName === 'tableau.completed' || messageName === 'completed') {
				handler.handleVizLoad();
			}
			else if (messageName === 'tableau.listening') {
				handler.handleVizListening();
			}
		},
		$findHostIdByDomComparison: function CrossDomainMessageRouter$FindHostIdByDomComparison(messageEvent) {
			var $t1 = new ss.ObjectEnumerator(this.$handlers);
			try {
				while ($t1.moveNext()) {
					var pair = $t1.current();
					if (this.$handlers.hasOwnProperty(pair.key) && ss.referenceEquals(pair.value.get_iframe().contentWindow, messageEvent.source)) {
						return pair.value;
					}
				}
			}
			finally {
				$t1.dispose();
			}
			return new $tab_$DoNothingCrossDomainHandler();
		}
	}, null, [$tab_ICrossDomainMessageRouter]);
	ss.initClass($tab_EventContext, $asm, {
		get__workbookImpl: function EventContext$get_WorkbookImpl() {
			return this.$workbookImpl;
		},
		get__worksheetImpl: function EventContext$get_WorksheetImpl() {
			return this.$worksheetImpl;
		}
	});
	ss.initClass($tab_$CustomViewEventContext, $asm, {
		get__customViewImpl: function CustomViewEventContext$get_CustomViewImpl() {
			return this.$customViewImpl;
		}
	}, $tab_EventContext);
	ss.initClass($tab_$DashboardZoneInfo, $asm, {});
	ss.initClass($tab_$DeferredUtil, $asm, {});
	ss.initInterface($tab_ICrossDomainMessageHandler, $asm, { add_customViewsListLoad: null, remove_customViewsListLoad: null, add_stateReadyForQuery: null, remove_stateReadyForQuery: null, get_iframe: null, get_hostId: null, set_hostId: null, handleVizLoad: null, handleVizListening: null, handleEventNotification: null });
	ss.initClass($tab_$DoNothingCrossDomainHandler, $asm, {
		add_customViewsListLoad: function DoNothingCrossDomainHandler$add_CustomViewsListLoad(value) {
			this.$1$CustomViewsListLoadField = ss.delegateCombine(this.$1$CustomViewsListLoadField, value);
		},
		remove_customViewsListLoad: function DoNothingCrossDomainHandler$remove_CustomViewsListLoad(value) {
			this.$1$CustomViewsListLoadField = ss.delegateRemove(this.$1$CustomViewsListLoadField, value);
		},
		add_stateReadyForQuery: function DoNothingCrossDomainHandler$add_StateReadyForQuery(value) {
			this.$1$StateReadyForQueryField = ss.delegateCombine(this.$1$StateReadyForQueryField, value);
		},
		remove_stateReadyForQuery: function DoNothingCrossDomainHandler$remove_StateReadyForQuery(value) {
			this.$1$StateReadyForQueryField = ss.delegateRemove(this.$1$StateReadyForQueryField, value);
		},
		get_iframe: function DoNothingCrossDomainHandler$get_Iframe() {
			return null;
		},
		get_hostId: function DoNothingCrossDomainHandler$get_HostId() {
			return this.$hostId;
		},
		set_hostId: function DoNothingCrossDomainHandler$set_HostId(value) {
			this.$hostId = value;
		},
		get_$serverRoot: function DoNothingCrossDomainHandler$get_ServerRoot() {
			return '*';
		},
		handleVizLoad: function DoNothingCrossDomainHandler$HandleVizLoad() {
		},
		handleVizListening: function DoNothingCrossDomainHandler$HandleVizListening() {
		},
		handleEventNotification: function DoNothingCrossDomainHandler$HandleEventNotification(eventName, parameters) {
		},
		$silenceTheCompilerWarning: function DoNothingCrossDomainHandler$SilenceTheCompilerWarning() {
			this.$1$CustomViewsListLoadField(null);
			this.$1$StateReadyForQueryField(null);
		}
	}, null, [$tab_ICrossDomainMessageHandler]);
	ss.initClass($tab_$FilterEventContext, $asm, {
		get__filterFieldName: function FilterEventContext$get_FilterFieldName() {
			return this.$fieldFieldName;
		},
		get_$filterCaption: function FilterEventContext$get_FilterCaption() {
			return this.$filterCaption;
		}
	}, $tab_EventContext);
	ss.initClass($tab_$HighlightEventContext, $asm, {}, $tab_EventContext);
	ss.initClass($tab_$MarkImpl, $asm, {
		get_$pairs: function MarkImpl$get_Pairs() {
			return this.$collection;
		},
		get_$tupleId: function MarkImpl$get_TupleId() {
			return this.$tupleId;
		},
		get_$clonedPairs: function MarkImpl$get_ClonedPairs() {
			if (ss.isNullOrUndefined(this.$clonedPairs)) {
				this.$clonedPairs = this.$collection._toApiCollection();
			}
			return this.$clonedPairs;
		},
		$addPair: function MarkImpl$AddPair(pair) {
			this.$collection._add(pair.fieldName, pair);
		}
	});
	ss.initClass($tab_$MarksEventContext, $asm, {}, $tab_EventContext);
	ss.initClass($tab_$ParameterEventContext, $asm, {
		get__parameterName: function ParameterEventContext$get_ParameterName() {
			return this.$parameterName;
		}
	}, $tab_EventContext);
	ss.initClass($tab_$ParameterImpl, $asm, {
		get_$parameter: function ParameterImpl$get_Parameter() {
			if (ss.isNullOrUndefined(this.$parameter)) {
				this.$parameter = new $tableauSoftware_Parameter(this);
			}
			return this.$parameter;
		},
		get_$name: function ParameterImpl$get_Name() {
			return this.$name;
		},
		get_$currentValue: function ParameterImpl$get_CurrentValue() {
			return this.$currentValue;
		},
		get_$dataType: function ParameterImpl$get_DataType() {
			return this.$dataType;
		},
		get_$allowableValuesType: function ParameterImpl$get_AllowableValuesType() {
			return this.$allowableValuesType;
		},
		get_$allowableValues: function ParameterImpl$get_AllowableValues() {
			return this.$allowableValues;
		},
		get_$minValue: function ParameterImpl$get_MinValue() {
			return this.$minValue;
		},
		get_$maxValue: function ParameterImpl$get_MaxValue() {
			return this.$maxValue;
		},
		get_$stepSize: function ParameterImpl$get_StepSize() {
			return this.$stepSize;
		},
		get_$dateStepPeriod: function ParameterImpl$get_DateStepPeriod() {
			return this.$dateStepPeriod;
		}
	});
	ss.initClass($tab_$PublicEnums, $asm, {});
	ss.initClass($tab__ApiBootstrap, $asm, {});
	ss.initClass($tab__ApiCommand, $asm, {
		get_name: function() {
			return this.$1$NameField;
		},
		set_name: function(value) {
			this.$1$NameField = value;
		},
		get_hostId: function() {
			return this.$1$HostIdField;
		},
		set_hostId: function(value) {
			this.$1$HostIdField = value;
		},
		get_commandId: function() {
			return this.$1$CommandIdField;
		},
		set_commandId: function(value) {
			this.$1$CommandIdField = value;
		},
		get_parameters: function() {
			return this.$1$ParametersField;
		},
		set_parameters: function(value) {
			this.$1$ParametersField = value;
		},
		get_isApiCommandName: function ApiCommand$get_IsApiCommandName() {
			return this.get_rawName().indexOf('api.', 0) === 0;
		},
		get_rawName: function ApiCommand$get_RawName() {
			return this.get_name().toString();
		},
		serialize: function ApiCommand$Serialize() {
			var message = [];
			message.push(this.get_name());
			message.push(this.get_commandId());
			message.push(this.get_hostId());
			if (ss.isValue(this.get_parameters())) {
				message.push(this.get_parameters());
			}
			var serializedMessage = message.join(',');
			$tab__ApiCommand.lastRequestMessage = serializedMessage;
			return serializedMessage;
		}
	});
	ss.initClass($tab__ApiObjectRegistry, $asm, {});
	ss.initClass($tab__ApiServerNotification, $asm, {
		get_workbookName: function ApiServerNotification$get_WorkbookName() {
			return this.$workbookName;
		},
		get_worksheetName: function ApiServerNotification$get_WorksheetName() {
			return this.$worksheetName;
		},
		get_data: function ApiServerNotification$get_Data() {
			return this.$data;
		},
		serialize: function ApiServerNotification$Serialize() {
			var serialized = {};
			serialized['api.workbookName'] = this.$workbookName;
			serialized['api.worksheetName'] = this.$worksheetName;
			serialized['api.commandData'] = this.$data;
			return JSON.stringify(serialized);
		}
	});
	ss.initClass($tab__ApiServerResultParser, $asm, {
		get_result: function ApiServerResultParser$get_Result() {
			return this.$commandResult;
		},
		get_data: function ApiServerResultParser$get_Data() {
			return this.$commandData;
		}
	});
	ss.initClass($tab__CollectionImpl, $asm, {
		get__length: function DoNotUseCollection$get_Length() {
			return this.$items.length;
		},
		get__rawArray: function DoNotUseCollection$get_RawArray() {
			return this.$items;
		},
		get_item: function DoNotUseCollection$get_Item(index) {
			return this.$items[index];
		},
		_get: function DoNotUseCollection$Get(key) {
			var validKey = this.$ensureValidKey(key);
			if (ss.isValue(this.$itemMap[validKey])) {
				return this.$itemMap[validKey];
			}
			return undefined;
		},
		_has: function DoNotUseCollection$Has(key) {
			return ss.isValue(this._get(key));
		},
		_add: function DoNotUseCollection$Add(key, item) {
			this.$verifyKeyAndItemParameters(key, item);
			var validKey = this.$ensureValidKey(key);
			this.$items.push(item);
			this.$itemMap[validKey] = item;
		},
		_addToFirst: function DoNotUseCollection$AddToFirst(key, item) {
			this.$verifyKeyAndItemParameters(key, item);
			var validKey = this.$ensureValidKey(key);
			this.$items.unshift(item);
			this.$itemMap[validKey] = item;
		},
		_remove: function DoNotUseCollection$Remove(key) {
			var validKey = this.$ensureValidKey(key);
			if (ss.isValue(this.$itemMap[validKey])) {
				var item = this.$itemMap[validKey];
				delete this.$itemMap[validKey];
				for (var index = 0; index < this.$items.length; index++) {
					if (ss.referenceEquals(this.$items[index], item)) {
						this.$items.splice(index, 1);
						break;
					}
				}
			}
		},
		_toApiCollection: function DoNotUseCollection$ToApiCollection() {
			var clone = this.$items.concat();
			clone.get = ss.mkdel(this, function(key) {
				return this._get(key);
			});
			clone.has = ss.mkdel(this, function(key1) {
				return this._has(key1);
			});
			return clone;
		},
		$verifyUniqueKeyParameter: function DoNotUseCollection$VerifyUniqueKeyParameter(key) {
			if ($tab__Utility.isNullOrEmpty(key)) {
				throw new ss.Exception('Null key');
			}
			if (this._has(key)) {
				throw new ss.Exception("Duplicate key '" + key + "'");
			}
		},
		$verifyKeyAndItemParameters: function DoNotUseCollection$VerifyKeyAndItemParameters(key, item) {
			this.$verifyUniqueKeyParameter(key);
			if (ss.isNullOrUndefined(item)) {
				throw new ss.Exception('Null item');
			}
		},
		$ensureValidKey: function DoNotUseCollection$EnsureValidKey(key) {
			return '_' + key;
		}
	});
	ss.initClass($tab__ColumnImpl, $asm, {
		get_fieldName: function ColumnImpl$get_FieldName() {
			return this.$fieldName;
		},
		get_dataType: function ColumnImpl$get_DataType() {
			return this.$dataType;
		},
		get_isReferenced: function ColumnImpl$get_IsReferenced() {
			return this.$isReferenced;
		},
		get_index: function ColumnImpl$get_Index() {
			return this.$index;
		}
	});
	ss.initClass($tab__CustomViewImpl, $asm, {
		get_$customView: function CustomViewImpl$get_CustomView() {
			if (ss.isNullOrUndefined(this.$customView)) {
				this.$customView = new $tableauSoftware_CustomView(this);
			}
			return this.$customView;
		},
		get_$workbook: function CustomViewImpl$get_Workbook() {
			return this.$workbookImpl.get_workbook();
		},
		get_$url: function CustomViewImpl$get_Url() {
			return this.$url;
		},
		get_$name: function CustomViewImpl$get_Name() {
			return this.$name;
		},
		set_$name: function CustomViewImpl$set_Name(value) {
			if (this.$isStale) {
				throw $tab__TableauException.create('staleDataReference', 'Stale data');
			}
			this.$name = value;
		},
		get_$ownerName: function CustomViewImpl$get_OwnerName() {
			return this.$ownerName;
		},
		get_$advertised: function CustomViewImpl$get_Advertised() {
			return this.$isPublic;
		},
		set_$advertised: function CustomViewImpl$set_Advertised(value) {
			if (this.$isStale) {
				throw $tab__TableauException.create('staleDataReference', 'Stale data');
			}
			this.$isPublic = value;
		},
		get_$isDefault: function CustomViewImpl$get_IsDefault() {
			return this.$isDefault;
		},
		$saveAsync: function CustomViewImpl$SaveAsync() {
			if (this.$isStale || ss.isNullOrUndefined(this.$presModel)) {
				throw $tab__TableauException.create('staleDataReference', 'Stale data');
			}
			this.$presModel.isPublic = this.$isPublic;
			this.$presModel.name = this.$name;
			var deferred = new tab._Deferred();
			var param = {};
			param['api.customViewParam'] = this.$presModel;
			var returnHandler = $tab__CustomViewImpl.$createCustomViewCommandReturnHandler('api.UpdateCustomViewCommand', deferred, ss.mkdel(this, function(result) {
				$tab__CustomViewImpl._processCustomViewUpdate(this.$workbookImpl, this.$messagingOptions, result, true);
				deferred.resolve(this.get_$customView());
			}));
			this.$messagingOptions.sendCommand(Object).call(this.$messagingOptions, param, returnHandler);
			return deferred.get_promise();
		},
		$removeAsync: function CustomViewImpl$RemoveAsync() {
			var deferred = new tab._Deferred();
			var param = {};
			param['api.customViewParam'] = this.$presModel;
			var returnHandler = $tab__CustomViewImpl.$createCustomViewCommandReturnHandler('api.RemoveCustomViewCommand', deferred, ss.mkdel(this, function(result) {
				this.$isStale = true;
				$tab__CustomViewImpl._processCustomViews(this.$workbookImpl, this.$messagingOptions, result);
				deferred.resolve(this.get_$customView());
			}));
			this.$messagingOptions.sendCommand(Object).call(this.$messagingOptions, param, returnHandler);
			return deferred.get_promise();
		},
		_showAsync: function CustomViewImpl$ShowAsync() {
			if (this.$isStale || ss.isNullOrUndefined(this.$presModel)) {
				throw $tab__TableauException.create('staleDataReference', 'Stale data');
			}
			return $tab__CustomViewImpl._showCustomViewAsync(this.$workbookImpl, this.$messagingOptions, this.$presModel);
		},
		$isDifferent: function CustomViewImpl$IsDifferent(other) {
			return !ss.referenceEquals(this.$ownerName, other.$ownerName) || !ss.referenceEquals(this.$url, other.$url) || this.$isPublic !== other.$isPublic || this.$isDefault !== other.$isDefault;
		}
	});
	ss.initClass($tab__SheetImpl, $asm, {
		get_sheet: null,
		get_name: function SheetImpl$get_Name() {
			return this.$name;
		},
		get_index: function SheetImpl$get_Index() {
			return this.$index;
		},
		get_workbookImpl: function SheetImpl$get_WorkbookImpl() {
			return this.$workbookImpl;
		},
		get_workbook: function SheetImpl$get_Workbook() {
			return this.$workbookImpl.get_workbook();
		},
		get_url: function SheetImpl$get_Url() {
			if (this.$isHidden) {
				throw $tab__TableauException.createNoUrlForHiddenWorksheet();
			}
			return this.$url;
		},
		get_size: function SheetImpl$get_Size() {
			return this.$size;
		},
		get_isHidden: function SheetImpl$get_IsHidden() {
			return this.$isHidden;
		},
		get_isActive: function SheetImpl$get_IsActive() {
			return this.$isActive;
		},
		set_isActive: function SheetImpl$set_IsActive(value) {
			this.$isActive = value;
		},
		get_isDashboard: function SheetImpl$get_IsDashboard() {
			return this.$sheetType === 'dashboard';
		},
		get_isStory: function SheetImpl$get_IsStory() {
			return this.$sheetType === 'story';
		},
		get_sheetType: function SheetImpl$get_SheetType() {
			return this.$sheetType;
		},
		get_parentStoryPoint: function SheetImpl$get_ParentStoryPoint() {
			if (ss.isValue(this.$parentStoryPointImpl)) {
				return this.$parentStoryPointImpl.get_storyPoint();
			}
			return null;
		},
		get_parentStoryPointImpl: function SheetImpl$get_ParentStoryPointImpl() {
			return this.$parentStoryPointImpl;
		},
		set_parentStoryPointImpl: function SheetImpl$set_ParentStoryPointImpl(value) {
			if (this.$sheetType === 'story') {
				throw $tab__TableauException.createInternalError('A story cannot be a child of another story.');
			}
			this.$parentStoryPointImpl = value;
		},
		get_zoneId: function SheetImpl$get_ZoneId() {
			return this.$zoneId;
		},
		get_messagingOptions: function SheetImpl$get_MessagingOptions() {
			return this.$messagingOptions;
		},
		changeSizeAsync: function SheetImpl$ChangeSizeAsync(newSize) {
			newSize = $tab__SheetImpl.$normalizeSheetSize(newSize);
			if (this.$sheetType === 'worksheet' && newSize.behavior !== 'automatic') {
				throw $tab__TableauException.createInvalidSizeBehaviorOnWorksheet();
			}
			var deferred = new tab._Deferred();
			if (this.$size.behavior === newSize.behavior && newSize.behavior === 'automatic') {
				deferred.resolve(newSize);
				return deferred.get_promise();
			}
			var dict = this.$processSheetSize(newSize);
			var param = {};
			param['api.setSheetSizeName'] = this.$name;
			param['api.minWidth'] = dict['api.minWidth'];
			param['api.minHeight'] = dict['api.minHeight'];
			param['api.maxWidth'] = dict['api.maxWidth'];
			param['api.maxHeight'] = dict['api.maxHeight'];
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.SetSheetSizeCommand', 1, ss.mkdel(this, function(result) {
				this.get_workbookImpl()._update(ss.mkdel(this, function() {
					var updatedSize = this.get_workbookImpl().get_publishedSheets()._get(this.get_name()).getSize();
					deferred.resolve(updatedSize);
				}));
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, param, returnHandler);
			return deferred.get_promise();
		},
		sendCommand: function(T) {
			return function SheetImpl$SendCommand(commandParameters, returnHandler) {
				this.$messagingOptions.sendCommand(T).call(this.$messagingOptions, commandParameters, returnHandler);
			};
		},
		$processSheetSize: function SheetImpl$ProcessSheetSize(newSize) {
			var fixedSheetSize = null;
			if (ss.isNullOrUndefined(newSize) || ss.isNullOrUndefined(newSize.behavior) || newSize.behavior !== 'automatic' && ss.isNullOrUndefined(newSize.minSize) && ss.isNullOrUndefined(newSize.maxSize)) {
				throw $tab__TableauException.createInvalidSheetSizeParam();
			}
			var minWidth = 0;
			var minHeight = 0;
			var maxWidth = 0;
			var maxHeight = 0;
			var dict = {};
			dict['api.minWidth'] = 0;
			dict['api.minHeight'] = 0;
			dict['api.maxWidth'] = 0;
			dict['api.maxHeight'] = 0;
			if (newSize.behavior === 'automatic') {
				fixedSheetSize = $tab_SheetSize.$ctor('automatic', undefined, undefined);
			}
			else if (newSize.behavior === 'atmost') {
				if (ss.isNullOrUndefined(newSize.maxSize) || ss.isNullOrUndefined(newSize.maxSize.width) || ss.isNullOrUndefined(newSize.maxSize.height)) {
					throw $tab__TableauException.createMissingMaxSize();
				}
				if (newSize.maxSize.width < 0 || newSize.maxSize.height < 0) {
					throw $tab__TableauException.createInvalidSizeValue();
				}
				dict['api.maxWidth'] = newSize.maxSize.width;
				dict['api.maxHeight'] = newSize.maxSize.height;
				fixedSheetSize = $tab_SheetSize.$ctor('atmost', undefined, newSize.maxSize);
			}
			else if (newSize.behavior === 'atleast') {
				if (ss.isNullOrUndefined(newSize.minSize) || ss.isNullOrUndefined(newSize.minSize.width) || ss.isNullOrUndefined(newSize.minSize.height)) {
					throw $tab__TableauException.createMissingMinSize();
				}
				if (newSize.minSize.width < 0 || newSize.minSize.height < 0) {
					throw $tab__TableauException.createInvalidSizeValue();
				}
				dict['api.minWidth'] = newSize.minSize.width;
				dict['api.minHeight'] = newSize.minSize.height;
				fixedSheetSize = $tab_SheetSize.$ctor('atleast', newSize.minSize, undefined);
			}
			else if (newSize.behavior === 'range') {
				if (ss.isNullOrUndefined(newSize.minSize) || ss.isNullOrUndefined(newSize.maxSize) || ss.isNullOrUndefined(newSize.minSize.width) || ss.isNullOrUndefined(newSize.maxSize.width) || ss.isNullOrUndefined(newSize.minSize.height) || ss.isNullOrUndefined(newSize.maxSize.height)) {
					throw $tab__TableauException.createMissingMinMaxSize();
				}
				if (newSize.minSize.width < 0 || newSize.minSize.height < 0 || newSize.maxSize.width < 0 || newSize.maxSize.height < 0 || newSize.minSize.width > newSize.maxSize.width || newSize.minSize.height > newSize.maxSize.height) {
					throw $tab__TableauException.createInvalidRangeSize();
				}
				dict['api.minWidth'] = newSize.minSize.width;
				dict['api.minHeight'] = newSize.minSize.height;
				dict['api.maxWidth'] = newSize.maxSize.width;
				dict['api.maxHeight'] = newSize.maxSize.height;
				fixedSheetSize = $tab_SheetSize.$ctor('range', newSize.minSize, newSize.maxSize);
			}
			else if (newSize.behavior === 'exactly') {
				if (ss.isValue(newSize.minSize) && ss.isValue(newSize.maxSize) && ss.isValue(newSize.minSize.width) && ss.isValue(newSize.maxSize.width) && ss.isValue(newSize.minSize.height) && ss.isValue(newSize.maxSize.height)) {
					minWidth = newSize.minSize.width;
					minHeight = newSize.minSize.height;
					maxWidth = newSize.maxSize.width;
					maxHeight = newSize.maxSize.height;
					if (minWidth !== maxWidth || minHeight !== maxHeight) {
						throw $tab__TableauException.createSizeConflictForExactly();
					}
				}
				else if (ss.isValue(newSize.minSize) && ss.isValue(newSize.minSize.width) && ss.isValue(newSize.minSize.height)) {
					minWidth = newSize.minSize.width;
					minHeight = newSize.minSize.height;
					maxWidth = minWidth;
					maxHeight = minHeight;
				}
				else if (ss.isValue(newSize.maxSize) && ss.isValue(newSize.maxSize.width) && ss.isValue(newSize.maxSize.height)) {
					maxWidth = newSize.maxSize.width;
					maxHeight = newSize.maxSize.height;
					minWidth = maxWidth;
					minHeight = maxHeight;
				}
				dict['api.minWidth'] = minWidth;
				dict['api.minHeight'] = minHeight;
				dict['api.maxWidth'] = maxWidth;
				dict['api.maxHeight'] = maxHeight;
				fixedSheetSize = $tab_SheetSize.$ctor('exactly', $tab_Size.$ctor(minWidth, minHeight), $tab_Size.$ctor(maxWidth, maxHeight));
			}
			this.$size = fixedSheetSize;
			return dict;
		}
	});
	ss.initClass($tab__DashboardImpl, $asm, {
		get_sheet: function DashboardImpl$get_Sheet() {
			return this.get_dashboard();
		},
		get_dashboard: function DashboardImpl$get_Dashboard() {
			if (ss.isNullOrUndefined(this.$dashboard)) {
				this.$dashboard = new $tableauSoftware_Dashboard(this);
			}
			return this.$dashboard;
		},
		get_worksheets: function DashboardImpl$get_Worksheets() {
			return this.$worksheets;
		},
		get_objects: function DashboardImpl$get_Objects() {
			return this.$dashboardObjects;
		},
		$addObjects: function DashboardImpl$AddObjects(zones, findSheetFunc) {
			this.$dashboardObjects = new tab._Collection();
			this.$worksheets = new tab._Collection();
			for (var i = 0; i < zones.length; i++) {
				var zone = zones[i];
				var worksheet = null;
				if (zones[i].objectType === 'worksheet') {
					var name = zone.name;
					if (ss.isNullOrUndefined(name)) {
						continue;
					}
					var index = this.$worksheets.get__length();
					var size = $tab_SheetSizeFactory.createAutomatic();
					var isActive = false;
					var publishedSheetInfo = findSheetFunc(name);
					var isHidden = ss.isNullOrUndefined(publishedSheetInfo);
					var url = (isHidden ? '' : publishedSheetInfo.getUrl());
					var sheetInfoImpl = $tab__SheetInfoImpl.$ctor(name, 'worksheet', index, size, this.get_workbook(), url, isActive, isHidden, zone.zoneId);
					var worksheetImpl = new $tab__WorksheetImpl(sheetInfoImpl, this.get_workbookImpl(), this.get_messagingOptions(), this);
					worksheet = worksheetImpl.get_worksheet();
					this.$worksheets._add(name, worksheetImpl.get_worksheet());
				}
				var obj = new $tableauSoftware_DashboardObject(zone, this.get_dashboard(), worksheet);
				this.$dashboardObjects._add(i.toString(), obj);
			}
		}
	}, $tab__SheetImpl);
	ss.initClass($tab__DataSourceImpl, $asm, {
		get_dataSource: function DataSourceImpl$get_DataSource() {
			if (ss.isNullOrUndefined(this.$dataSource)) {
				this.$dataSource = new $tableauSoftware_DataSource(this);
			}
			return this.$dataSource;
		},
		get_name: function DataSourceImpl$get_Name() {
			return this.$name;
		},
		get_fields: function DataSourceImpl$get_Fields() {
			return this.$fields;
		},
		get_isPrimary: function DataSourceImpl$get_IsPrimary() {
			return this.$isPrimary;
		},
		addField: function DataSourceImpl$AddField(field) {
			this.$fields._add(field.getName(), field);
		}
	});
	ss.initClass($tab__DataTableImpl, $asm, {
		get_name: function DataTableImpl$get_Name() {
			return this.$name;
		},
		get_rows: function DataTableImpl$get_Rows() {
			return this.$rows;
		},
		get_columns: function DataTableImpl$get_Columns() {
			return this.$columns;
		},
		get_totalRowCount: function DataTableImpl$get_TotalRowCount() {
			return this.$totalRowCount;
		},
		get_isSummaryData: function DataTableImpl$get_IsSummaryData() {
			return this.$isSummaryData;
		}
	});
	ss.initClass($tab__DeferredImpl, $asm, {
		get_promise: function DoNotUseDeferred$get_Promise() {
			return this.$promise;
		},
		all: function DoNotUseDeferred$All(promisesOrValues) {
			var allDone = new $tab__DeferredImpl();
			var length = promisesOrValues.length;
			var toResolve = length;
			var results = [];
			if (length === 0) {
				allDone.resolve(results);
				return allDone.get_promise();
			}
			var resolveOne = function(promiseOrValue, index) {
				var promise = $tab_$DeferredUtil.$coerceToTrustedPromise(promiseOrValue);
				promise.then(function(returnValue) {
					results[index] = returnValue;
					toResolve--;
					if (toResolve === 0) {
						allDone.resolve(results);
					}
					return null;
				}, function(e) {
					allDone.reject(e);
					return null;
				});
			};
			for (var i = 0; i < length; i++) {
				resolveOne(promisesOrValues[i], i);
			}
			return allDone.get_promise();
		},
		then: function DoNotUseDeferred$Then(callback, errback) {
			return this.$thenFunc(callback, errback);
		},
		resolve: function DoNotUseDeferred$Resolve(promiseOrValue) {
			return this.$resolveFunc(promiseOrValue);
		},
		reject: function DoNotUseDeferred$Reject(e) {
			return this.$resolveFunc($tab_$DeferredUtil.$rejected(e));
		},
		$preResolutionThen: function DoNotUseDeferred$PreResolutionThen(callback, errback) {
			var deferred = new $tab__DeferredImpl();
			this.$listeners.push(function(promise) {
				promise.then(callback, errback).then(ss.mkdel(deferred, deferred.resolve), ss.mkdel(deferred, deferred.reject));
			});
			return deferred.get_promise();
		},
		$transitionToFulfilled: function DoNotUseDeferred$TransitionToFulfilled(completed) {
			var completedPromise = $tab_$DeferredUtil.$coerceToTrustedPromise(completed);
			this.$thenFunc = completedPromise.then;
			this.$resolveFunc = $tab_$DeferredUtil.$coerceToTrustedPromise;
			for (var i = 0; i < this.$listeners.length; i++) {
				var listener = this.$listeners[i];
				listener(completedPromise);
			}
			this.$listeners = null;
			return completedPromise;
		}
	});
	ss.initClass($tab__jQueryShim, $asm, {});
	ss.initClass($tab__Param, $asm, {});
	ss.initClass($tab__PromiseImpl, $asm, {
		always: function DoNotUsePromise$Always(callback) {
			return ss.cast(this.then(callback, ss.cast(callback, Function)), $tab__PromiseImpl);
		},
		otherwise: function DoNotUsePromise$Otherwise(errback) {
			return ss.cast(this.then(null, errback), $tab__PromiseImpl);
		}
	});
	ss.initClass($tab__Rect, $asm, {
		intersect: function TabRect$Intersect(other) {
			var left = Math.max(this.left, other.left);
			var top = Math.max(this.top, other.top);
			var right = Math.min(this.left + this.width, other.left + other.width);
			var bottom = Math.min(this.top + this.height, other.top + other.height);
			if (right <= left || bottom <= top) {
				return new $tab__Rect(0, 0, 0, 0);
			}
			return new $tab__Rect(left, top, right - left, bottom - top);
		}
	});
	ss.initClass($tab__SheetInfoImpl, $asm, {}, Object);
	ss.initClass($tab__StoryImpl, $asm, {
		add_activeStoryPointChange: function StoryImpl$add_ActiveStoryPointChange(value) {
			this.$2$ActiveStoryPointChangeField = ss.delegateCombine(this.$2$ActiveStoryPointChangeField, value);
		},
		remove_activeStoryPointChange: function StoryImpl$remove_ActiveStoryPointChange(value) {
			this.$2$ActiveStoryPointChangeField = ss.delegateRemove(this.$2$ActiveStoryPointChangeField, value);
		},
		get_activeStoryPointImpl: function StoryImpl$get_ActiveStoryPointImpl() {
			return this.$activeStoryPointImpl;
		},
		get_sheet: function StoryImpl$get_Sheet() {
			return this.get_story();
		},
		get_story: function StoryImpl$get_Story() {
			if (ss.isNullOrUndefined(this.$story)) {
				this.$story = new $tableauSoftware_Story(this);
			}
			return this.$story;
		},
		get_storyPointsInfo: function StoryImpl$get_StoryPointsInfo() {
			return this.$storyPointsInfo;
		},
		update: function StoryImpl$Update(storyPm) {
			var activeStoryPointContainedSheetInfo = null;
			var newActiveStoryPointInfoImpl = null;
			this.$storyPointsInfo = this.$storyPointsInfo || new Array(storyPm.storyPoints.length);
			for (var i = 0; i < storyPm.storyPoints.length; i++) {
				var storyPointPm = storyPm.storyPoints[i];
				var caption = storyPointPm.caption;
				var isActive = i === storyPm.activeStoryPointIndex;
				var storyPointInfoImpl = $tab__StoryPointInfoImpl.$ctor(caption, i, storyPointPm.storyPointId, isActive, storyPointPm.isUpdated, this);
				if (ss.isNullOrUndefined(this.$storyPointsInfo[i])) {
					this.$storyPointsInfo[i] = new $tableauSoftware_StoryPointInfo(storyPointInfoImpl);
				}
				else if (this.$storyPointsInfo[i]._impl.storyPointId === storyPointInfoImpl.storyPointId) {
					var existing = this.$storyPointsInfo[i]._impl;
					existing.caption = storyPointInfoImpl.caption;
					existing.index = storyPointInfoImpl.index;
					existing.isActive = isActive;
					existing.isUpdated = storyPointInfoImpl.isUpdated;
				}
				else {
					this.$storyPointsInfo[i] = new $tableauSoftware_StoryPointInfo(storyPointInfoImpl);
				}
				if (isActive) {
					activeStoryPointContainedSheetInfo = storyPointPm.containedSheetInfo;
					newActiveStoryPointInfoImpl = storyPointInfoImpl;
				}
			}
			var deleteCount = this.$storyPointsInfo.length - storyPm.storyPoints.length;
			this.$storyPointsInfo.splice(storyPm.storyPoints.length, deleteCount);
			var activeStoryPointChanged = ss.isNullOrUndefined(this.$activeStoryPointImpl) || this.$activeStoryPointImpl.get_storyPointId() !== newActiveStoryPointInfoImpl.storyPointId;
			if (ss.isValue(this.$activeStoryPointImpl) && activeStoryPointChanged) {
				this.$activeStoryPointImpl.set_isActive(false);
			}
			var previouslyActiveStoryPoint = this.$activeStoryPointImpl;
			if (activeStoryPointChanged) {
				var containedSheetImpl = $tab__StoryPointImpl.createContainedSheet(activeStoryPointContainedSheetInfo, this.get_workbookImpl(), this.get_messagingOptions(), this.$findSheetFunc);
				this.$activeStoryPointImpl = new $tab__StoryPointImpl(newActiveStoryPointInfoImpl, containedSheetImpl);
			}
			else {
				this.$activeStoryPointImpl.set_isActive(newActiveStoryPointInfoImpl.isActive);
				this.$activeStoryPointImpl.set_isUpdated(newActiveStoryPointInfoImpl.isUpdated);
			}
			if (activeStoryPointChanged && ss.isValue(previouslyActiveStoryPoint)) {
				this.$raiseActiveStoryPointChange(this.$storyPointsInfo[previouslyActiveStoryPoint.get_index()], this.$activeStoryPointImpl.get_storyPoint());
			}
		},
		activatePreviousStoryPointAsync: function StoryImpl$ActivatePreviousStoryPointAsync() {
			return this.$activatePreviousNextStoryPointAsync('api.ActivatePreviousStoryPoint');
		},
		activateNextStoryPointAsync: function StoryImpl$ActivateNextStoryPointAsync() {
			return this.$activatePreviousNextStoryPointAsync('api.ActivateNextStoryPoint');
		},
		activateStoryPointAsync: function StoryImpl$ActivateStoryPointAsync(index) {
			var deferred = new tab._Deferred();
			if (index < 0 || index >= this.$storyPointsInfo.length) {
				throw $tab__TableauException.createIndexOutOfRange(index);
			}
			var previouslyActiveStoryPointImpl = this.get_activeStoryPointImpl();
			var commandParameters = {};
			commandParameters['api.storyPointIndex'] = index;
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.ActivateStoryPoint', 0, ss.mkdel(this, function(result) {
				this.$updateActiveState(previouslyActiveStoryPointImpl, result);
				deferred.resolve(this.$activeStoryPointImpl.get_storyPoint());
			}), function(remoteError, errorMessage) {
				deferred.reject($tab__TableauException.createServerError(errorMessage));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		revertStoryPointAsync: function StoryImpl$RevertStoryPointAsync(index) {
			index = index || this.$activeStoryPointImpl.get_index();
			if (index < 0 || index >= this.$storyPointsInfo.length) {
				throw $tab__TableauException.createIndexOutOfRange(index);
			}
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.storyPointIndex'] = index;
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.RevertStoryPoint', 0, ss.mkdel(this, function(result) {
				this.$updateStoryPointInfo(index, result);
				deferred.resolve(this.$storyPointsInfo[index]);
			}), function(remoteError, errorMessage) {
				deferred.reject($tab__TableauException.createServerError(errorMessage));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$activatePreviousNextStoryPointAsync: function StoryImpl$ActivatePreviousNextStoryPointAsync(commandName) {
			if (commandName !== 'api.ActivatePreviousStoryPoint' && commandName !== 'api.ActivateNextStoryPoint') {
				throw $tab__TableauException.createInternalError("commandName '" + commandName + "' is invalid.");
			}
			var deferred = new tab._Deferred();
			var previouslyActiveStoryPointImpl = this.get_activeStoryPointImpl();
			var commandParameters = {};
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))(commandName, 0, ss.mkdel(this, function(result) {
				this.$updateActiveState(previouslyActiveStoryPointImpl, result);
				deferred.resolve(this.$activeStoryPointImpl.get_storyPoint());
			}), function(remoteError, errorMessage) {
				deferred.reject($tab__TableauException.createServerError(errorMessage));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$updateStoryPointInfo: function StoryImpl$UpdateStoryPointInfo(index, newStoryPointPm) {
			var existingImpl = this.$storyPointsInfo[index]._impl;
			if (existingImpl.storyPointId !== newStoryPointPm.storyPointId) {
				throw $tab__TableauException.createInternalError("We should not be updating a story point where the IDs don't match. Existing storyPointID=" + existingImpl.storyPointId + ', newStoryPointID=' + newStoryPointPm.storyPointId);
			}
			existingImpl.caption = newStoryPointPm.caption;
			existingImpl.isUpdated = newStoryPointPm.isUpdated;
			if (newStoryPointPm.storyPointId === this.$activeStoryPointImpl.get_storyPointId()) {
				this.$activeStoryPointImpl.set_isUpdated(newStoryPointPm.isUpdated);
			}
		},
		$updateActiveState: function StoryImpl$UpdateActiveState(previouslyActiveStoryPointImpl, newActiveStoryPointPm) {
			var newActiveIndex = newActiveStoryPointPm.index;
			if (previouslyActiveStoryPointImpl.get_index() === newActiveIndex) {
				return;
			}
			var oldStoryPointInfo = this.$storyPointsInfo[previouslyActiveStoryPointImpl.get_index()];
			var newStoryPointInfoImpl = this.$storyPointsInfo[newActiveIndex]._impl;
			var containedSheetImpl = $tab__StoryPointImpl.createContainedSheet(newActiveStoryPointPm.containedSheetInfo, this.get_workbookImpl(), this.get_messagingOptions(), this.$findSheetFunc);
			newStoryPointInfoImpl.isActive = true;
			this.$activeStoryPointImpl = new $tab__StoryPointImpl(newStoryPointInfoImpl, containedSheetImpl);
			previouslyActiveStoryPointImpl.set_isActive(false);
			oldStoryPointInfo._impl.isActive = false;
			this.$raiseActiveStoryPointChange(oldStoryPointInfo, this.$activeStoryPointImpl.get_storyPoint());
		},
		$raiseActiveStoryPointChange: function StoryImpl$RaiseActiveStoryPointChange(oldStoryPointInfo, newStoryPoint) {
			if (!ss.staticEquals(this.$2$ActiveStoryPointChangeField, null)) {
				this.$2$ActiveStoryPointChangeField(oldStoryPointInfo, newStoryPoint);
			}
		}
	}, $tab__SheetImpl);
	ss.initClass($tab__StoryPointImpl, $asm, {
		get_caption: function StoryPointImpl$get_Caption() {
			return this.$caption;
		},
		get_containedSheetImpl: function StoryPointImpl$get_ContainedSheetImpl() {
			return this.$containedSheetImpl;
		},
		get_index: function StoryPointImpl$get_Index() {
			return this.$index;
		},
		get_isActive: function StoryPointImpl$get_IsActive() {
			return this.$isActive;
		},
		set_isActive: function StoryPointImpl$set_IsActive(value) {
			this.$isActive = value;
		},
		get_isUpdated: function StoryPointImpl$get_IsUpdated() {
			return this.$isUpdated;
		},
		set_isUpdated: function StoryPointImpl$set_IsUpdated(value) {
			this.$isUpdated = value;
		},
		get_parentStoryImpl: function StoryPointImpl$get_ParentStoryImpl() {
			return this.$parentStoryImpl;
		},
		get_storyPoint: function StoryPointImpl$get_StoryPoint() {
			if (ss.isNullOrUndefined(this.$storyPoint)) {
				this.$storyPoint = new $tableauSoftware_StoryPoint(this);
			}
			return this.$storyPoint;
		},
		get_storyPointId: function StoryPointImpl$get_StoryPointId() {
			return this.$storyPointId;
		},
		$toInfoImpl: function StoryPointImpl$ToInfoImpl() {
			return $tab__StoryPointInfoImpl.$ctor(this.$caption, this.$index, this.$storyPointId, this.$isActive, this.$isUpdated, this.$parentStoryImpl);
		}
	});
	ss.initClass($tab__StoryPointInfoImpl, $asm, {}, Object);
	ss.initClass($tab__TableauException, $asm, {});
	ss.initClass($tab__Utility, $asm, {});
	ss.initClass($tab__VizManagerImpl, $asm, {});
	ss.initClass($tab__VizParameters, $asm, {
		get_url: function VizParameters$get_Url() {
			return this.$constructUrl();
		},
		get_baseUrl: function VizParameters$get_BaseUrl() {
			return this.$urlFromApi;
		},
		$constructUrl: function VizParameters$ConstructUrl() {
			var url = [];
			url.push(this.get_baseUrl());
			url.push('?');
			if (this.userSuppliedParameters.length > 0) {
				url.push(this.userSuppliedParameters);
				url.push('&');
			}
			var addClientDimensionForDsd = !this.fixedSize && !(this.userSuppliedParameters.indexOf(':size=') !== -1) && this.parentElement.clientWidth * this.parentElement.clientHeight > 0;
			if (addClientDimensionForDsd) {
				url.push(':size=');
				url.push(this.parentElement.clientWidth + ',' + this.parentElement.clientHeight);
				url.push('&');
			}
			url.push(':embed=y');
			url.push('&:showVizHome=n');
			url.push('&:jsdebug=y');
			if (!this.fixedSize) {
				url.push('&:bootstrapWhenNotified=y');
			}
			if (!this.tabs) {
				url.push('&:tabs=n');
			}
			if (this.displayStaticImage) {
				url.push('&:display_static_image=y');
			}
			if (!this.toolbar) {
				url.push('&:toolbar=n');
			}
			else if (!ss.isNullOrUndefined(this.toolBarPosition)) {
				url.push('&:toolbar=');
				url.push(this.toolBarPosition.toString());
			}
			if (ss.isValue(this.device)) {
				url.push('&:device=');
				url.push(this.device.toString());
			}
			var userOptions = this.$createOptions;
			var $t1 = new ss.ObjectEnumerator(userOptions);
			try {
				while ($t1.moveNext()) {
					var entry = $t1.current();
					if (entry.key !== 'embed' && entry.key !== 'height' && entry.key !== 'width' && entry.key !== 'device' && entry.key !== 'autoSize' && entry.key !== 'hideTabs' && entry.key !== 'hideToolbar' && entry.key !== 'onFirstInteractive' && entry.key !== 'onFirstVizSizeKnown' && entry.key !== 'toolbarPosition' && entry.key !== 'instanceIdToClone' && entry.key !== 'display_static_image') {
						url.push('&');
						url.push(encodeURIComponent(entry.key));
						url.push('=');
						url.push(encodeURIComponent(entry.value.toString()));
					}
				}
			}
			finally {
				$t1.dispose();
			}
			url.push('&:apiID=' + this.hostId);
			if (ss.isValue(this.$createOptions.instanceIdToClone)) {
				url.push('#' + this.$createOptions.instanceIdToClone);
			}
			return url.join('');
		}
	});
	ss.initClass($tab__WorkbookImpl, $asm, {
		get_workbook: function WorkbookImpl$get_Workbook() {
			if (ss.isNullOrUndefined(this.$workbook)) {
				this.$workbook = new $tableauSoftware_Workbook(this);
			}
			return this.$workbook;
		},
		get_viz: function WorkbookImpl$get_Viz() {
			return this.$vizImpl.get_$viz();
		},
		get_publishedSheets: function WorkbookImpl$get_PublishedSheets() {
			return this.$publishedSheetsInfo;
		},
		get_name: function WorkbookImpl$get_Name() {
			return this.$name;
		},
		get_activeSheetImpl: function WorkbookImpl$get_ActiveSheetImpl() {
			return this.$activeSheetImpl;
		},
		get_activeCustomView: function WorkbookImpl$get_ActiveCustomView() {
			return this.$currentCustomView;
		},
		get_isDownloadAllowed: function WorkbookImpl$get_IsDownloadAllowed() {
			return this.$isDownloadAllowed;
		},
		$findActiveSheetOrSheetWithinActiveDashboard: function WorkbookImpl$FindActiveSheetOrSheetWithinActiveDashboard(sheetOrInfoOrName) {
			if (ss.isNullOrUndefined(this.$activeSheetImpl)) {
				return null;
			}
			var sheetName = $tab__WorkbookImpl.$extractSheetName(sheetOrInfoOrName);
			if (ss.isNullOrUndefined(sheetName)) {
				return null;
			}
			if (ss.referenceEquals(sheetName, this.$activeSheetImpl.get_name())) {
				return this.$activeSheetImpl;
			}
			if (this.$activeSheetImpl.get_isDashboard()) {
				var dashboardImpl = ss.cast(this.$activeSheetImpl, $tab__DashboardImpl);
				var sheet = dashboardImpl.get_worksheets()._get(sheetName);
				if (ss.isValue(sheet)) {
					return sheet._impl;
				}
			}
			return null;
		},
		_setActiveSheetAsync: function WorkbookImpl$ActivateSheetAsync(sheetNameOrInfoOrIndex) {
			if ($tab__Utility.isNumber(sheetNameOrInfoOrIndex)) {
				var index = sheetNameOrInfoOrIndex;
				if (index < this.$publishedSheetsInfo.get__length() && index >= 0) {
					return this.$activateSheetWithInfoAsync(this.$publishedSheetsInfo.get_item(index).$impl);
				}
				else {
					throw $tab__TableauException.createIndexOutOfRange(index);
				}
			}
			var sheetName = $tab__WorkbookImpl.$extractSheetName(sheetNameOrInfoOrIndex);
			var sheetInfo = this.$publishedSheetsInfo._get(sheetName);
			if (ss.isValue(sheetInfo)) {
				return this.$activateSheetWithInfoAsync(sheetInfo.$impl);
			}
			else if (this.$activeSheetImpl.get_isDashboard()) {
				var d = ss.cast(this.$activeSheetImpl, $tab__DashboardImpl);
				var sheet = d.get_worksheets()._get(sheetName);
				if (ss.isValue(sheet)) {
					this.$activatingHiddenSheetImpl = null;
					var sheetUrl = '';
					if (sheet.getIsHidden()) {
						this.$activatingHiddenSheetImpl = sheet._impl;
					}
					else {
						sheetUrl = sheet._impl.get_url();
					}
					return this.$activateSheetInternalAsync(sheet._impl.get_name(), sheetUrl);
				}
			}
			throw $tab__TableauException.create('sheetNotInWorkbook', 'Sheet is not found in Workbook');
		},
		_revertAllAsync: function WorkbookImpl$RevertAllAsync() {
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.RevertAllCommand', 1, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.$sendCommand(Object).call(this, null, returnHandler);
			return deferred.get_promise();
		},
		_update: function WorkbookImpl$Update(callback) {
			this.$getClientInfo(callback);
		},
		$activateSheetWithInfoAsync: function WorkbookImpl$ActivateSheetWithInfoAsync(sheetInfoImpl) {
			return this.$activateSheetInternalAsync(sheetInfoImpl.name, sheetInfoImpl.url);
		},
		$activateSheetInternalAsync: function WorkbookImpl$ActivateSheetInternalAsync(sheetName, sheetUrl) {
			var deferred = new tab._Deferred();
			if (ss.isValue(this.$activeSheetImpl) && ss.referenceEquals(sheetName, this.$activeSheetImpl.get_name())) {
				deferred.resolve(this.$activeSheetImpl.get_sheet());
				return deferred.get_promise();
			}
			var param = {};
			param['api.switchToSheetName'] = sheetName;
			param['api.switchToRepositoryUrl'] = sheetUrl;
			param['api.oldRepositoryUrl'] = this.$activeSheetImpl.get_url();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.SwitchActiveSheetCommand', 0, ss.mkdel(this, function(result) {
				this.$vizImpl.$workbookTabSwitchHandler = ss.mkdel(this, function() {
					this.$vizImpl.$workbookTabSwitchHandler = null;
					deferred.resolve(this.$activeSheetImpl.get_sheet());
				});
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.$sendCommand(Object).call(this, param, returnHandler);
			return deferred.get_promise();
		},
		_updateActiveSheetAsync: function WorkbookImpl$UpdateActiveSheetAsync() {
			var deferred = new tab._Deferred();
			var param = {};
			param['api.switchToSheetName'] = this.$activeSheetImpl.get_name();
			param['api.switchToRepositoryUrl'] = this.$activeSheetImpl.get_url();
			param['api.oldRepositoryUrl'] = this.$activeSheetImpl.get_url();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.UpdateActiveSheetCommand', 0, ss.mkdel(this, function(result) {
				deferred.resolve(this.$activeSheetImpl.get_sheet());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.$sendCommand(Object).call(this, param, returnHandler);
			return deferred.get_promise();
		},
		$sendCommand: function(T) {
			return function WorkbookImpl$SendCommand(commandParameters, returnHandler) {
				this.$messagingOptions.sendCommand(T).call(this.$messagingOptions, commandParameters, returnHandler);
			};
		},
		$getClientInfo: function WorkbookImpl$GetClientInfo(callback) {
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetClientInfoCommand', 0, ss.mkdel(this, function(result) {
				this.$processInfo(result);
				if (ss.isValue(callback)) {
					callback();
				}
			}), null);
			this.$sendCommand(Object).call(this, null, returnHandler);
		},
		$processInfo: function WorkbookImpl$ProcessInfo(clientInfo) {
			this.$name = clientInfo.workbookName;
			this.$isDownloadAllowed = clientInfo.isDownloadAllowed;
			this.$vizImpl.$setAreAutomaticUpdatesPaused(!clientInfo.isAutoUpdate);
			this.$vizImpl.set_instanceId(clientInfo.instanceId);
			this.$createSheetsInfo(clientInfo);
			this.$initializeActiveSheet(clientInfo);
		},
		$initializeActiveSheet: function WorkbookImpl$InitializeActiveSheet(clientInfo) {
			var currentSheetName = clientInfo.currentSheetName;
			var newActiveSheetInfo = this.$publishedSheetsInfo._get(currentSheetName);
			if (ss.isNullOrUndefined(newActiveSheetInfo) && ss.isNullOrUndefined(this.$activatingHiddenSheetImpl)) {
				throw $tab__TableauException.createInternalError('The active sheet was not specified in baseSheets');
			}
			if (ss.isValue(this.$activeSheetImpl) && ss.referenceEquals(this.$activeSheetImpl.get_name(), currentSheetName)) {
				return;
			}
			if (ss.isValue(this.$activeSheetImpl)) {
				this.$activeSheetImpl.set_isActive(false);
				var oldActiveSheetInfo = this.$publishedSheetsInfo._get(this.$activeSheetImpl.get_name());
				if (ss.isValue(oldActiveSheetInfo)) {
					oldActiveSheetInfo.$impl.isActive = false;
				}
				if (this.$activeSheetImpl.get_sheetType() === 'story') {
					var storyImpl = ss.cast(this.$activeSheetImpl, $tab__StoryImpl);
					storyImpl.remove_activeStoryPointChange(ss.mkdel(this.$vizImpl, this.$vizImpl.raiseStoryPointSwitch));
				}
			}
			if (ss.isValue(this.$activatingHiddenSheetImpl)) {
				var infoImpl = $tab__SheetInfoImpl.$ctor(this.$activatingHiddenSheetImpl.get_name(), 'worksheet', -1, this.$activatingHiddenSheetImpl.get_size(), this.get_workbook(), '', true, true, $tab__SheetImpl.noZoneId);
				this.$activatingHiddenSheetImpl = null;
				this.$activeSheetImpl = new $tab__WorksheetImpl(infoImpl, this, this.$messagingOptions, null);
			}
			else {
				var baseSheet = null;
				for (var i = 0, len = clientInfo.publishedSheets.length; i < len; i++) {
					if (ss.referenceEquals(clientInfo.publishedSheets[i].name, currentSheetName)) {
						baseSheet = clientInfo.publishedSheets[i];
						break;
					}
				}
				if (ss.isNullOrUndefined(baseSheet)) {
					throw $tab__TableauException.createInternalError('No base sheet was found corresponding to the active sheet.');
				}
				var findSheetFunc = ss.mkdel(this, function(sheetName) {
					return this.$publishedSheetsInfo._get(sheetName);
				});
				if (baseSheet.sheetType === 'dashboard') {
					var dashboardImpl = new $tab__DashboardImpl(newActiveSheetInfo.$impl, this, this.$messagingOptions);
					this.$activeSheetImpl = dashboardImpl;
					var dashboardFrames = $tab__WorkbookImpl.$createDashboardZones(clientInfo.dashboardZones);
					dashboardImpl.$addObjects(dashboardFrames, findSheetFunc);
				}
				else if (baseSheet.sheetType === 'story') {
					var storyImpl1 = new $tab__StoryImpl(newActiveSheetInfo.$impl, this, this.$messagingOptions, clientInfo.story, findSheetFunc);
					this.$activeSheetImpl = storyImpl1;
					storyImpl1.add_activeStoryPointChange(ss.mkdel(this.$vizImpl, this.$vizImpl.raiseStoryPointSwitch));
				}
				else {
					this.$activeSheetImpl = new $tab__WorksheetImpl(newActiveSheetInfo.$impl, this, this.$messagingOptions, null);
				}
				newActiveSheetInfo.$impl.isActive = true;
			}
			this.$activeSheetImpl.set_isActive(true);
		},
		$createSheetsInfo: function WorkbookImpl$CreateSheetsInfo(clientInfo) {
			var baseSheets = clientInfo.publishedSheets;
			if (ss.isNullOrUndefined(baseSheets)) {
				return;
			}
			for (var index = 0; index < baseSheets.length; index++) {
				var baseSheet = baseSheets[index];
				var sheetName = baseSheet.name;
				var sheetInfo = this.$publishedSheetsInfo._get(sheetName);
				var size = $tab__WorkbookImpl.$createSheetSize(baseSheet);
				if (ss.isNullOrUndefined(sheetInfo)) {
					var isActive = ss.referenceEquals(sheetName, clientInfo.currentSheetName);
					var sheetType = $tab_ApiEnumConverter.convertSheetType(baseSheet.sheetType);
					var sheetInfoImpl = $tab__SheetInfoImpl.$ctor(sheetName, sheetType, index, size, this.get_workbook(), baseSheet.repositoryUrl, isActive, false, $tab__SheetImpl.noZoneId);
					sheetInfo = new $tableauSoftware_SheetInfo(sheetInfoImpl);
					this.$publishedSheetsInfo._add(sheetName, sheetInfo);
				}
				else {
					sheetInfo.$impl.size = size;
				}
			}
		},
		get_$customViews: function WorkbookImpl$get_CustomViews() {
			return this.$customViews;
		},
		set_$customViews: function WorkbookImpl$set_CustomViews(value) {
			this.$customViews = value;
		},
		get_$updatedCustomViews: function WorkbookImpl$get_UpdatedCustomViews() {
			return this.$updatedCustomViews;
		},
		set_$updatedCustomViews: function WorkbookImpl$set_UpdatedCustomViews(value) {
			this.$updatedCustomViews = value;
		},
		get_$removedCustomViews: function WorkbookImpl$get_RemovedCustomViews() {
			return this.$removedCustomViews;
		},
		set_$removedCustomViews: function WorkbookImpl$set_RemovedCustomViews(value) {
			this.$removedCustomViews = value;
		},
		get_$currentCustomView: function WorkbookImpl$get_CurrentCustomView() {
			return this.$currentCustomView;
		},
		set_$currentCustomView: function WorkbookImpl$set_CurrentCustomView(value) {
			this.$currentCustomView = value;
		},
		$getCustomViewsAsync: function WorkbookImpl$GetCustomViewsAsync() {
			return $tab__CustomViewImpl._getCustomViewsAsync(this, this.$messagingOptions);
		},
		$showCustomViewAsync: function WorkbookImpl$ShowCustomViewAsync(customViewName) {
			if (ss.isNullOrUndefined(customViewName) || $tab__Utility.isNullOrEmpty(customViewName)) {
				return $tab__CustomViewImpl._showCustomViewAsync(this, this.$messagingOptions, null);
			}
			else {
				var cv = this.$customViews._get(customViewName);
				if (ss.isNullOrUndefined(cv)) {
					var deferred = new tab._Deferred();
					deferred.reject($tab__TableauException.createInvalidCustomViewName(customViewName));
					return deferred.get_promise();
				}
				return cv._impl._showAsync();
			}
		},
		$removeCustomViewAsync: function WorkbookImpl$RemoveCustomViewAsync(customViewName) {
			if ($tab__Utility.isNullOrEmpty(customViewName)) {
				throw $tab__TableauException.createNullOrEmptyParameter('customViewName');
			}
			var cv = this.$customViews._get(customViewName);
			if (ss.isNullOrUndefined(cv)) {
				var deferred = new tab._Deferred();
				deferred.reject($tab__TableauException.createInvalidCustomViewName(customViewName));
				return deferred.get_promise();
			}
			return cv._impl.$removeAsync();
		},
		$rememberCustomViewAsync: function WorkbookImpl$RememberCustomViewAsync(customViewName) {
			if ($tab__Utility.isNullOrEmpty(customViewName)) {
				throw $tab__TableauException.createInvalidParameter('customViewName');
			}
			return $tab__CustomViewImpl._saveNewAsync(this, this.$messagingOptions, customViewName);
		},
		$setActiveCustomViewAsDefaultAsync: function WorkbookImpl$SetActiveCustomViewAsDefaultAsync() {
			return $tab__CustomViewImpl._makeCurrentCustomViewDefaultAsync(this, this.$messagingOptions);
		},
		get_$lastChangedParameterImpl: function WorkbookImpl$get_LastChangedParameterImpl() {
			return this.$lastChangedParameterImpl;
		},
		set_$lastChangedParameterImpl: function WorkbookImpl$set_LastChangedParameterImpl(value) {
			this.$lastChangedParameterImpl = value;
		},
		get_$parameters: function WorkbookImpl$get_Parameters() {
			return this.$parameters;
		},
		$getSingleParameterAsync: function WorkbookImpl$GetSingleParameterAsync(parameterName) {
			var deferred = new tab._Deferred();
			if (ss.isValue(this.$lastChangedParameterImpl)) {
				deferred.resolve(this.$lastChangedParameterImpl.get_$parameter());
				return deferred.get_promise();
			}
			var commandParameters = {};
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.FetchParametersCommand', 0, ss.mkdel(this, function(result) {
				var parameterImpl = $tab__WorkbookImpl.$findAndCreateParameterImpl(parameterName, result);
				this.$lastChangedParameterImpl = parameterImpl;
				deferred.resolve(parameterImpl.get_$parameter());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.$sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getParametersAsync: function WorkbookImpl$GetParametersAsync() {
			var deferred = new tab._Deferred();
			var commandParameters = {};
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.FetchParametersCommand', 0, ss.mkdel(this, function(result) {
				this.$parameters = $tab__WorkbookImpl.$processParameters(result);
				deferred.resolve(this.get_$parameters()._toApiCollection());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.$sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$changeParameterValueAsync: function WorkbookImpl$ChangeParameterValueAsync(parameterName, value) {
			var deferred = new tab._Deferred();
			var parameterImpl = null;
			if (ss.isValue(this.$parameters)) {
				if (ss.isNullOrUndefined(this.$parameters._get(parameterName))) {
					deferred.reject($tab__TableauException.createInvalidParameter(parameterName));
					return deferred.get_promise();
				}
				parameterImpl = this.$parameters._get(parameterName)._impl;
				if (ss.isNullOrUndefined(parameterImpl)) {
					deferred.reject($tab__TableauException.createInvalidParameter(parameterName));
					return deferred.get_promise();
				}
			}
			var param = {};
			param['api.setParameterName'] = (ss.isValue(this.$parameters) ? parameterImpl.get_$name() : parameterName);
			if (ss.isValue(value) && $tab__Utility.isDate(value)) {
				var date = ss.cast(value, ss.JsDate);
				var dateStr = $tab__Utility.serializeDateForServer(date);
				param['api.setParameterValue'] = dateStr;
			}
			else {
				param['api.setParameterValue'] = (ss.isValue(value) ? value.toString() : null);
			}
			this.$lastChangedParameterImpl = null;
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.SetParameterValueCommand', 0, ss.mkdel(this, function(result) {
				if (ss.isNullOrUndefined(result)) {
					deferred.reject($tab__TableauException.create('serverError', 'server error'));
					return;
				}
				if (!result.isValidPresModel) {
					deferred.reject($tab__TableauException.createInvalidParameter(parameterName));
					return;
				}
				var paramUpdated = new $tab_$ParameterImpl(result);
				this.$lastChangedParameterImpl = paramUpdated;
				deferred.resolve(paramUpdated.get_$parameter());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createInvalidParameter(parameterName));
			});
			this.$sendCommand(Object).call(this, param, returnHandler);
			return deferred.get_promise();
		}
	});
	ss.initClass($tab__WorksheetImpl, $asm, {
		get_sheet: function WorksheetImpl$get_Sheet() {
			return this.get_worksheet();
		},
		get_worksheet: function WorksheetImpl$get_Worksheet() {
			if (ss.isNullOrUndefined(this.$worksheet)) {
				this.$worksheet = new $tableauSoftware_Worksheet(this);
			}
			return this.$worksheet;
		},
		get_parentDashboardImpl: function WorksheetImpl$get_ParentDashboardImpl() {
			return this.$parentDashboardImpl;
		},
		get_parentDashboard: function WorksheetImpl$get_ParentDashboard() {
			if (ss.isValue(this.$parentDashboardImpl)) {
				return this.$parentDashboardImpl.get_dashboard();
			}
			return null;
		},
		$getDataSourcesAsync: function WorksheetImpl$GetDataSourcesAsync() {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.worksheetName'] = this.get_name();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetDataSourcesCommand', 0, function(result) {
				var dataSources = $tab__DataSourceImpl.processDataSourcesForWorksheet(result);
				deferred.resolve(dataSources._toApiCollection());
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getDataSourceAsync: function WorksheetImpl$GetDataSourceAsync(dataSourceName) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.dataSourceName'] = dataSourceName;
			commandParameters['api.worksheetName'] = this.get_name();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetDataSourceCommand', 0, function(result) {
				var dataSourceImpl = $tab__DataSourceImpl.processDataSource(result);
				if (ss.isValue(dataSourceImpl)) {
					deferred.resolve(dataSourceImpl.get_dataSource());
				}
				else {
					deferred.reject($tab__TableauException.createServerError("Data source '" + dataSourceName + "' not found"));
				}
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$verifyActiveSheetOrEmbeddedInActiveDashboard: function WorksheetImpl$VerifyActiveSheetOrEmbeddedInActiveDashboard() {
			var isRootAndActiveWorksheet = this.get_isActive();
			var isWithinActiveDashboard = ss.isValue(this.$parentDashboardImpl) && this.$parentDashboardImpl.get_isActive();
			var isWithinActiveStoryPoint = ss.isValue(this.get_parentStoryPointImpl()) && this.get_parentStoryPointImpl().get_parentStoryImpl().get_isActive();
			if (!isRootAndActiveWorksheet && !isWithinActiveDashboard && !isWithinActiveStoryPoint) {
				throw $tab__TableauException.createNotActiveSheet();
			}
		},
		$addVisualIdToCommand: function WorksheetImpl$AddVisualIdToCommand(commandParameters) {
			if (ss.isValue(this.get_parentStoryPointImpl())) {
				var visualId = {};
				visualId.worksheet = this.get_name();
				visualId.dashboard = (ss.isValue(this.get_parentDashboardImpl()) ? this.$parentDashboardImpl.get_name() : this.get_name());
				visualId.flipboardZoneId = this.get_parentStoryPointImpl().get_containedSheetImpl().get_zoneId();
				visualId.storyboard = this.get_parentStoryPointImpl().get_parentStoryImpl().get_name();
				visualId.storyPointId = this.get_parentStoryPointImpl().get_storyPointId();
				commandParameters['api.visualId'] = visualId;
			}
			else {
				commandParameters['api.worksheetName'] = this.get_name();
				if (ss.isValue(this.get_parentDashboardImpl())) {
					commandParameters['api.dashboardName'] = this.get_parentDashboardImpl().get_name();
				}
			}
		},
		get__filters: function WorksheetImpl$get_Filters() {
			return this.$filters;
		},
		set__filters: function WorksheetImpl$set_Filters(value) {
			this.$filters = value;
		},
		$getFilterAsync: function WorksheetImpl$GetFilterAsync(fieldName, fieldCaption, options) {
			if (!$tab__Utility.isNullOrEmpty(fieldName) && !$tab__Utility.isNullOrEmpty(fieldCaption)) {
				throw $tab__TableauException.createInternalError('Only fieldName OR fieldCaption is allowed, not both.');
			}
			options = options || new Object();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			if (!$tab__Utility.isNullOrEmpty(fieldCaption) && $tab__Utility.isNullOrEmpty(fieldName)) {
				commandParameters['api.fieldCaption'] = fieldCaption;
			}
			if (!$tab__Utility.isNullOrEmpty(fieldName)) {
				commandParameters['api.fieldName'] = fieldName;
			}
			commandParameters['api.filterHierarchicalLevels'] = 0;
			commandParameters['api.ignoreDomain'] = options.ignoreDomain || false;
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetOneFilterInfoCommand', 0, ss.mkdel(this, function(result) {
				var error = $tab__WorksheetImpl.$filterCommandError(result);
				if (ss.isNullOrUndefined(error)) {
					var filterJson = result;
					var filter = $tableauSoftware_Filter.$createFilter(this, filterJson);
					deferred.resolve(filter);
				}
				else {
					deferred.reject(error);
				}
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getFiltersAsync: function WorksheetImpl$GetFiltersAsync(options) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			options = options || new Object();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			commandParameters['api.ignoreDomain'] = options.ignoreDomain || false;
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetFiltersListCommand', 0, ss.mkdel(this, function(result) {
				this.set__filters($tableauSoftware_Filter.processFiltersList(this, result));
				deferred.resolve(this.get__filters()._toApiCollection());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$applyFilterAsync: function WorksheetImpl$ApplyFilterAsync(fieldName, values, updateType, options) {
			return this.$applyFilterWithValuesInternalAsync(fieldName, values, updateType, options);
		},
		$clearFilterAsync: function WorksheetImpl$ClearFilterAsync(fieldName) {
			return this.$clearFilterInternalAsync(fieldName);
		},
		$applyRangeFilterAsync: function WorksheetImpl$ApplyRangeFilterAsync(fieldName, options) {
			var fixedUpFilterOptions = $tab__WorksheetImpl.$normalizeRangeFilterOption(options);
			return this.$applyRangeFilterInternalAsync(fieldName, fixedUpFilterOptions);
		},
		$applyRelativeDateFilterAsync: function WorksheetImpl$ApplyRelativeDateFilterAsync(fieldName, options) {
			var fixedUpFilterOptions = $tab__WorksheetImpl.$normalizeRelativeDateFilterOptions(options);
			return this.$applyRelativeDateFilterInternalAsync(fieldName, fixedUpFilterOptions);
		},
		$applyHierarchicalFilterAsync: function WorksheetImpl$ApplyHierarchicalFilterAsync(fieldName, values, updateType, options) {
			if (ss.isNullOrUndefined(values) && updateType !== 'all') {
				throw $tab__TableauException.createInvalidParameter('values');
			}
			return this.$applyHierarchicalFilterInternalAsync(fieldName, values, updateType, options);
		},
		$clearFilterInternalAsync: function WorksheetImpl$ClearFilterInternalAsync(fieldName) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if ($tab__Utility.isNullOrEmpty(fieldName)) {
				throw $tab__TableauException.createNullOrEmptyParameter('fieldName');
			}
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = $tab__WorksheetImpl.$createFilterCommandReturnHandler('api.ClearFilterCommand', fieldName, deferred);
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$applyFilterWithValuesInternalAsync: function WorksheetImpl$ApplyFilterWithValuesInternalAsync(fieldName, values, updateType, options) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if ($tab__Utility.isNullOrEmpty(fieldName)) {
				throw $tab__TableauException.createNullOrEmptyParameter('fieldName');
			}
			updateType = $tab_$PublicEnums.$normalizeEnum($tab_ApiFilterUpdateType).call(null, updateType, 'updateType');
			var fieldValues = [];
			if ($tab__jQueryShim.isArray(values)) {
				for (var i = 0; i < values.length; i++) {
					fieldValues.push(values[i].toString());
				}
			}
			else if (ss.isValue(values)) {
				fieldValues.push(values.toString());
			}
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			commandParameters['api.filterUpdateType'] = updateType;
			commandParameters['api.exclude'] = ((ss.isValue(options) && options.isExcludeMode) ? true : false);
			if (updateType !== 'all') {
				commandParameters['api.filterCategoricalValues'] = fieldValues;
			}
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = $tab__WorksheetImpl.$createFilterCommandReturnHandler('api.ApplyCategoricalFilterCommand', fieldName, deferred);
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$applyRangeFilterInternalAsync: function WorksheetImpl$ApplyRangeFilterInternalAsync(fieldName, filterOptions) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if ($tab__Utility.isNullOrEmpty(fieldName)) {
				throw $tab__TableauException.createNullOrEmptyParameter('fieldName');
			}
			if (ss.isNullOrUndefined(filterOptions)) {
				throw $tab__TableauException.createNullOrEmptyParameter('filterOptions');
			}
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			if (ss.isValue(filterOptions.min)) {
				if ($tab__Utility.isDate(filterOptions.min)) {
					var dt = ss.cast(filterOptions.min, ss.JsDate);
					if ($tab__Utility.isDateValid(dt)) {
						commandParameters['api.filterRangeMin'] = $tab__Utility.serializeDateForServer(dt);
					}
					else {
						throw $tab__TableauException.createInvalidDateParameter('filterOptions.min');
					}
				}
				else {
					commandParameters['api.filterRangeMin'] = filterOptions.min;
				}
			}
			if (ss.isValue(filterOptions.max)) {
				if ($tab__Utility.isDate(filterOptions.max)) {
					var dt1 = ss.cast(filterOptions.max, ss.JsDate);
					if ($tab__Utility.isDateValid(dt1)) {
						commandParameters['api.filterRangeMax'] = $tab__Utility.serializeDateForServer(dt1);
					}
					else {
						throw $tab__TableauException.createInvalidDateParameter('filterOptions.max');
					}
				}
				else {
					commandParameters['api.filterRangeMax'] = filterOptions.max;
				}
			}
			if (ss.isValue(filterOptions.nullOption)) {
				commandParameters['api.filterRangeNullOption'] = filterOptions.nullOption;
			}
			this.$addVisualIdToCommand(commandParameters);
			var deferred = new tab._Deferred();
			var returnHandler = $tab__WorksheetImpl.$createFilterCommandReturnHandler('api.ApplyRangeFilterCommand', fieldName, deferred);
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$applyRelativeDateFilterInternalAsync: function WorksheetImpl$ApplyRelativeDateFilterInternalAsync(fieldName, filterOptions) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if ($tab__Utility.isNullOrEmpty(fieldName)) {
				throw $tab__TableauException.createInvalidParameter('fieldName');
			}
			else if (ss.isNullOrUndefined(filterOptions)) {
				throw $tab__TableauException.createInvalidParameter('filterOptions');
			}
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			if (ss.isValue(filterOptions)) {
				commandParameters['api.filterPeriodType'] = filterOptions.periodType;
				commandParameters['api.filterDateRangeType'] = filterOptions.rangeType;
				if (filterOptions.rangeType === 'lastn' || filterOptions.rangeType === 'nextn') {
					if (ss.isNullOrUndefined(filterOptions.rangeN)) {
						throw $tab__TableauException.create('missingRangeNForRelativeDateFilters', 'Missing rangeN field for a relative date filter of LASTN or NEXTN.');
					}
					commandParameters['api.filterDateRange'] = filterOptions.rangeN;
				}
				if (ss.isValue(filterOptions.anchorDate)) {
					commandParameters['api.filterDateArchorValue'] = $tab__Utility.serializeDateForServer(filterOptions.anchorDate);
				}
			}
			this.$addVisualIdToCommand(commandParameters);
			var deferred = new tab._Deferred();
			var returnHandler = $tab__WorksheetImpl.$createFilterCommandReturnHandler('api.ApplyRelativeDateFilterCommand', fieldName, deferred);
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$applyHierarchicalFilterInternalAsync: function WorksheetImpl$ApplyHierarchicalFilterInternalAsync(fieldName, values, updateType, options) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if ($tab__Utility.isNullOrEmpty(fieldName)) {
				throw $tab__TableauException.createNullOrEmptyParameter('fieldName');
			}
			updateType = $tab_$PublicEnums.$normalizeEnum($tab_ApiFilterUpdateType).call(null, updateType, 'updateType');
			var fieldValues = null;
			var levelValues = null;
			if ($tab__jQueryShim.isArray(values)) {
				fieldValues = [];
				var arr = values;
				for (var i = 0; i < arr.length; i++) {
					fieldValues.push(arr[i].toString());
				}
			}
			else if ($tab__Utility.isString(values)) {
				fieldValues = [];
				fieldValues.push(values.toString());
			}
			else if (ss.isValue(values) && ss.isValue(values['levels'])) {
				var levelValue = values['levels'];
				levelValues = [];
				if ($tab__jQueryShim.isArray(levelValue)) {
					var levels = levelValue;
					for (var i1 = 0; i1 < levels.length; i1++) {
						levelValues.push(levels[i1].toString());
					}
				}
				else {
					levelValues.push(levelValue.toString());
				}
			}
			else if (ss.isValue(values)) {
				throw $tab__TableauException.createInvalidParameter('values');
			}
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			commandParameters['api.filterUpdateType'] = updateType;
			commandParameters['api.exclude'] = ((ss.isValue(options) && options.isExcludeMode) ? true : false);
			if (ss.isValue(fieldValues)) {
				commandParameters['api.filterHierarchicalValues'] = JSON.stringify(fieldValues);
			}
			if (ss.isValue(levelValues)) {
				commandParameters['api.filterHierarchicalLevels'] = JSON.stringify(levelValues);
			}
			this.$addVisualIdToCommand(commandParameters);
			var deferred = new tab._Deferred();
			var returnHandler = $tab__WorksheetImpl.$createFilterCommandReturnHandler('api.ApplyHierarchicalFilterCommand', fieldName, deferred);
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		get_selectedMarks: function WorksheetImpl$get_SelectedMarks() {
			return this.$selectedMarks;
		},
		set_selectedMarks: function WorksheetImpl$set_SelectedMarks(value) {
			this.$selectedMarks = value;
		},
		$clearSelectedMarksAsync: function WorksheetImpl$ClearSelectedMarksAsync() {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.ClearSelectedMarksCommand', 1, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$selectMarksAsync: function WorksheetImpl$SelectMarksAsync(fieldNameOrFieldValuesMap, valueOrUpdateType, updateType) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			if (ss.isNullOrUndefined(fieldNameOrFieldValuesMap) && ss.isNullOrUndefined(valueOrUpdateType)) {
				return this.$clearSelectedMarksAsync();
			}
			if ($tab__Utility.isString(fieldNameOrFieldValuesMap) && ($tab__jQueryShim.isArray(valueOrUpdateType) || $tab__Utility.isString(valueOrUpdateType) || !$tab_$PublicEnums.$isValidEnum($tab_ApiSelectionUpdateType).call(null, valueOrUpdateType))) {
				return this.$selectMarksWithFieldNameAndValueAsync(ss.cast(fieldNameOrFieldValuesMap, String), valueOrUpdateType, updateType);
			}
			else if ($tab__jQueryShim.isArray(fieldNameOrFieldValuesMap)) {
				return this.$selectMarksWithMarksArrayAsync(fieldNameOrFieldValuesMap, ss.cast(valueOrUpdateType, String));
			}
			else {
				return this.$selectMarksWithMultiDimOptionAsync(fieldNameOrFieldValuesMap, ss.cast(valueOrUpdateType, String));
			}
		},
		$getSelectedMarksAsync: function WorksheetImpl$GetSelectedMarksAsync() {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.FetchSelectedMarksCommand', 0, ss.mkdel(this, function(result) {
				this.$selectedMarks = $tab_$MarkImpl.$processActiveMarks(result);
				deferred.resolve(this.$selectedMarks._toApiCollection());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$selectMarksWithFieldNameAndValueAsync: function WorksheetImpl$SelectMarksWithFieldNameAndValueAsync(fieldName, value, updateType) {
			var catNameList = [];
			var catValueList = [];
			var hierNameList = [];
			var hierValueList = [];
			var rangeNameList = [];
			var rangeValueList = [];
			this.$parseMarksParam(catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, fieldName, value);
			return this.$selectMarksWithValuesAsync(null, catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, updateType);
		},
		$selectMarksWithMultiDimOptionAsync: function WorksheetImpl$SelectMarksWithMultiDimOptionAsync(fieldValuesMap, updateType) {
			var dict = fieldValuesMap;
			var catNameList = [];
			var catValueList = [];
			var hierNameList = [];
			var hierValueList = [];
			var rangeNameList = [];
			var rangeValueList = [];
			var $t1 = new ss.ObjectEnumerator(dict);
			try {
				while ($t1.moveNext()) {
					var ent = $t1.current();
					if (fieldValuesMap.hasOwnProperty(ent.key)) {
						if (!$tab__jQueryShim.isFunction(dict[ent.key])) {
							this.$parseMarksParam(catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, ent.key, ent.value);
						}
					}
				}
			}
			finally {
				$t1.dispose();
			}
			return this.$selectMarksWithValuesAsync(null, catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, updateType);
		},
		$selectMarksWithMarksArrayAsync: function WorksheetImpl$SelectMarksWithMarksArrayAsync(marksArray, updateType) {
			var catNameList = [];
			var catValueList = [];
			var hierNameList = [];
			var hierValueList = [];
			var rangeNameList = [];
			var rangeValueList = [];
			var tupleIdList = [];
			for (var i = 0; i < marksArray.length; i++) {
				var mark = marksArray[i];
				if (ss.isValue(mark.$impl.get_$tupleId()) && mark.$impl.get_$tupleId() > 0) {
					tupleIdList.push(mark.$impl.get_$tupleId());
				}
				else {
					var pairs = mark.$impl.get_$pairs();
					for (var j = 0; j < pairs.get__length(); j++) {
						var pair = pairs.get_item(j);
						if (pair.hasOwnProperty('fieldName') && pair.hasOwnProperty('value') && !$tab__jQueryShim.isFunction(pair.fieldName) && !$tab__jQueryShim.isFunction(pair.value)) {
							this.$parseMarksParam(catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, pair.fieldName, pair.value);
						}
					}
				}
			}
			return this.$selectMarksWithValuesAsync(tupleIdList, catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, updateType);
		},
		$parseMarksParam: function WorksheetImpl$ParseMarksParam(catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, fieldName, value) {
			var sourceOptions = value;
			if ($tab__WorksheetImpl.$regexHierarchicalFieldName.test(fieldName)) {
				this.$addToParamLists(hierNameList, hierValueList, fieldName, value);
			}
			else if (ss.isValue(sourceOptions.min) || ss.isValue(sourceOptions.max)) {
				var range = new Object();
				if (ss.isValue(sourceOptions.min)) {
					if ($tab__Utility.isDate(sourceOptions.min)) {
						var dt = ss.cast(sourceOptions.min, ss.JsDate);
						if ($tab__Utility.isDateValid(dt)) {
							range.min = $tab__Utility.serializeDateForServer(dt);
						}
						else {
							throw $tab__TableauException.createInvalidDateParameter('options.min');
						}
					}
					else {
						range.min = sourceOptions.min;
					}
				}
				if (ss.isValue(sourceOptions.max)) {
					if ($tab__Utility.isDate(sourceOptions.max)) {
						var dt1 = ss.cast(sourceOptions.max, ss.JsDate);
						if ($tab__Utility.isDateValid(dt1)) {
							range.max = $tab__Utility.serializeDateForServer(dt1);
						}
						else {
							throw $tab__TableauException.createInvalidDateParameter('options.max');
						}
					}
					else {
						range.max = sourceOptions.max;
					}
				}
				if (ss.isValue(sourceOptions.nullOption)) {
					var nullOption = $tab_$PublicEnums.$normalizeEnum($tab_ApiNullOption).call(null, sourceOptions.nullOption, 'options.nullOption');
					range.nullOption = nullOption;
				}
				else {
					range.nullOption = 'allValues';
				}
				var jsonValue = JSON.stringify(range);
				this.$addToParamLists(rangeNameList, rangeValueList, fieldName, jsonValue);
			}
			else {
				this.$addToParamLists(catNameList, catValueList, fieldName, value);
			}
		},
		$addToParamLists: function WorksheetImpl$AddToParamLists(paramNameList, paramValueList, paramName, paramValue) {
			var markValues = [];
			if ($tab__jQueryShim.isArray(paramValue)) {
				var values = ss.cast(paramValue, Array);
				for (var i = 0; i < values.length; i++) {
					markValues.push(values[i].toString());
				}
			}
			else {
				markValues.push(paramValue.toString());
			}
			paramValueList.push(markValues);
			paramNameList.push(paramName);
		},
		$selectMarksWithValuesAsync: function WorksheetImpl$SelectMarksWithValuesAsync(tupleIdList, catNameList, catValueList, hierNameList, hierValueList, rangeNameList, rangeValueList, updateType) {
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			updateType = $tab_$PublicEnums.$normalizeEnum($tab_ApiSelectionUpdateType).call(null, updateType, 'updateType');
			commandParameters['api.filterUpdateType'] = updateType;
			if (!$tab__Utility.isNullOrEmpty(tupleIdList)) {
				commandParameters['api.tupleIds'] = JSON.stringify(tupleIdList);
			}
			if (!$tab__Utility.isNullOrEmpty(catNameList) && !$tab__Utility.isNullOrEmpty(catValueList)) {
				commandParameters['api.categoricalFieldCaption'] = JSON.stringify(catNameList);
				var markValues = [];
				for (var i = 0; i < catValueList.length; i++) {
					var values = JSON.stringify(catValueList[i]);
					markValues.push(values);
				}
				commandParameters['api.categoricalMarkValues'] = JSON.stringify(markValues);
			}
			if (!$tab__Utility.isNullOrEmpty(hierNameList) && !$tab__Utility.isNullOrEmpty(hierValueList)) {
				commandParameters['api.hierarchicalFieldCaption'] = JSON.stringify(hierNameList);
				var markValues1 = [];
				for (var i1 = 0; i1 < hierValueList.length; i1++) {
					var values1 = JSON.stringify(hierValueList[i1]);
					markValues1.push(values1);
				}
				commandParameters['api.hierarchicalMarkValues'] = JSON.stringify(markValues1);
			}
			if (!$tab__Utility.isNullOrEmpty(rangeNameList) && !$tab__Utility.isNullOrEmpty(rangeValueList)) {
				commandParameters['api.rangeFieldCaption'] = JSON.stringify(rangeNameList);
				var markValues2 = [];
				for (var i2 = 0; i2 < rangeValueList.length; i2++) {
					var values2 = JSON.stringify(rangeValueList[i2]);
					markValues2.push(values2);
				}
				commandParameters['api.rangeMarkValues'] = JSON.stringify(markValues2);
			}
			if ($tab__Utility.isNullOrEmpty(commandParameters['api.tupleIds']) && $tab__Utility.isNullOrEmpty(commandParameters['api.categoricalFieldCaption']) && $tab__Utility.isNullOrEmpty(commandParameters['api.hierarchicalFieldCaption']) && $tab__Utility.isNullOrEmpty(commandParameters['api.rangeFieldCaption'])) {
				throw $tab__TableauException.createInvalidParameter('fieldNameOrFieldValuesMap');
			}
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.SelectMarksCommand', 1, function(result) {
				var error = $tab__WorksheetImpl.$createSelectionCommandError(result);
				if (ss.isNullOrUndefined(error)) {
					deferred.resolve();
				}
				else {
					deferred.reject(error);
				}
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getSummaryDataAsync: function WorksheetImpl$GetSummaryDataAsync(options) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			options = options || new Object();
			commandParameters['api.ignoreAliases'] = ss.coalesce(options.ignoreAliases, false);
			commandParameters['api.ignoreSelection'] = ss.coalesce(options.ignoreSelection, false);
			commandParameters['api.maxRows'] = ss.coalesce(options.maxRows, 0);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetSummaryTableCommand', 0, function(result) {
				var dataResult = result;
				var dt = $tab__DataTableImpl.processGetDataPresModel(dataResult);
				deferred.resolve(dt);
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getUnderlyingDataAsync: function WorksheetImpl$GetUnderlyingDataAsync(options) {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			options = options || new Object();
			commandParameters['api.ignoreAliases'] = ss.coalesce(options.ignoreAliases, false);
			commandParameters['api.ignoreSelection'] = ss.coalesce(options.ignoreSelection, false);
			commandParameters['api.includeAllColumns'] = ss.coalesce(options.includeAllColumns, false);
			commandParameters['api.maxRows'] = ss.coalesce(options.maxRows, 0);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.GetUnderlyingTableCommand', 0, function(result) {
				var dataResult = result;
				var dt = $tab__DataTableImpl.processGetDataPresModel(dataResult);
				deferred.resolve(dt);
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$clearHighlightedMarksAsync: function WorksheetImpl$ClearHighlightedMarksAsync() {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.ClearHighlightedMarksCommand', 1, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$highlightMarksAsync: function WorksheetImpl$HighlightMarksAsync(fieldName, values) {
			$tab__Param.verifyString(fieldName, 'fieldName');
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.fieldCaption'] = fieldName;
			commandParameters['api.ObjectTextIDs'] = values;
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.HighlightMarksCommand', 0, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$highlightMarksByPatternMatchAsync: function WorksheetImpl$HighlightMarksByPatternMatchAsync(fieldName, patternMatch) {
			$tab__Param.verifyString(fieldName, 'fieldName');
			$tab__Param.verifyString(patternMatch, 'patternMatch');
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			commandParameters['api.filterUpdateType'] = 'replace';
			commandParameters['api.fieldCaption'] = fieldName;
			commandParameters['api.Pattern'] = patternMatch;
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.HighlightMarksByPatternMatch', 0, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		},
		$getHighlightedMarksAsync: function WorksheetImpl$GetHighlightedMarksAsync() {
			this.$verifyActiveSheetOrEmbeddedInActiveDashboard();
			var deferred = new tab._Deferred();
			var commandParameters = {};
			this.$addVisualIdToCommand(commandParameters);
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.FetchHighlightedMarksCommand', 0, ss.mkdel(this, function(result) {
				this.highlightedMarks = $tab_$MarkImpl.$processActiveMarks(result);
				deferred.resolve(this.highlightedMarks._toApiCollection());
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this.sendCommand(Object).call(this, commandParameters, returnHandler);
			return deferred.get_promise();
		}
	}, $tab__SheetImpl);
	ss.initEnum($tab_ApiDashboardObjectType, $asm, { blank: 'blank', worksheet: 'worksheet', quickFilter: 'quickFilter', parameterControl: 'parameterControl', pageFilter: 'pageFilter', legend: 'legend', title: 'title', text: 'text', image: 'image', webPage: 'webPage' }, true);
	ss.initEnum($tab_ApiDateRangeType, $asm, { last: 'last', lastn: 'lastn', next: 'next', nextn: 'nextn', curr: 'curr', todate: 'todate' }, true);
	ss.initEnum($tab_ApiDeviceType, $asm, { default: 'default', desktop: 'desktop', tablet: 'tablet', phone: 'phone' }, true);
	ss.initClass($tab_ApiEnumConverter, $asm, {});
	ss.initEnum($tab_ApiErrorCode, $asm, { internalError: 'internalError', serverError: 'serverError', invalidAggregationFieldName: 'invalidAggregationFieldName', invalidParameter: 'invalidParameter', invalidUrl: 'invalidUrl', staleDataReference: 'staleDataReference', vizAlreadyInManager: 'vizAlreadyInManager', noUrlOrParentElementNotFound: 'noUrlOrParentElementNotFound', invalidFilterFieldName: 'invalidFilterFieldName', invalidFilterFieldValue: 'invalidFilterFieldValue', invalidFilterFieldNameOrValue: 'invalidFilterFieldNameOrValue', filterCannotBePerformed: 'filterCannotBePerformed', notActiveSheet: 'notActiveSheet', invalidCustomViewName: 'invalidCustomViewName', missingRangeNForRelativeDateFilters: 'missingRangeNForRelativeDateFilters', missingMaxSize: 'missingMaxSize', missingMinSize: 'missingMinSize', missingMinMaxSize: 'missingMinMaxSize', invalidSize: 'invalidSize', invalidSizeBehaviorOnWorksheet: 'invalidSizeBehaviorOnWorksheet', sheetNotInWorkbook: 'sheetNotInWorkbook', indexOutOfRange: 'indexOutOfRange', downloadWorkbookNotAllowed: 'downloadWorkbookNotAllowed', nullOrEmptyParameter: 'nullOrEmptyParameter', browserNotCapable: 'browserNotCapable', unsupportedEventName: 'unsupportedEventName', invalidDateParameter: 'invalidDateParameter', invalidSelectionFieldName: 'invalidSelectionFieldName', invalidSelectionValue: 'invalidSelectionValue', invalidSelectionDate: 'invalidSelectionDate', noUrlForHiddenWorksheet: 'noUrlForHiddenWorksheet', maxVizResizeAttempts: 'maxVizResizeAttempts' }, true);
	ss.initEnum($tab_ApiFieldAggregationType, $asm, { SUM: 'SUM', AVG: 'AVG', MIN: 'MIN', MAX: 'MAX', STDEV: 'STDEV', STDEVP: 'STDEVP', VAR: 'VAR', VARP: 'VARP', COUNT: 'COUNT', COUNTD: 'COUNTD', MEDIAN: 'MEDIAN', ATTR: 'ATTR', NONE: 'NONE', PERCENTILE: 'PERCENTILE', YEAR: 'YEAR', QTR: 'QTR', MONTH: 'MONTH', DAY: 'DAY', HOUR: 'HOUR', MINUTE: 'MINUTE', SECOND: 'SECOND', WEEK: 'WEEK', WEEKDAY: 'WEEKDAY', MONTHYEAR: 'MONTHYEAR', MDY: 'MDY', END: 'END', TRUNC_YEAR: 'TRUNC_YEAR', TRUNC_QTR: 'TRUNC_QTR', TRUNC_MONTH: 'TRUNC_MONTH', TRUNC_WEEK: 'TRUNC_WEEK', TRUNC_DAY: 'TRUNC_DAY', TRUNC_HOUR: 'TRUNC_HOUR', TRUNC_MINUTE: 'TRUNC_MINUTE', TRUNC_SECOND: 'TRUNC_SECOND', QUART1: 'QUART1', QUART3: 'QUART3', SKEWNESS: 'SKEWNESS', KURTOSIS: 'KURTOSIS', INOUT: 'INOUT', SUM_XSQR: 'SUM_XSQR', USER: 'USER' }, true);
	ss.initEnum($tab_ApiFieldRoleType, $asm, { dimension: 'dimension', measure: 'measure', unknown: 'unknown' }, true);
	ss.initEnum($tab_ApiFilterType, $asm, { categorical: 'categorical', quantitative: 'quantitative', hierarchical: 'hierarchical', relativedate: 'relativedate' }, true);
	ss.initEnum($tab_ApiFilterUpdateType, $asm, { all: 'all', replace: 'replace', add: 'add', remove: 'remove' }, true);
	ss.initEnum($tab_ApiNullOption, $asm, { nullValues: 'nullValues', nonNullValues: 'nonNullValues', allValues: 'allValues' }, true);
	ss.initEnum($tab_ApiParameterAllowableValuesType, $asm, { all: 'all', list: 'list', range: 'range' }, true);
	ss.initEnum($tab_ApiParameterDataType, $asm, { float: 'float', integer: 'integer', string: 'string', boolean: 'boolean', date: 'date', datetime: 'datetime' }, true);
	ss.initEnum($tab_ApiPeriodType, $asm, { year: 'year', quarter: 'quarter', month: 'month', week: 'week', day: 'day', hour: 'hour', minute: 'minute', second: 'second' }, true);
	ss.initEnum($tab_ApiSelectionUpdateType, $asm, { replace: 'replace', add: 'add', remove: 'remove' }, true);
	ss.initEnum($tab_ApiSheetSizeBehavior, $asm, { automatic: 'automatic', exactly: 'exactly', range: 'range', atleast: 'atleast', atmost: 'atmost' }, true);
	ss.initEnum($tab_ApiSheetType, $asm, { worksheet: 'worksheet', dashboard: 'dashboard', story: 'story' }, true);
	ss.initEnum($tab_ApiTableauEventName, $asm, { customviewload: 'customviewload', customviewremove: 'customviewremove', customviewsave: 'customviewsave', customviewsetdefault: 'customviewsetdefault', filterchange: 'filterchange', firstinteractive: 'firstinteractive', firstvizsizeknown: 'firstvizsizeknown', marksselection: 'marksselection', markshighlight: 'markshighlight', parametervaluechange: 'parametervaluechange', storypointswitch: 'storypointswitch', tabswitch: 'tabswitch', vizresize: 'vizresize' }, true);
	ss.initEnum($tab_ApiToolbarPosition, $asm, { top: 'top', bottom: 'bottom' }, true);
	ss.initClass($tab_CrossDomainMessagingOptions, $asm, {
		get_router: function CrossDomainMessagingOptions$get_Router() {
			return this.$router;
		},
		get_handler: function CrossDomainMessagingOptions$get_Handler() {
			return this.$handler;
		},
		sendCommand: function(T) {
			return function CrossDomainMessagingOptions$SendCommand(commandParameters, returnHandler) {
				this.$router.sendCommand(T).call(this.$router, this.$handler, commandParameters, returnHandler);
			};
		}
	});
	ss.initClass($tab_TableauEvent, $asm, {
		getViz: function TableauEvent$GetViz() {
			return this.$viz;
		},
		getEventName: function TableauEvent$GetEventName() {
			return this.$eventName;
		}
	});
	ss.initClass($tab_CustomViewEvent, $asm, {
		getCustomViewAsync: function CustomViewEvent$GetCustomViewAsync() {
			var deferred = new tab._Deferred();
			var customView = null;
			if (ss.isValue(this.$context.get__customViewImpl())) {
				customView = this.$context.get__customViewImpl().get_$customView();
			}
			deferred.resolve(customView);
			return deferred.get_promise();
		}
	}, $tab_TableauEvent);
	ss.initEnum($tab_DataType, $asm, { float: 'float', integer: 'integer', string: 'string', boolean: 'boolean', date: 'date', datetime: 'datetime' }, true);
	ss.initClass($tab_DataValue, $asm, {}, Object);
	ss.initClass($tab_WorksheetEvent, $asm, {
		getWorksheet: function WorksheetEvent$GetWorksheet() {
			return this.$worksheetImpl.get_worksheet();
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_FilterEvent, $asm, {
		getFieldName: function FilterEvent$GetFieldName() {
			return this.$filterCaption;
		},
		getFilterAsync: function FilterEvent$GetFilterAsync() {
			return this.$context.get__worksheetImpl().$getFilterAsync(this.$context.get__filterFieldName(), null, null);
		}
	}, $tab_WorksheetEvent);
	ss.initClass($tab_FirstVizSizeKnownEvent, $asm, {
		getVizSize: function FirstVizSizeKnownEvent$GetVizSize() {
			return this.$vizSize;
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_HighlightEvent, $asm, {
		getHighlightedMarksAsync: function HighlightEvent$GetHighlightedMarksAsync() {
			var worksheetImpl = this.$context.get__worksheetImpl();
			return worksheetImpl.$getHighlightedMarksAsync();
		}
	}, $tab_WorksheetEvent);
	ss.initClass($tab_MarksEvent, $asm, {
		getMarksAsync: function MarksEvent$GetMarksAsync() {
			var worksheetImpl = this.$context.get__worksheetImpl();
			if (ss.isValue(worksheetImpl.get_selectedMarks())) {
				var deferred = new tab._Deferred();
				return deferred.resolve(worksheetImpl.get_selectedMarks()._toApiCollection());
			}
			return worksheetImpl.$getSelectedMarksAsync();
		}
	}, $tab_WorksheetEvent);
	ss.initClass($tab_ParameterEvent, $asm, {
		getParameterName: function ParameterEvent$GetParameterName() {
			return this.$context.get__parameterName();
		},
		getParameterAsync: function ParameterEvent$GetParameterAsync() {
			return this.$context.get__workbookImpl().$getSingleParameterAsync(this.$context.get__parameterName());
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_Point, $asm, {}, Object);
	ss.initClass($tab_SheetSize, $asm, {}, Object);
	ss.initClass($tab_SheetSizeFactory, $asm, {});
	ss.initClass($tab_Size, $asm, {}, Object);
	ss.initClass($tab_StoryPointInfoImplUtil, $asm, {});
	ss.initClass($tab_StoryPointSwitchEvent, $asm, {
		getOldStoryPointInfo: function StoryPointSwitchEvent$GetOldStoryPointInfo() {
			return this.$oldStoryPointInfo;
		},
		getNewStoryPoint: function StoryPointSwitchEvent$GetNewStoryPoint() {
			return this.$newStoryPoint;
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_TabSwitchEvent, $asm, {
		getOldSheetName: function TabSwitchEvent$GetOldSheetName() {
			return this.$oldName;
		},
		getNewSheetName: function TabSwitchEvent$GetNewSheetName() {
			return this.$newName;
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_VizImpl, $asm, {
		add_customViewsListLoad: function VizImpl$add_CustomViewsListLoad(value) {
			this.$1$CustomViewsListLoadField = ss.delegateCombine(this.$1$CustomViewsListLoadField, value);
		},
		remove_customViewsListLoad: function VizImpl$remove_CustomViewsListLoad(value) {
			this.$1$CustomViewsListLoadField = ss.delegateRemove(this.$1$CustomViewsListLoadField, value);
		},
		add_stateReadyForQuery: function VizImpl$add_StateReadyForQuery(value) {
			this.$1$StateReadyForQueryField = ss.delegateCombine(this.$1$StateReadyForQueryField, value);
		},
		remove_stateReadyForQuery: function VizImpl$remove_StateReadyForQuery(value) {
			this.$1$StateReadyForQueryField = ss.delegateRemove(this.$1$StateReadyForQueryField, value);
		},
		add_$marksSelection: function VizImpl$add_MarksSelection(value) {
			this.$1$MarksSelectionField = ss.delegateCombine(this.$1$MarksSelectionField, value);
		},
		remove_$marksSelection: function VizImpl$remove_MarksSelection(value) {
			this.$1$MarksSelectionField = ss.delegateRemove(this.$1$MarksSelectionField, value);
		},
		add_$marksHighlight: function VizImpl$add_MarksHighlight(value) {
			this.$1$MarksHighlightField = ss.delegateCombine(this.$1$MarksHighlightField, value);
		},
		remove_$marksHighlight: function VizImpl$remove_MarksHighlight(value) {
			this.$1$MarksHighlightField = ss.delegateRemove(this.$1$MarksHighlightField, value);
		},
		add_$filterChange: function VizImpl$add_FilterChange(value) {
			this.$1$FilterChangeField = ss.delegateCombine(this.$1$FilterChangeField, value);
		},
		remove_$filterChange: function VizImpl$remove_FilterChange(value) {
			this.$1$FilterChangeField = ss.delegateRemove(this.$1$FilterChangeField, value);
		},
		add_$parameterValueChange: function VizImpl$add_ParameterValueChange(value) {
			this.$1$ParameterValueChangeField = ss.delegateCombine(this.$1$ParameterValueChangeField, value);
		},
		remove_$parameterValueChange: function VizImpl$remove_ParameterValueChange(value) {
			this.$1$ParameterValueChangeField = ss.delegateRemove(this.$1$ParameterValueChangeField, value);
		},
		add_$customViewLoad: function VizImpl$add_CustomViewLoad(value) {
			this.$1$CustomViewLoadField = ss.delegateCombine(this.$1$CustomViewLoadField, value);
		},
		remove_$customViewLoad: function VizImpl$remove_CustomViewLoad(value) {
			this.$1$CustomViewLoadField = ss.delegateRemove(this.$1$CustomViewLoadField, value);
		},
		add_$customViewSave: function VizImpl$add_CustomViewSave(value) {
			this.$1$CustomViewSaveField = ss.delegateCombine(this.$1$CustomViewSaveField, value);
		},
		remove_$customViewSave: function VizImpl$remove_CustomViewSave(value) {
			this.$1$CustomViewSaveField = ss.delegateRemove(this.$1$CustomViewSaveField, value);
		},
		add_$customViewRemove: function VizImpl$add_CustomViewRemove(value) {
			this.$1$CustomViewRemoveField = ss.delegateCombine(this.$1$CustomViewRemoveField, value);
		},
		remove_$customViewRemove: function VizImpl$remove_CustomViewRemove(value) {
			this.$1$CustomViewRemoveField = ss.delegateRemove(this.$1$CustomViewRemoveField, value);
		},
		add_$customViewSetDefault: function VizImpl$add_CustomViewSetDefault(value) {
			this.$1$CustomViewSetDefaultField = ss.delegateCombine(this.$1$CustomViewSetDefaultField, value);
		},
		remove_$customViewSetDefault: function VizImpl$remove_CustomViewSetDefault(value) {
			this.$1$CustomViewSetDefaultField = ss.delegateRemove(this.$1$CustomViewSetDefaultField, value);
		},
		add_$tabSwitch: function VizImpl$add_TabSwitch(value) {
			this.$1$TabSwitchField = ss.delegateCombine(this.$1$TabSwitchField, value);
		},
		remove_$tabSwitch: function VizImpl$remove_TabSwitch(value) {
			this.$1$TabSwitchField = ss.delegateRemove(this.$1$TabSwitchField, value);
		},
		add_$storyPointSwitch: function VizImpl$add_StoryPointSwitch(value) {
			this.$1$StoryPointSwitchField = ss.delegateCombine(this.$1$StoryPointSwitchField, value);
		},
		remove_$storyPointSwitch: function VizImpl$remove_StoryPointSwitch(value) {
			this.$1$StoryPointSwitchField = ss.delegateRemove(this.$1$StoryPointSwitchField, value);
		},
		add_$vizResize: function VizImpl$add_VizResize(value) {
			this.$1$VizResizeField = ss.delegateCombine(this.$1$VizResizeField, value);
		},
		remove_$vizResize: function VizImpl$remove_VizResize(value) {
			this.$1$VizResizeField = ss.delegateRemove(this.$1$VizResizeField, value);
		},
		get_hostId: function VizImpl$get_HostId() {
			return this.$parameters.hostId;
		},
		set_hostId: function VizImpl$set_HostId(value) {
			this.$parameters.hostId = value;
		},
		get_iframe: function VizImpl$get_Iframe() {
			return this.$iframe;
		},
		get_instanceId: function VizImpl$get_InstanceId() {
			return this.$instanceId;
		},
		set_instanceId: function VizImpl$set_InstanceId(value) {
			this.$instanceId = value;
		},
		get_$viz: function VizImpl$get_Viz() {
			return this.$viz;
		},
		get_$areTabsHidden: function VizImpl$get_AreTabsHidden() {
			return this.$areTabsHidden;
		},
		get_$isToolbarHidden: function VizImpl$get_IsToolbarHidden() {
			return this.$isToolbarHidden;
		},
		get_$isHidden: function VizImpl$get_IsHidden() {
			return this.$iframe.style.display === 'none';
		},
		get_$parentElement: function VizImpl$get_ParentElement() {
			return this.$parameters.parentElement;
		},
		get_$url: function VizImpl$get_Url() {
			return this.$parameters.get_baseUrl();
		},
		get_$workbook: function VizImpl$get_Workbook() {
			return this.$workbookImpl.get_workbook();
		},
		get__workbookImpl: function VizImpl$get_WorkbookImpl() {
			return this.$workbookImpl;
		},
		get_$areAutomaticUpdatesPaused: function VizImpl$get_AreAutomaticUpdatesPaused() {
			return this.$areAutomaticUpdatesPaused;
		},
		get_$vizSize: function VizImpl$get_VizSize() {
			return this.$vizSize;
		},
		getCurrentUrlAsync: function VizImpl$GetCurrentUrlAsync() {
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [String]))('api.GetCurrentUrlCommand', 0, function(result) {
				deferred.resolve(result);
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createInternalError(message));
			});
			this._sendCommand(String).call(this, null, returnHandler);
			return deferred.get_promise();
		},
		handleVizListening: function VizImpl$HandleVizListening() {
			this.$enableVisibleRectCommunication();
		},
		handleVizLoad: function VizImpl$HandleVizLoad() {
			if (ss.isNullOrUndefined(this.$vizSize)) {
				this.$setFrameSize(this.$initialAvailableSize.width + 'px', this.$initialAvailableSize.height + 'px');
				this.$show();
			}
			if (ss.isValue(this.$staticImage)) {
				this.$staticImage.style.display = 'none';
			}
			if (ss.isNullOrUndefined(this.$workbookImpl)) {
				this.$workbookImpl = new $tab__WorkbookImpl(this, this.$messagingOptions, ss.mkdel(this, function() {
					this.$onWorkbookInteractive(null);
				}));
			}
			else if (!this.$initializingWorkbookImpl) {
				this.$workbookImpl._update(ss.mkdel(this, function() {
					this.$onWorkbookInteractive(null);
				}));
			}
		},
		$calculateFrameSize: function VizImpl$CalculateFrameSize(availableSize) {
			var chromeHeight = this.$vizSize.chromeHeight;
			var sheetSize = this.$vizSize.sheetSize;
			var width = 0;
			var height = 0;
			if (sheetSize.behavior === 'exactly') {
				width = sheetSize.maxSize.width;
				height = sheetSize.maxSize.height + chromeHeight;
			}
			else {
				var minWidth;
				var maxWidth;
				var minHeight;
				var maxHeight;
				switch (sheetSize.behavior) {
					case 'range': {
						minWidth = sheetSize.minSize.width;
						maxWidth = sheetSize.maxSize.width;
						minHeight = sheetSize.minSize.height + chromeHeight;
						maxHeight = sheetSize.maxSize.height + chromeHeight;
						width = Math.max(minWidth, Math.min(maxWidth, availableSize.width));
						height = Math.max(minHeight, Math.min(maxHeight, availableSize.height));
						break;
					}
					case 'atleast': {
						minWidth = sheetSize.minSize.width;
						minHeight = sheetSize.minSize.height + chromeHeight;
						width = Math.max(minWidth, availableSize.width);
						height = Math.max(minHeight, availableSize.height);
						break;
					}
					case 'atmost': {
						maxWidth = sheetSize.maxSize.width;
						maxHeight = sheetSize.maxSize.height + chromeHeight;
						width = Math.min(maxWidth, availableSize.width);
						height = Math.min(maxHeight, availableSize.height);
						break;
					}
					case 'automatic': {
						width = availableSize.width;
						height = Math.max(availableSize.height, chromeHeight);
						break;
					}
					default: {
						throw $tab__TableauException.createInternalError('Unknown SheetSizeBehavior for viz: ' + sheetSize.behavior.toString());
					}
				}
			}
			return $tab_Size.$ctor(width, height);
		},
		$getNewFrameSize: function VizImpl$GetNewFrameSize() {
			var availableSize;
			if (ss.isValue(this.$initialAvailableSize)) {
				availableSize = this.$initialAvailableSize;
				this.$initialAvailableSize = null;
			}
			else {
				availableSize = $tab__Utility.computeContentSize(this.get_$parentElement());
			}
			this.$raiseVizResizeEvent(availableSize);
			return this.$calculateFrameSize(availableSize);
		},
		$refreshSize: function VizImpl$RefreshSize() {
			if (!ss.isValue(this.$vizSize)) {
				return;
			}
			var frameSize = this.$getNewFrameSize();
			if (frameSize.height === this.$vizSize.chromeHeight) {
				return;
			}
			this.$setFrameSize(frameSize.width + 'px', frameSize.height + 'px');
			var resizeAttempts = 10;
			for (var i = 0; i < resizeAttempts; i++) {
				var newFrameSize = this.$getNewFrameSize();
				if (ss.referenceEquals(JSON.stringify(frameSize), JSON.stringify(newFrameSize))) {
					return;
				}
				frameSize = newFrameSize;
				this.$setFrameSize(frameSize.width + 'px', frameSize.height + 'px');
			}
			throw $tab__TableauException.create('maxVizResizeAttempts', 'Viz resize limit hit. The calculated iframe size did not stabilize after ' + resizeAttempts + ' resizes.');
		},
		handleEventNotification: function VizImpl$HandleEventNotification(eventName, eventParameters) {
			var notification = $tab__ApiServerNotification.deserialize(eventParameters);
			switch (eventName) {
				case 'api.FirstVizSizeKnownEvent': {
					this.$handleFirstVizSizeKnownEvent(notification);
					break;
				}
				case 'api.VizInteractiveEvent': {
					this.$handleVizInteractiveEvent(notification);
					break;
				}
				case 'api.MarksSelectionChangedEvent': {
					this.$handleMarksSelectionChangedEvent(notification);
					break;
				}
				case 'api.MarksHighlightChangedEvent': {
					this.$handleMarksHighlightChangedEvent(notification);
					break;
				}
				case 'api.FilterChangedEvent': {
					this.$handleFilterChangedEvent(notification);
					break;
				}
				case 'api.ParameterChangedEvent': {
					this.$handleParameterChangedEvent(notification);
					break;
				}
				case 'api.CustomViewsListLoadedEvent': {
					this.$handleCustomViewsListLoadedEvent(notification);
					break;
				}
				case 'api.CustomViewUpdatedEvent': {
					this.$handleCustomViewUpdatedEvent(notification);
					break;
				}
				case 'api.CustomViewRemovedEvent': {
					this.$handleCustomViewRemovedEvent();
					break;
				}
				case 'api.CustomViewSetDefaultEvent': {
					this.$handleCustomViewSetDefaultEvent(notification);
					break;
				}
				case 'api.TabSwitchEvent': {
					this.$handleTabSwitchEvent(notification);
					break;
				}
				case 'api.StorytellingStateChangedEvent': {
					this.$handleStorytellingStateChangedEvent(notification);
					break;
				}
			}
		},
		addEventListener: function VizImpl$AddEventListener(eventName, handler) {
			var normalizedEventName = {};
			if (!$tab_$PublicEnums.$tryNormalizeEnum($tab_ApiTableauEventName).call(null, eventName, normalizedEventName)) {
				throw $tab__TableauException.createUnsupportedEventName(eventName.toString());
			}
			switch (normalizedEventName.$) {
				case 'marksselection': {
					this.add_$marksSelection(ss.cast(handler, Function));
					break;
				}
				case 'markshighlight': {
					this.add_$marksHighlight(ss.cast(handler, Function));
					break;
				}
				case 'parametervaluechange': {
					this.add_$parameterValueChange(ss.cast(handler, Function));
					break;
				}
				case 'filterchange': {
					this.add_$filterChange(ss.cast(handler, Function));
					break;
				}
				case 'customviewload': {
					this.add_$customViewLoad(ss.cast(handler, Function));
					break;
				}
				case 'customviewsave': {
					this.add_$customViewSave(ss.cast(handler, Function));
					break;
				}
				case 'customviewremove': {
					this.add_$customViewRemove(ss.cast(handler, Function));
					break;
				}
				case 'customviewsetdefault': {
					this.add_$customViewSetDefault(ss.cast(handler, Function));
					break;
				}
				case 'tabswitch': {
					this.add_$tabSwitch(ss.cast(handler, Function));
					break;
				}
				case 'storypointswitch': {
					this.add_$storyPointSwitch(ss.cast(handler, Function));
					break;
				}
				case 'vizresize': {
					this.add_$vizResize(ss.cast(handler, Function));
					break;
				}
			}
		},
		removeEventListener: function VizImpl$RemoveEventListener(eventName, handler) {
			var normalizedEventName = {};
			if (!$tab_$PublicEnums.$tryNormalizeEnum($tab_ApiTableauEventName).call(null, eventName, normalizedEventName)) {
				throw $tab__TableauException.createUnsupportedEventName(eventName.toString());
			}
			switch (normalizedEventName.$) {
				case 'marksselection': {
					this.remove_$marksSelection(ss.cast(handler, Function));
					break;
				}
				case 'markshighlight': {
					this.remove_$marksHighlight(ss.cast(handler, Function));
					break;
				}
				case 'parametervaluechange': {
					this.remove_$parameterValueChange(ss.cast(handler, Function));
					break;
				}
				case 'filterchange': {
					this.remove_$filterChange(ss.cast(handler, Function));
					break;
				}
				case 'customviewload': {
					this.remove_$customViewLoad(ss.cast(handler, Function));
					break;
				}
				case 'customviewsave': {
					this.remove_$customViewSave(ss.cast(handler, Function));
					break;
				}
				case 'customviewremove': {
					this.remove_$customViewRemove(ss.cast(handler, Function));
					break;
				}
				case 'customviewsetdefault': {
					this.remove_$customViewSetDefault(ss.cast(handler, Function));
					break;
				}
				case 'tabswitch': {
					this.remove_$tabSwitch(ss.cast(handler, Function));
					break;
				}
				case 'storypointswitch': {
					this.remove_$storyPointSwitch(ss.cast(handler, Function));
					break;
				}
				case 'vizresize': {
					this.remove_$vizResize(ss.cast(handler, Function));
					break;
				}
			}
		},
		$dispose: function VizImpl$Dispose() {
			if (ss.isValue(this.$iframe)) {
				this.$iframe.parentNode.removeChild(this.$iframe);
				this.$iframe = null;
			}
			$tab__VizManagerImpl.$unregisterViz(this.$viz);
			this.$messagingOptions.get_router().unregisterHandler(this);
			this.$removeWindowResizeHandler();
		},
		$show: function VizImpl$Show() {
			this.$iframe.style.display = 'block';
			this.$iframe.style.visibility = 'visible';
		},
		$hide: function VizImpl$Hide() {
			this.$iframe.style.display = 'none';
		},
		$makeInvisible: function VizImpl$MakeInvisible() {
			this.$iframe.style.visibility = 'hidden';
		},
		$showExportImageDialog: function VizImpl$ShowExportImageDialog() {
			this.$invokeCommand('showExportImageDialog');
		},
		$showExportDataDialog: function VizImpl$ShowExportDataDialog(sheetOrInfoOrName) {
			var sheetName = this.$verifyOperationAllowedOnActiveSheetOrSheetWithinActiveDashboard(sheetOrInfoOrName);
			this.$invokeCommand('showExportDataDialog', sheetName);
		},
		$showExportCrossTabDialog: function VizImpl$ShowExportCrossTabDialog(sheetOrInfoOrName) {
			var sheetName = this.$verifyOperationAllowedOnActiveSheetOrSheetWithinActiveDashboard(sheetOrInfoOrName);
			this.$invokeCommand('showExportCrosstabDialog', sheetName);
		},
		$showExportPDFDialog: function VizImpl$ShowExportPDFDialog() {
			this.$invokeCommand('showExportPDFDialog');
		},
		$revertAllAsync: function VizImpl$RevertAllAsync() {
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.RevertAllCommand', 1, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this._sendCommand(Object).call(this, null, returnHandler);
			return deferred.get_promise();
		},
		$refreshDataAsync: function VizImpl$RefreshDataAsync() {
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.RefreshDataCommand', 1, function(result) {
				deferred.resolve();
			}, function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this._sendCommand(Object).call(this, null, returnHandler);
			return deferred.get_promise();
		},
		$showShareDialog: function VizImpl$ShowShareDialog() {
			this.$invokeCommand('showShareDialog');
		},
		$showDownloadWorkbookDialog: function VizImpl$ShowDownloadWorkbookDialog() {
			if (this.get__workbookImpl().get_isDownloadAllowed()) {
				this.$invokeCommand('showDownloadWorkbookDialog');
			}
			else {
				throw $tab__TableauException.create('downloadWorkbookNotAllowed', 'Download workbook is not allowed');
			}
		},
		$pauseAutomaticUpdatesAsync: function VizImpl$PauseAutomaticUpdatesAsync() {
			return this.$invokeAutomaticUpdatesCommandAsync('pauseAutomaticUpdates');
		},
		$resumeAutomaticUpdatesAsync: function VizImpl$ResumeAutomaticUpdatesAsync() {
			return this.$invokeAutomaticUpdatesCommandAsync('resumeAutomaticUpdates');
		},
		$toggleAutomaticUpdatesAsync: function VizImpl$ToggleAutomaticUpdatesAsync() {
			return this.$invokeAutomaticUpdatesCommandAsync('toggleAutomaticUpdates');
		},
		$setFrameSizeAndUpdate: function VizImpl$SetFrameSizeAndUpdate(width, height) {
			this.$raiseVizResizeEvent($tab_Size.$ctor(-1, -1));
			this.$setFrameSize(width, height);
			this.$workbookImpl._updateActiveSheetAsync();
		},
		$setAreAutomaticUpdatesPaused: function VizImpl$SetAreAutomaticUpdatesPaused(value) {
			this.$areAutomaticUpdatesPaused = value;
		},
		$contentRootElement: function VizImpl$ContentRootElement() {
			return this.$parameters.parentElement;
		},
		$create: function VizImpl$Create() {
			try {
				$tab__VizManagerImpl.$registerViz(this.$viz);
			}
			catch ($t1) {
				var e = ss.Exception.wrap($t1);
				this.$dispose();
				throw e;
			}
			if (!this.$parameters.fixedSize) {
				this.$initialAvailableSize = $tab__Utility.computeContentSize(this.get_$parentElement());
				if (this.$initialAvailableSize.width === 0 || this.$initialAvailableSize.height === 0) {
					this.$initialAvailableSize = $tab_Size.$ctor(800, 600);
				}
				this.$iframe = this.$createIframe();
				this.$makeInvisible();
				if (this.$parameters.displayStaticImage) {
					this.$staticImage = this.$createStaticImageElement(this.$initialAvailableSize);
					this.$staticImage.style.display = 'block';
				}
			}
			else {
				if (this.$parameters.displayStaticImage) {
					this.$staticImage = this.$createStaticImageElement($tab_Size.$ctor(parseInt(this.$parameters.width), parseInt(this.$parameters.height)));
					this.$staticImage.style.display = 'block';
				}
				this.$iframe = this.$createIframe();
				this.$show();
			}
			if (!$tab__Utility.hasWindowPostMessage()) {
				if ($tab__Utility.isIE()) {
					this.$iframe['onreadystatechange'] = this.$getOnCheckForDoneDelegate();
				}
				else {
					this.$iframe.onload = this.$getOnCheckForDoneDelegate();
				}
			}
			this.$isToolbarHidden = !this.$parameters.toolbar;
			this.$areTabsHidden = !this.$parameters.tabs;
			this.$messagingOptions.get_router().registerHandler(this);
			this.$iframe.src = this.$parameters.get_url();
		},
		$sendVisibleRect: function VizImpl$SendVisibleRect() {
			try {
				if (!$tab__Utility.hasWindowPostMessage() || ss.isNullOrUndefined(this.$iframe) || !ss.isValue(this.$iframe.contentWindow)) {
					return;
				}
			}
			catch ($t1) {
				return;
			}
			var visibleRect = $tab__Utility.visibleContentRectInDocumentCoordinates(this.get_iframe());
			var iframeContentRect = $tab__Utility.contentRectInDocumentCoordinates(this.get_iframe());
			var param = [];
			param.push('layoutInfoResp'.toString());
			param.push(visibleRect.left - iframeContentRect.left);
			param.push(visibleRect.top - iframeContentRect.top);
			param.push(visibleRect.width);
			param.push(visibleRect.height);
			this.$iframe.contentWindow.postMessage(param.join(','), '*');
		},
		$enableVisibleRectCommunication: function VizImpl$EnableVisibleRectCommunication() {
			if (!$tab__Utility.hasWindowPostMessage() || ss.isNullOrUndefined(this.$iframe) || !ss.isValue(this.$iframe.contentWindow)) {
				return;
			}
			this.$iframe.contentWindow.postMessage('tableau.enableVisibleRectCommunication'.toString(), '*');
		},
		_sendCommand: function(T) {
			return function VizImpl$SendCommand(commandParameters, returnHandler) {
				this.$messagingOptions.sendCommand(T).call(this.$messagingOptions, commandParameters, returnHandler);
			};
		},
		$raiseParameterValueChange: function VizImpl$RaiseParameterValueChange(parameterName) {
			if (!ss.staticEquals(this.$1$ParameterValueChangeField, null)) {
				this.$1$ParameterValueChangeField(new $tab_ParameterEvent('parametervaluechange', this.$viz, parameterName));
			}
		},
		$raiseCustomViewLoad: function VizImpl$RaiseCustomViewLoad(customView) {
			this.get__workbookImpl()._update(ss.mkdel(this, function() {
				if (!ss.staticEquals(this.$1$CustomViewLoadField, null)) {
					this.$1$CustomViewLoadField(new $tab_CustomViewEvent('customviewload', this.$viz, (ss.isValue(customView) ? customView._impl : null)));
				}
			}));
		},
		$raiseCustomViewSave: function VizImpl$RaiseCustomViewSave(customView) {
			this.get__workbookImpl()._update(ss.mkdel(this, function() {
				if (!ss.staticEquals(this.$1$CustomViewSaveField, null)) {
					this.$1$CustomViewSaveField(new $tab_CustomViewEvent('customviewsave', this.$viz, customView._impl));
				}
			}));
		},
		$raiseCustomViewRemove: function VizImpl$RaiseCustomViewRemove(customView) {
			if (!ss.staticEquals(this.$1$CustomViewRemoveField, null)) {
				this.$1$CustomViewRemoveField(new $tab_CustomViewEvent('customviewremove', this.$viz, customView._impl));
			}
		},
		$raiseCustomViewSetDefault: function VizImpl$RaiseCustomViewSetDefault(customView) {
			if (!ss.staticEquals(this.$1$CustomViewSetDefaultField, null)) {
				this.$1$CustomViewSetDefaultField(new $tab_CustomViewEvent('customviewsetdefault', this.$viz, customView._impl));
			}
		},
		$raiseTabSwitch: function VizImpl$RaiseTabSwitch(oldSheetName, newSheetName) {
			if (!ss.staticEquals(this.$1$TabSwitchField, null)) {
				this.$1$TabSwitchField(new $tab_TabSwitchEvent('tabswitch', this.$viz, oldSheetName, newSheetName));
			}
		},
		raiseStoryPointSwitch: function VizImpl$RaiseStoryPointSwitch(oldStoryPointInfo, newStoryPoint) {
			if (!ss.staticEquals(this.$1$StoryPointSwitchField, null)) {
				this.$1$StoryPointSwitchField(new $tab_StoryPointSwitchEvent('storypointswitch', this.$viz, oldStoryPointInfo, newStoryPoint));
			}
		},
		$raiseStateReadyForQuery: function VizImpl$RaiseStateReadyForQuery() {
			if (!ss.staticEquals(this.$1$StateReadyForQueryField, null)) {
				this.$1$StateReadyForQueryField(this);
			}
		},
		$raiseCustomViewsListLoad: function VizImpl$RaiseCustomViewsListLoad() {
			if (!ss.staticEquals(this.$1$CustomViewsListLoadField, null)) {
				this.$1$CustomViewsListLoadField(this);
			}
		},
		$raiseVizResizeEvent: function VizImpl$RaiseVizResizeEvent(availableSize) {
			if (!ss.staticEquals(this.$1$VizResizeField, null)) {
				this.$1$VizResizeField(new $tab_VizResizeEvent('vizresize', this.$viz, availableSize));
			}
		},
		$setFrameSize: function VizImpl$SetFrameSize(width, height) {
			this.$parameters.width = width;
			this.$parameters.height = height;
			this.$iframe.style.width = this.$parameters.width;
			this.$iframe.style.height = this.$parameters.height;
		},
		$verifyOperationAllowedOnActiveSheetOrSheetWithinActiveDashboard: function VizImpl$VerifyOperationAllowedOnActiveSheetOrSheetWithinActiveDashboard(sheetOrInfoOrName) {
			if (ss.isNullOrUndefined(sheetOrInfoOrName)) {
				return null;
			}
			var sheetImpl = this.$workbookImpl.$findActiveSheetOrSheetWithinActiveDashboard(sheetOrInfoOrName);
			if (ss.isNullOrUndefined(sheetImpl)) {
				throw $tab__TableauException.createNotActiveSheet();
			}
			return sheetImpl.get_name();
		},
		$invokeAutomaticUpdatesCommandAsync: function VizImpl$InvokeAutomaticUpdatesCommandAsync(command) {
			if (command !== 'pauseAutomaticUpdates' && command !== 'resumeAutomaticUpdates' && command !== 'toggleAutomaticUpdates') {
				throw $tab__TableauException.createInternalError(null);
			}
			var param = {};
			param['api.invokeCommandName'] = command;
			var deferred = new tab._Deferred();
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.InvokeCommandCommand', 0, ss.mkdel(this, function(result) {
				if (ss.isValue(result) && ss.isValue(result.isAutoUpdate)) {
					this.$areAutomaticUpdatesPaused = !result.isAutoUpdate;
				}
				deferred.resolve(this.$areAutomaticUpdatesPaused);
			}), function(remoteError, message) {
				deferred.reject($tab__TableauException.createServerError(message));
			});
			this._sendCommand(Object).call(this, param, returnHandler);
			return deferred.get_promise();
		},
		$invokeCommand: function VizImpl$InvokeCommand(command, sheetName) {
			if (command !== 'showExportImageDialog' && command !== 'showExportDataDialog' && command !== 'showExportCrosstabDialog' && command !== 'showExportPDFDialog' && command !== 'showShareDialog' && command !== 'showDownloadWorkbookDialog') {
				throw $tab__TableauException.createInternalError(null);
			}
			var param = {};
			param['api.invokeCommandName'] = command;
			if (ss.isValue(sheetName)) {
				param['api.invokeCommandParam'] = sheetName;
			}
			var returnHandler = new (ss.makeGenericType($tab_CommandReturnHandler$1, [Object]))('api.InvokeCommandCommand', 0, null, null);
			this._sendCommand(Object).call(this, param, returnHandler);
		},
		$handleFirstVizSizeKnownEvent: function VizImpl$HandleFirstVizSizeKnownEvent(notification) {
			var size = JSON.parse(ss.cast(notification.get_data(), String));
			this.$handleInitialVizSize(size);
		},
		$handleVizInteractiveEvent: function VizImpl$HandleVizInteractiveEvent(notification) {
			if (ss.isValue(this.$workbookImpl) && ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
				this.$onWorkbookInteractive(null);
			}
			else {
				this.$raiseStateReadyForQuery();
			}
		},
		$handleMarksSelectionChangedEvent: function VizImpl$HandleMarksSelectionChangedEvent(notification) {
			if (ss.staticEquals(this.$1$MarksSelectionField, null) || !ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
				return;
			}
			var worksheetImpl = null;
			var activeSheetImpl = this.$workbookImpl.get_activeSheetImpl();
			if (activeSheetImpl.get_isStory()) {
				activeSheetImpl = ss.cast(activeSheetImpl, $tab__StoryImpl).get_activeStoryPointImpl().get_containedSheetImpl();
			}
			if (ss.referenceEquals(activeSheetImpl.get_name(), notification.get_worksheetName())) {
				worksheetImpl = ss.cast(activeSheetImpl, $tab__WorksheetImpl);
			}
			else if (activeSheetImpl.get_isDashboard()) {
				var dashboardImpl = ss.cast(activeSheetImpl, $tab__DashboardImpl);
				worksheetImpl = dashboardImpl.get_worksheets()._get(notification.get_worksheetName())._impl;
			}
			if (ss.isValue(worksheetImpl)) {
				worksheetImpl.set_selectedMarks(null);
				this.$1$MarksSelectionField(new $tab_MarksEvent('marksselection', this.$viz, worksheetImpl));
			}
		},
		$handleMarksHighlightChangedEvent: function VizImpl$HandleMarksHighlightChangedEvent(notification) {
			if (ss.staticEquals(this.$1$MarksHighlightField, null) || !ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
				return;
			}
			var worksheetImpl = null;
			var activeSheetImpl = this.$workbookImpl.get_activeSheetImpl();
			if (activeSheetImpl.get_isStory()) {
				activeSheetImpl = ss.cast(activeSheetImpl, $tab__StoryImpl).get_activeStoryPointImpl().get_containedSheetImpl();
			}
			if (ss.referenceEquals(activeSheetImpl.get_name(), notification.get_worksheetName())) {
				worksheetImpl = ss.cast(activeSheetImpl, $tab__WorksheetImpl);
			}
			else if (activeSheetImpl.get_isDashboard()) {
				var dashboardImpl = ss.cast(activeSheetImpl, $tab__DashboardImpl);
				worksheetImpl = dashboardImpl.get_worksheets()._get(notification.get_worksheetName())._impl;
			}
			if (ss.isValue(worksheetImpl)) {
				worksheetImpl.highlightedMarks = null;
				this.$1$MarksHighlightField(new $tab_HighlightEvent('markshighlight', this.$viz, worksheetImpl));
			}
		},
		$handleFilterChangedEvent: function VizImpl$HandleFilterChangedEvent(notification) {
			if (ss.staticEquals(this.$1$FilterChangeField, null) || !ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
				return;
			}
			var worksheetImpl = null;
			var activeSheetImpl = this.$workbookImpl.get_activeSheetImpl();
			if (ss.referenceEquals(activeSheetImpl.get_name(), notification.get_worksheetName())) {
				worksheetImpl = ss.cast(activeSheetImpl, $tab__WorksheetImpl);
			}
			else if (activeSheetImpl.get_isDashboard()) {
				var db = ss.cast(activeSheetImpl, $tab__DashboardImpl);
				worksheetImpl = db.get_worksheets()._get(notification.get_worksheetName())._impl;
			}
			else if (activeSheetImpl.get_isStory()) {
				var story = ss.cast(activeSheetImpl, $tab__StoryImpl);
				var activeStoryPoint = story.get_activeStoryPointImpl();
				var containedSheet = activeStoryPoint.get_containedSheetImpl();
				if (containedSheet.get_isDashboard()) {
					var db1 = ss.cast(containedSheet, $tab__DashboardImpl);
					worksheetImpl = db1.get_worksheets()._get(notification.get_worksheetName())._impl;
				}
				else if (ss.referenceEquals(containedSheet.get_name(), notification.get_worksheetName())) {
					worksheetImpl = ss.cast(containedSheet, $tab__WorksheetImpl);
				}
			}
			if (ss.isValue(worksheetImpl)) {
				var results = ss.cast(JSON.parse(ss.cast(notification.get_data(), String)), Array);
				var filterFieldName = results[0];
				var filterCaption = results[1];
				this.$1$FilterChangeField(new $tab_FilterEvent('filterchange', this.$viz, worksheetImpl, filterFieldName, filterCaption));
			}
		},
		$handleParameterChangedEvent: function VizImpl$HandleParameterChangedEvent(notification) {
			if (!ss.staticEquals(this.$1$ParameterValueChangeField, null)) {
				if (ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
					this.$workbookImpl.set_$lastChangedParameterImpl(null);
					var parameterName = ss.cast(notification.get_data(), String);
					this.$raiseParameterValueChange(parameterName);
				}
			}
		},
		$handleCustomViewsListLoadedEvent: function VizImpl$HandleCustomViewsListLoadedEvent(notification) {
			var info = JSON.parse(ss.cast(notification.get_data(), String));
			var process = ss.mkdel(this, function() {
				$tab__CustomViewImpl._processCustomViews(this.$workbookImpl, this.$messagingOptions, info);
			});
			var raiseEvents = ss.mkdel(this, function() {
				this.$raiseCustomViewsListLoad();
				if (!ss.staticEquals(this.$1$CustomViewLoadField, null) && !info.customViewLoaded) {
					this.$raiseCustomViewLoad(this.$workbookImpl.get_activeCustomView());
				}
			});
			if (ss.isNullOrUndefined(this.$workbookImpl)) {
				this.$initializingWorkbookImpl = true;
				this.$workbookImpl = new $tab__WorkbookImpl(this, this.$messagingOptions, ss.mkdel(this, function() {
					process();
					this.$onWorkbookInteractive(raiseEvents);
					this.$initializingWorkbookImpl = false;
				}));
			}
			else {
				process();
				this.$ensureCalledAfterFirstInteractive(raiseEvents);
			}
		},
		$handleCustomViewUpdatedEvent: function VizImpl$HandleCustomViewUpdatedEvent(notification) {
			var info = JSON.parse(ss.cast(notification.get_data(), String));
			if (ss.isNullOrUndefined(this.$workbookImpl)) {
				this.$workbookImpl = new $tab__WorkbookImpl(this, this.$messagingOptions, null);
			}
			if (ss.isValue(this.$workbookImpl)) {
				$tab__CustomViewImpl._processCustomViewUpdate(this.$workbookImpl, this.$messagingOptions, info, true);
			}
			if (!ss.staticEquals(this.$1$CustomViewSaveField, null)) {
				var updated = this.$workbookImpl.get_$updatedCustomViews()._toApiCollection();
				for (var i = 0, len = updated.length; i < len; i++) {
					this.$raiseCustomViewSave(updated[i]);
				}
			}
		},
		$handleCustomViewRemovedEvent: function VizImpl$HandleCustomViewRemovedEvent() {
			if (!ss.staticEquals(this.$1$CustomViewRemoveField, null)) {
				var removed = this.$workbookImpl.get_$removedCustomViews()._toApiCollection();
				for (var i = 0, len = removed.length; i < len; i++) {
					this.$raiseCustomViewRemove(removed[i]);
				}
			}
		},
		$handleCustomViewSetDefaultEvent: function VizImpl$HandleCustomViewSetDefaultEvent(notification) {
			var info = JSON.parse(ss.cast(notification.get_data(), String));
			if (ss.isValue(this.$workbookImpl)) {
				$tab__CustomViewImpl._processCustomViews(this.$workbookImpl, this.$messagingOptions, info);
			}
			if (!ss.staticEquals(this.$1$CustomViewSetDefaultField, null) && ss.isValue(info.defaultCustomViewId)) {
				var views = this.$workbookImpl.get_$customViews();
				for (var i = 0; i < views.get__length(); i++) {
					var view = views.get_item(i);
					if (view.getDefault()) {
						this.$raiseCustomViewSetDefault(view);
						break;
					}
				}
			}
		},
		$handleTabSwitchEvent: function VizImpl$HandleTabSwitchEvent(notification) {
			this.$workbookImpl._update(ss.mkdel(this, function() {
				if (ss.isValue(this.$workbookTabSwitchHandler)) {
					this.$workbookTabSwitchHandler();
				}
				if (ss.referenceEquals(this.$workbookImpl.get_name(), notification.get_workbookName())) {
					var oldSheetName = notification.get_worksheetName();
					var currSheetName = ss.cast(notification.get_data(), String);
					this.$raiseTabSwitch(oldSheetName, currSheetName);
				}
				this.$onWorkbookInteractive(null);
			}));
		},
		$handleStorytellingStateChangedEvent: function VizImpl$HandleStorytellingStateChangedEvent(notification) {
			var storyImpl = ss.cast(this.$workbookImpl.get_activeSheetImpl(), $tab__StoryImpl);
			if (storyImpl.get_sheetType() === 'story') {
				storyImpl.update(JSON.parse(ss.cast(notification.get_data(), String)));
			}
		},
		$onWorkbookInteractive: function VizImpl$OnWorkbookInteractive(actionAfterFirstInteractive) {
			if (!this.$onFirstInteractiveAlreadyCalled) {
				var callback = this.$onFirstInteractiveCallback;
				window.setTimeout(ss.mkdel(this, function() {
					if (!ss.staticEquals(callback, null)) {
						callback(new $tab_TableauEvent('firstinteractive', this.$viz));
					}
					if (!ss.staticEquals(actionAfterFirstInteractive, null)) {
						actionAfterFirstInteractive();
					}
				}), 0);
				this.$onFirstInteractiveAlreadyCalled = true;
			}
			this.$raiseStateReadyForQuery();
		},
		$ensureCalledAfterFirstInteractive: function VizImpl$EnsureCalledAfterFirstInteractive(action) {
			var start = new Date();
			var poll = null;
			poll = ss.mkdel(this, function() {
				var now = new Date();
				if (this.$onFirstInteractiveAlreadyCalled) {
					action();
				}
				else if (now - start > 300000) {
					throw $tab__TableauException.createInternalError('Timed out while waiting for the viz to become interactive');
				}
				else {
					window.setTimeout(poll, 10);
				}
			});
			poll();
		},
		$checkForDone: function VizImpl$CheckForDone() {
			if ($tab__Utility.isIE()) {
				if (this.$iframe['readyState'] === 'complete') {
					this.handleVizLoad();
				}
			}
			else {
				this.handleVizLoad();
			}
		},
		$onCheckForDone: function VizImpl$OnCheckForDone() {
			window.setTimeout(ss.mkdel(this, this.$checkForDone), 3000);
		},
		$createStaticImageElement: function VizImpl$CreateStaticImageElement(initialSize) {
			var $t1 = document.createElement('div');
			var img = ss.cast($t1, ss.isValue($t1) && (ss.isInstanceOfType($t1, Element) && $t1.tagName === 'DIV'));
			img.style.background = "transparent url('" + this.$parameters.staticImageUrl + "') no-repeat scroll 0 0";
			img.style.left = '8px';
			img.style.top = (this.$parameters.tabs ? '31px' : '9px');
			img.style.position = 'absolute';
			img.style.width = initialSize.width + 'px';
			img.style.height = initialSize.height + 'px';
			this.$contentRootElement().appendChild(img);
			return img;
		},
		$createIframe: function VizImpl$CreateIframe() {
			if (ss.isNullOrUndefined(this.$contentRootElement())) {
				return null;
			}
			var $t1 = document.createElement('IFrame');
			var ifr = ss.cast($t1, ss.isValue($t1) && (ss.isInstanceOfType($t1, Element) && $t1.tagName === 'IFRAME'));
			ifr.frameBorder = '0';
			ifr.setAttribute('allowTransparency', 'true');
			ifr.setAttribute('allowFullScreen', 'true');
			ifr.setAttribute('title', this.$getLocalizedTitle());
      ifr.setAttribute('data-hj-allow-iframe', 'true');
			ifr.marginHeight = '0';
			ifr.marginWidth = '0';
			ifr.style.display = 'block';
			if (this.$parameters.fixedSize) {
				ifr.style.width = this.$parameters.width;
				ifr.style.height = this.$parameters.height;
			}
			else {
				ifr.style.width = '1px';
				ifr.style.height = '1px';
				ifr.setAttribute('scrolling', 'no');
			}
			if ($tab__Utility.isSafari()) {
				ifr.addEventListener('mousewheel', ss.mkdel(this, this.$onIframeMouseWheel), false);
			}
			this.$contentRootElement().appendChild(ifr);
			return ifr;
		},
		$getLocalizedTitle: function VizImpl$GetLocalizedTitle() {
			var lang = window.navigator.language;
			if (lang === 'zh-CN') {
				return '数据可视化';
			}
			switch (lang.substr(0, 2)) {
				case 'fr': {
					return 'Visualisation de données';
				}
				case 'es': {
					return 'Visualización de datos';
				}
				case 'pt': {
					return 'Visualização de dados';
				}
				case 'ja': {
					return 'データ ビジュアライゼーション';
				}
				case 'de': {
					return 'Datenvisualisierung';
				}
				case 'ko': {
					return '데이터 비주얼리제이션';
				}
				case 'en':
				default: {
					return 'data visualization';
				}
			}
		},
		$onIframeMouseWheel: function VizImpl$OnIframeMouseWheel(e) {
		},
		$getOnCheckForDoneDelegate: function VizImpl$GetOnCheckForDoneDelegate() {
			return ss.mkdel(this, function(e) {
				this.$onCheckForDone();
			});
		},
		$handleInitialVizSize: function VizImpl$HandleInitialVizSize(vizAndChromeSize) {
			var sheetSize = $tab_SheetSizeFactory.fromSizeConstraints(vizAndChromeSize.sizeConstraints);
			this.$vizSize = $tab_VizSize.$ctor(sheetSize, vizAndChromeSize.chromeHeight);
			if (ss.isValue(this.$onFirstVizSizeKnownCallback)) {
				this.$onFirstVizSizeKnownCallback(new $tab_FirstVizSizeKnownEvent('firstvizsizeknown', this.$viz, this.$vizSize));
			}
			if (this.$parameters.fixedSize) {
				return;
			}
			this.$refreshSize();
			this.$addWindowResizeHandler();
			this.$show();
		},
		$removeWindowResizeHandler: function VizImpl$RemoveWindowResizeHandler() {
			if (ss.isNullOrUndefined(this.$windowResizeHandler)) {
				return;
			}
			if ($tab__Utility.hasWindowAddEventListener()) {
				window.removeEventListener('resize', this.$windowResizeHandler, false);
			}
			else {
				window.self.detachEvent('onresize', this.$windowResizeHandler);
			}
			this.$windowResizeHandler = null;
		},
		$addWindowResizeHandler: function VizImpl$AddWindowResizeHandler() {
			if (ss.isValue(this.$windowResizeHandler)) {
				return;
			}
			this.$windowResizeHandler = ss.mkdel(this, function() {
				this.$refreshSize();
			});
			if ($tab__Utility.hasWindowAddEventListener()) {
				window.addEventListener('resize', this.$windowResizeHandler, false);
			}
			else {
				window.self.attachEvent('onresize', this.$windowResizeHandler);
			}
		}
	}, null, [$tab_ICrossDomainMessageHandler]);
	ss.initClass($tab_VizResizeEvent, $asm, {
		getAvailableSize: function VizResizeEvent$GetAvailableSize() {
			return this.$availableSize;
		}
	}, $tab_TableauEvent);
	ss.initClass($tab_VizSize, $asm, {}, Object);
	ss.initClass($tableauSoftware_Filter, $asm, {
		getFilterType: function Filter$GetFilterType() {
			return this.$type;
		},
		getFieldName: function Filter$GetFieldName() {
			return this.$caption;
		},
		getWorksheet: function Filter$GetWorksheet() {
			return this.$worksheetImpl.get_worksheet();
		},
		getFieldAsync: function Filter$GetFieldAsync() {
			var deferred = new tab._Deferred();
			if (ss.isNullOrUndefined(this.$field)) {
				var rejected = function(e) {
					deferred.reject(e);
					return null;
				};
				var fulfilled = ss.mkdel(this, function(value) {
					this.$field = new $tableauSoftware_Field(value, this.$caption, this.$fieldRole, this.$fieldAggregation);
					deferred.resolve(this.$field);
					return null;
				});
				this.$worksheetImpl.$getDataSourceAsync(this.$dataSourceName).then(fulfilled, rejected);
			}
			else {
				window.setTimeout(ss.mkdel(this, function() {
					deferred.resolve(this.$field);
				}), 0);
			}
			return deferred.get_promise();
		},
		_update: function Filter$Update(pm) {
			this.$initializeFromJson(pm);
			this._updateFromJson(pm);
		},
		_addFieldParams: function Filter$AddFieldParams(param) {
		},
		_updateFromJson: null,
		$initializeFromJson: function Filter$InitializeFromJson(pm) {
			this.$caption = pm.caption;
			this.$type = $tab_ApiEnumConverter.convertFilterType(pm.filterType);
			this.$field = null;
			this.$dataSourceName = pm.dataSourceName;
			this.$fieldRole = $tab_ApiEnumConverter.convertFieldRole(ss.coalesce(pm.fieldRole, 'unknown'));
			this.$fieldAggregation = $tab_ApiEnumConverter.convertFieldAggregation(ss.coalesce(pm.fieldAggregation, 'NONE'));
		}
	});
	ss.initClass($tableauSoftware_CategoricalFilter, $asm, {
		getIsExcludeMode: function CategoricalFilter$GetIsExcludeMode() {
			return this.$isExclude;
		},
		getAppliedValues: function CategoricalFilter$GetAppliedValues() {
			return this.$appliedValues;
		},
		_updateFromJson: function CategoricalFilter$UpdateFromJson(pm) {
			this.$initializeFromJson$1(pm);
		},
		$initializeFromJson$1: function CategoricalFilter$InitializeFromJson(pm) {
			this.$isExclude = pm.isExclude;
			if (ss.isValue(pm.appliedValues)) {
				this.$appliedValues = [];
				for (var $t1 = 0; $t1 < pm.appliedValues.length; $t1++) {
					var v = pm.appliedValues[$t1];
					this.$appliedValues.push($tab__Utility.getDataValue(v));
				}
			}
		}
	}, $tableauSoftware_Filter);
	ss.initClass($tableauSoftware_Column, $asm, {
		getFieldName: function Column$GetFieldName() {
			return this.$impl.get_fieldName();
		},
		getDataType: function Column$GetDataType() {
			return this.$impl.get_dataType();
		},
		getIsReferenced: function Column$GetIsReferenced() {
			return this.$impl.get_isReferenced();
		},
		getIndex: function Column$GetIndex() {
			return this.$impl.get_index();
		}
	});
	ss.initClass($tableauSoftware_CustomView, $asm, {
		getWorkbook: function CustomView$GetWorkbook() {
			return this._impl.get_$workbook();
		},
		getUrl: function CustomView$GetUrl() {
			return this._impl.get_$url();
		},
		getName: function CustomView$GetName() {
			return this._impl.get_$name();
		},
		setName: function CustomView$SetName(value) {
			this._impl.set_$name(value);
		},
		getOwnerName: function CustomView$GetOwnerName() {
			return this._impl.get_$ownerName();
		},
		getAdvertised: function CustomView$GetAdvertised() {
			return this._impl.get_$advertised();
		},
		setAdvertised: function CustomView$SetAdvertised(value) {
			this._impl.set_$advertised(value);
		},
		getDefault: function CustomView$GetDefault() {
			return this._impl.get_$isDefault();
		},
		saveAsync: function CustomView$SaveAsync() {
			return this._impl.$saveAsync();
		}
	});
	ss.initClass($tableauSoftware_Sheet, $asm, {
		getName: function Sheet$GetName() {
			return this._impl.get_name();
		},
		getIndex: function Sheet$GetIndex() {
			return this._impl.get_index();
		},
		getWorkbook: function Sheet$GetWorkbook() {
			return this._impl.get_workbookImpl().get_workbook();
		},
		getSize: function Sheet$GetSize() {
			return this._impl.get_size();
		},
		getIsHidden: function Sheet$GetIsHidden() {
			return this._impl.get_isHidden();
		},
		getIsActive: function Sheet$GetIsActive() {
			return this._impl.get_isActive();
		},
		getSheetType: function Sheet$GetSheetType() {
			return this._impl.get_sheetType();
		},
		getUrl: function Sheet$GetUrl() {
			return this._impl.get_url();
		},
		changeSizeAsync: function Sheet$ChangeSizeAsync(size) {
			return this._impl.changeSizeAsync(size);
		}
	});
	ss.initClass($tableauSoftware_Dashboard, $asm, {
		getParentStoryPoint: function Dashboard$GetParentStoryPoint() {
			return this._impl.get_parentStoryPoint();
		},
		getObjects: function Dashboard$GetObjects() {
			return this._impl.get_objects()._toApiCollection();
		},
		getWorksheets: function Dashboard$GetWorksheets() {
			return this._impl.get_worksheets()._toApiCollection();
		}
	}, $tableauSoftware_Sheet);
	ss.initClass($tableauSoftware_DashboardObject, $asm, {
		getObjectType: function DashboardObject$GetObjectType() {
			return this.$zoneInfo.objectType;
		},
		getDashboard: function DashboardObject$GetDashboard() {
			return this.$dashboard;
		},
		getWorksheet: function DashboardObject$GetWorksheet() {
			return this.$worksheet;
		},
		getPosition: function DashboardObject$GetPosition() {
			return this.$zoneInfo.position;
		},
		getSize: function DashboardObject$GetSize() {
			return this.$zoneInfo.size;
		}
	});
	ss.initClass($tableauSoftware_DataSource, $asm, {
		getName: function DataSource$GetName() {
			return this.$impl.get_name();
		},
		getFields: function DataSource$GetFields() {
			return this.$impl.get_fields()._toApiCollection();
		},
		getIsPrimary: function DataSource$GetIsPrimary() {
			return this.$impl.get_isPrimary();
		}
	});
	ss.initClass($tableauSoftware_DataTable, $asm, {
		getName: function DataTable$GetName() {
			return this.$impl.get_name();
		},
		getData: function DataTable$GetData() {
			return this.$impl.get_rows();
		},
		getColumns: function DataTable$GetColumns() {
			return this.$impl.get_columns();
		},
		getTotalRowCount: function DataTable$GetTotalRowCount() {
			return this.$impl.get_totalRowCount();
		},
		getIsSummaryData: function DataTable$GetIsSummaryData() {
			return this.$impl.get_isSummaryData();
		}
	});
	ss.initClass($tableauSoftware_Field, $asm, {
		getDataSource: function Field$GetDataSource() {
			return this.$dataSource;
		},
		getName: function Field$GetName() {
			return this.$name;
		},
		getRole: function Field$GetRole() {
			return this.$fieldRoleType;
		},
		getAggregation: function Field$GetAggregation() {
			return this.$fieldAggrType;
		}
	});
	ss.initClass($tableauSoftware_HierarchicalFilter, $asm, {
		_addFieldParams: function HierarchicalFilter$AddFieldParams(param) {
			param['api.filterHierarchicalLevels'] = this.$levels;
		},
		_updateFromJson: function HierarchicalFilter$UpdateFromJson(pm) {
			this.$initializeFromJson$1(pm);
		},
		$initializeFromJson$1: function HierarchicalFilter$InitializeFromJson(pm) {
			this.$levels = pm.levels;
		}
	}, $tableauSoftware_Filter);
	ss.initClass($tableauSoftware_Mark, $asm, {
		getPairs: function Mark$GetPairs() {
			return this.$impl.get_$clonedPairs();
		}
	});
	ss.initClass($tableauSoftware_Pair, $asm, {});
	ss.initClass($tableauSoftware_Parameter, $asm, {
		getName: function Parameter$GetName() {
			return this._impl.get_$name();
		},
		getCurrentValue: function Parameter$GetCurrentValue() {
			return this._impl.get_$currentValue();
		},
		getDataType: function Parameter$GetDataType() {
			return this._impl.get_$dataType();
		},
		getAllowableValuesType: function Parameter$GetAllowableValuesType() {
			return this._impl.get_$allowableValuesType();
		},
		getAllowableValues: function Parameter$GetAllowableValues() {
			return this._impl.get_$allowableValues();
		},
		getMinValue: function Parameter$GetMinValue() {
			return this._impl.get_$minValue();
		},
		getMaxValue: function Parameter$GetMaxValue() {
			return this._impl.get_$maxValue();
		},
		getStepSize: function Parameter$GetStepSize() {
			return this._impl.get_$stepSize();
		},
		getDateStepPeriod: function Parameter$GetDateStepPeriod() {
			return this._impl.get_$dateStepPeriod();
		}
	});
	ss.initClass($tableauSoftware_QuantitativeFilter, $asm, {
		getMin: function QuantitativeFilter$GetMin() {
			return this.$min;
		},
		getMax: function QuantitativeFilter$GetMax() {
			return this.$max;
		},
		getIncludeNullValues: function QuantitativeFilter$GetIncludeNullValues() {
			return this.$includeNullValues;
		},
		getDomainMin: function QuantitativeFilter$GetDomainMin() {
			return this.$domainMin;
		},
		getDomainMax: function QuantitativeFilter$GetDomainMax() {
			return this.$domainMax;
		},
		_updateFromJson: function QuantitativeFilter$UpdateFromJson(pm) {
			this.$initializeFromJson$1(pm);
		},
		$initializeFromJson$1: function QuantitativeFilter$InitializeFromJson(pm) {
			this.$domainMin = $tab__Utility.getDataValue(pm.domainMinValue);
			this.$domainMax = $tab__Utility.getDataValue(pm.domainMaxValue);
			this.$min = $tab__Utility.getDataValue(pm.minValue);
			this.$max = $tab__Utility.getDataValue(pm.maxValue);
			this.$includeNullValues = pm.includeNullValues;
		}
	}, $tableauSoftware_Filter);
	ss.initClass($tableauSoftware_RelativeDateFilter, $asm, {
		getPeriod: function RelativeDateFilter$GetPeriod() {
			return this.$periodType;
		},
		getRange: function RelativeDateFilter$GetRange() {
			return this.$rangeType;
		},
		getRangeN: function RelativeDateFilter$GetRangeN() {
			return this.$rangeN;
		},
		_updateFromJson: function RelativeDateFilter$UpdateFromJson(pm) {
			this.$initializeFromJson$1(pm);
		},
		$initializeFromJson$1: function RelativeDateFilter$InitializeFromJson(pm) {
			if (ss.isValue(pm.periodType)) {
				this.$periodType = $tab_ApiEnumConverter.convertPeriodType(ss.unbox(pm.periodType));
			}
			if (ss.isValue(pm.rangeType)) {
				this.$rangeType = $tab_ApiEnumConverter.convertDateRange(ss.unbox(pm.rangeType));
			}
			if (ss.isValue(pm.rangeN)) {
				this.$rangeN = ss.unbox(pm.rangeN);
			}
		}
	}, $tableauSoftware_Filter);
	ss.initClass($tableauSoftware_SheetInfo, $asm, {
		getName: function ApiSheetInfo$GetName() {
			return this.$impl.name;
		},
		getSheetType: function ApiSheetInfo$GetSheetType() {
			return this.$impl.sheetType;
		},
		getSize: function ApiSheetInfo$GetSize() {
			return this.$impl.size;
		},
		getIndex: function ApiSheetInfo$GetIndex() {
			return this.$impl.index;
		},
		getUrl: function ApiSheetInfo$GetUrl() {
			return this.$impl.url;
		},
		getIsActive: function ApiSheetInfo$GetIsActive() {
			return this.$impl.isActive;
		},
		getIsHidden: function ApiSheetInfo$GetIsHidden() {
			return this.$impl.isHidden;
		},
		getWorkbook: function ApiSheetInfo$GetWorkbook() {
			return this.$impl.workbook;
		}
	});
	ss.initClass($tableauSoftware_Story, $asm, {
		getActiveStoryPoint: function Story$GetActiveStoryPoint() {
			return this._impl.get_activeStoryPointImpl().get_storyPoint();
		},
		getStoryPointsInfo: function Story$GetStoryPointsInfo() {
			return this._impl.get_storyPointsInfo();
		},
		activatePreviousStoryPointAsync: function Story$ActivatePreviousStoryPointAsync() {
			return this._impl.activatePreviousStoryPointAsync();
		},
		activateNextStoryPointAsync: function Story$ActivateNextStoryPointAsync() {
			return this._impl.activateNextStoryPointAsync();
		},
		activateStoryPointAsync: function Story$ActivateStoryPointAsync(index) {
			return this._impl.activateStoryPointAsync(index);
		},
		revertStoryPointAsync: function Story$RevertStoryPointAsync(index) {
			return this._impl.revertStoryPointAsync(index);
		}
	}, $tableauSoftware_Sheet);
	ss.initClass($tableauSoftware_StoryPoint, $asm, {
		getCaption: function StoryPoint$GetCaption() {
			return this.$impl.get_caption();
		},
		getContainedSheet: function StoryPoint$GetContainedSheet() {
			return (ss.isValue(this.$impl.get_containedSheetImpl()) ? this.$impl.get_containedSheetImpl().get_sheet() : null);
		},
		getIndex: function StoryPoint$GetIndex() {
			return this.$impl.get_index();
		},
		getIsActive: function StoryPoint$GetIsActive() {
			return this.$impl.get_isActive();
		},
		getIsUpdated: function StoryPoint$GetIsUpdated() {
			return this.$impl.get_isUpdated();
		},
		getParentStory: function StoryPoint$GetParentStory() {
			return this.$impl.get_parentStoryImpl().get_story();
		}
	});
	ss.initClass($tableauSoftware_StoryPointInfo, $asm, {
		getCaption: function StoryPointInfo$GetCaption() {
			return this._impl.caption;
		},
		getIndex: function StoryPointInfo$GetIndex() {
			return this._impl.index;
		},
		getIsActive: function StoryPointInfo$GetIsActive() {
			return this._impl.isActive;
		},
		getIsUpdated: function StoryPointInfo$GetIsUpdated() {
			return this._impl.isUpdated;
		},
		getParentStory: function StoryPointInfo$GetParentStory() {
			return this._impl.parentStoryImpl.get_story();
		}
	});
	ss.initClass($tableauSoftware_Version, $asm, {
		getMajor: function Version$GetMajor() {
			return this.$major;
		},
		getMinor: function Version$GetMinor() {
			return this.$minor;
		},
		getPatch: function Version$GetPatch() {
			return this.$patch;
		},
		getMetadata: function Version$GetMetadata() {
			return this.$metadata;
		},
		toString: function Version$ToString() {
			var version = this.$major + '.' + this.$minor + '.' + this.$patch;
			if (ss.isValue(this.$metadata) && this.$metadata.length > 0) {
				version += '-' + this.$metadata;
			}
			return version;
		}
	});
	ss.initClass($tableauSoftware_Viz, $asm, {
		getAreTabsHidden: function Viz$GetAreTabsHidden() {
			return this._impl.get_$areTabsHidden();
		},
		getIsToolbarHidden: function Viz$GetIsToolbarHidden() {
			return this._impl.get_$isToolbarHidden();
		},
		getIsHidden: function Viz$GetIsHidden() {
			return this._impl.get_$isHidden();
		},
		getInstanceId: function Viz$GetInstanceId() {
			return this._impl.get_instanceId();
		},
		getParentElement: function Viz$GetParentElement() {
			return this._impl.get_$parentElement();
		},
		getUrl: function Viz$GetUrl() {
			return this._impl.get_$url();
		},
		getVizSize: function Viz$GetVizSize() {
			return this._impl.get_$vizSize();
		},
		getWorkbook: function Viz$GetWorkbook() {
			return this._impl.get_$workbook();
		},
		getAreAutomaticUpdatesPaused: function Viz$GetAreAutomaticUpdatesPaused() {
			return this._impl.get_$areAutomaticUpdatesPaused();
		},
		getCurrentUrlAsync: function Viz$GetCurrentUrlAsync() {
			return this._impl.getCurrentUrlAsync();
		},
		addEventListener: function Viz$AddEventListener(eventName, handler) {
			this._impl.addEventListener(eventName, handler);
		},
		removeEventListener: function Viz$RemoveEventListener(eventName, handler) {
			this._impl.removeEventListener(eventName, handler);
		},
		dispose: function Viz$Dispose() {
			this._impl.$dispose();
		},
		show: function Viz$Show() {
			this._impl.$show();
		},
		hide: function Viz$Hide() {
			this._impl.$hide();
		},
		showExportDataDialog: function Viz$ShowExportDataDialog(worksheetWithinDashboard) {
			this._impl.$showExportDataDialog(worksheetWithinDashboard);
		},
		showExportCrossTabDialog: function Viz$ShowExportCrossTabDialog(worksheetWithinDashboard) {
			this._impl.$showExportCrossTabDialog(worksheetWithinDashboard);
		},
		showExportImageDialog: function Viz$ShowExportImageDialog() {
			this._impl.$showExportImageDialog();
		},
		showExportPDFDialog: function Viz$ShowExportPDFDialog() {
			this._impl.$showExportPDFDialog();
		},
		revertAllAsync: function Viz$RevertAllAsync() {
			return this._impl.$revertAllAsync();
		},
		refreshDataAsync: function Viz$RefreshDataAsync() {
			return this._impl.$refreshDataAsync();
		},
		showShareDialog: function Viz$ShowShareDialog() {
			this._impl.$showShareDialog();
		},
		showDownloadWorkbookDialog: function Viz$ShowDownloadWorkbookDialog() {
			this._impl.$showDownloadWorkbookDialog();
		},
		pauseAutomaticUpdatesAsync: function Viz$PauseAutomaticUpdatesAsync() {
			return this._impl.$pauseAutomaticUpdatesAsync();
		},
		resumeAutomaticUpdatesAsync: function Viz$ResumeAutomaticUpdatesAsync() {
			return this._impl.$resumeAutomaticUpdatesAsync();
		},
		toggleAutomaticUpdatesAsync: function Viz$ToggleAutomaticUpdatesAsync() {
			return this._impl.$toggleAutomaticUpdatesAsync();
		},
		refreshSize: function Viz$RefreshSize() {
			this._impl.$refreshSize();
		},
		setFrameSize: function Viz$SetFrameSize(width, height) {
			var widthString = width;
			var heightString = height;
			if ($tab__Utility.isNumber(width)) {
				widthString = width.toString() + 'px';
			}
			if ($tab__Utility.isNumber(height)) {
				heightString = height.toString() + 'px';
			}
			this._impl.$setFrameSizeAndUpdate(widthString, heightString);
		}
	});
	ss.initClass($tableauSoftware_VizManager, $asm, {});
	ss.initClass($tableauSoftware_Workbook, $asm, {
		getViz: function Workbook$GetViz() {
			return this.$workbookImpl.get_viz();
		},
		getPublishedSheetsInfo: function Workbook$GetPublishedSheetsInfo() {
			return this.$workbookImpl.get_publishedSheets()._toApiCollection();
		},
		getName: function Workbook$GetName() {
			return this.$workbookImpl.get_name();
		},
		getActiveSheet: function Workbook$GetActiveSheet() {
			return this.$workbookImpl.get_activeSheetImpl().get_sheet();
		},
		getActiveCustomView: function Workbook$GetActiveCustomView() {
			return this.$workbookImpl.get_activeCustomView();
		},
		activateSheetAsync: function Workbook$ActivateSheetAsync(sheetNameOrIndex) {
			return this.$workbookImpl._setActiveSheetAsync(sheetNameOrIndex);
		},
		revertAllAsync: function Workbook$RevertAllAsync() {
			return this.$workbookImpl._revertAllAsync();
		},
		getCustomViewsAsync: function Workbook$GetCustomViewsAsync() {
			return this.$workbookImpl.$getCustomViewsAsync();
		},
		showCustomViewAsync: function Workbook$ShowCustomViewAsync(customViewName) {
			return this.$workbookImpl.$showCustomViewAsync(customViewName);
		},
		removeCustomViewAsync: function Workbook$RemoveCustomViewAsync(customViewName) {
			return this.$workbookImpl.$removeCustomViewAsync(customViewName);
		},
		rememberCustomViewAsync: function Workbook$RememberCustomViewAsync(customViewName) {
			return this.$workbookImpl.$rememberCustomViewAsync(customViewName);
		},
		setActiveCustomViewAsDefaultAsync: function Workbook$SetActiveCustomViewAsDefaultAsync() {
			return this.$workbookImpl.$setActiveCustomViewAsDefaultAsync();
		},
		getParametersAsync: function Workbook$GetParametersAsync() {
			return this.$workbookImpl.$getParametersAsync();
		},
		changeParameterValueAsync: function Workbook$ChangeParameterValueAsync(parameterName, value) {
			return this.$workbookImpl.$changeParameterValueAsync(parameterName, value);
		}
	});
	ss.initClass($tableauSoftware_Worksheet, $asm, {
		getParentDashboard: function Worksheet$GetParentDashboard() {
			return this._impl.get_parentDashboard();
		},
		getParentStoryPoint: function Worksheet$GetParentStoryPoint() {
			return this._impl.get_parentStoryPoint();
		},
		getDataSourcesAsync: function Worksheet$GetDataSourcesAsync() {
			return this._impl.$getDataSourcesAsync();
		},
		getFilterAsync: function Worksheet$GetFilterAsync(fieldName, options) {
			return this._impl.$getFilterAsync(null, fieldName, options);
		},
		getFiltersAsync: function Worksheet$GetFiltersAsync(options) {
			return this._impl.$getFiltersAsync(options);
		},
		applyFilterAsync: function Worksheet$ApplyFilterAsync(fieldName, values, updateType, options) {
			return this._impl.$applyFilterAsync(fieldName, values, updateType, options);
		},
		clearFilterAsync: function Worksheet$ClearFilterAsync(fieldName) {
			return this._impl.$clearFilterAsync(fieldName);
		},
		applyRangeFilterAsync: function Worksheet$ApplyRangeFilterAsync(fieldName, options) {
			return this._impl.$applyRangeFilterAsync(fieldName, options);
		},
		applyRelativeDateFilterAsync: function Worksheet$ApplyRelativeDateFilterAsync(fieldName, options) {
			return this._impl.$applyRelativeDateFilterAsync(fieldName, options);
		},
		applyHierarchicalFilterAsync: function Worksheet$ApplyHierarchicalFilterAsync(fieldName, values, updateType, options) {
			return this._impl.$applyHierarchicalFilterAsync(fieldName, values, updateType, options);
		},
		clearSelectedMarksAsync: function Worksheet$ClearSelectedMarksAsync() {
			return this._impl.$clearSelectedMarksAsync();
		},
		selectMarksAsync: function Worksheet$SelectMarksAsync(fieldNameOrFieldValuesMap, valueOrUpdateType, updateType) {
			return this._impl.$selectMarksAsync(fieldNameOrFieldValuesMap, valueOrUpdateType, updateType);
		},
		getSelectedMarksAsync: function Worksheet$GetSelectedMarksAsync() {
			return this._impl.$getSelectedMarksAsync();
		},
		getSummaryDataAsync: function Worksheet$GetSummaryDataAsync(options) {
			return this._impl.$getSummaryDataAsync(options);
		},
		getUnderlyingDataAsync: function Worksheet$GetUnderlyingDataAsync(options) {
			return this._impl.$getUnderlyingDataAsync(options);
		},
		clearHighlightedMarksAsync: function Worksheet$ClearHighlightedMarksAsync() {
			return this._impl.$clearHighlightedMarksAsync();
		},
		highlightMarksAsync: function Worksheet$HighlightMarksAsync(fieldName, values) {
			return this._impl.$highlightMarksAsync(fieldName, values);
		},
		highlightMarksByPatternMatchAsync: function Worksheet$HighlightMarksByPatternMatchAsync(fieldName, patternMatch) {
			return this._impl.$highlightMarksByPatternMatchAsync(fieldName, patternMatch);
		},
		getHighlightedMarksAsync: function Worksheet$GetHighlightedMarksAsync() {
			return this._impl.$getHighlightedMarksAsync();
		}
	}, $tableauSoftware_Sheet);
	(function() {
		$tab__ApiCommand.crossDomainEventNotificationId = 'xdomainSourceId';
		$tab__ApiCommand.lastRequestMessage = null;
		$tab__ApiCommand.lastResponseMessage = null;
		$tab__ApiCommand.lastClientInfoResponseMessage = null;
		$tab__ApiCommand.$nextCommandId = 0;
	})();
	(function() {
		$tab__VizManagerImpl.$vizs = [];
	})();
	(function() {
		$tab__jQueryShim.$arrayType = 'array';
		$tab__jQueryShim.$booleanType = 'boolean';
		$tab__jQueryShim.$dateType = 'date';
		$tab__jQueryShim.$functionType = 'function';
		$tab__jQueryShim.$numberType = 'number';
		$tab__jQueryShim.$objectType = 'object';
		$tab__jQueryShim.$regExpType = 'regexp';
		$tab__jQueryShim.$stringType = 'string';
		$tab__jQueryShim.$class2type = ss.mkdict(['[object Boolean]', $tab__jQueryShim.$booleanType, '[object Number]', $tab__jQueryShim.$numberType, '[object String]', $tab__jQueryShim.$stringType, '[object Function]', $tab__jQueryShim.$functionType, '[object Array]', $tab__jQueryShim.$arrayType, '[object Date]', $tab__jQueryShim.$dateType, '[object RegExp]', $tab__jQueryShim.$regExpType, '[object Object]', $tab__jQueryShim.$objectType]);
		$tab__jQueryShim.$trim = ss.cast(String.prototype['trim'], Function);
		$tab__jQueryShim.$toString = ss.cast(Object.prototype['toString'], Function);
		$tab__jQueryShim.$trimLeft = new RegExp('^[\\s\\xA0]+');
		$tab__jQueryShim.$trimRight = new RegExp('[\\s\\xA0]+$');
		$tab__jQueryShim.$rvalidchars = new RegExp('^[\\],:{}\\s]*$');
		$tab__jQueryShim.$rvalidescape = new RegExp('\\\\(?:["\\\\\\/bfnrt]|u[0-9a-fA-F]{4})', 'g');
		$tab__jQueryShim.$rvalidtokens = new RegExp('"[^"\\\\\\n\\r]*"|true|false|null|-?\\d+(?:\\.\\d*)?(?:[eE][+\\-]?\\d+)?', 'g');
		$tab__jQueryShim.$rvalidbraces = new RegExp('(?:^|:|,)(?:\\s*\\[)+', 'g');
	})();
	(function() {
		var ns = global.tableauSoftware;
		ns.DeviceType = { DEFAULT: 'default', DESKTOP: 'desktop', TABLET: 'tablet', PHONE: 'phone' };
		ns.DashboardObjectType = { BLANK: 'blank', WORKSHEET: 'worksheet', QUICK_FILTER: 'quickFilter', PARAMETER_CONTROL: 'parameterControl', PAGE_FILTER: 'pageFilter', LEGEND: 'legend', TITLE: 'title', TEXT: 'text', IMAGE: 'image', WEB_PAGE: 'webPage' };
		ns.DataType = { FLOAT: 'float', INTEGER: 'integer', STRING: 'string', BOOLEAN: 'boolean', DATE: 'date', DATETIME: 'datetime' };
		ns.DateRangeType = { LAST: 'last', LASTN: 'lastn', NEXT: 'next', NEXTN: 'nextn', CURR: 'curr', TODATE: 'todate' };
		ns.ErrorCode = { INTERNAL_ERROR: 'internalError', SERVER_ERROR: 'serverError', INVALID_AGGREGATION_FIELD_NAME: 'invalidAggregationFieldName', INVALID_PARAMETER: 'invalidParameter', INVALID_URL: 'invalidUrl', STALE_DATA_REFERENCE: 'staleDataReference', VIZ_ALREADY_IN_MANAGER: 'vizAlreadyInManager', NO_URL_OR_PARENT_ELEMENT_NOT_FOUND: 'noUrlOrParentElementNotFound', INVALID_FILTER_FIELDNAME: 'invalidFilterFieldName', INVALID_FILTER_FIELDVALUE: 'invalidFilterFieldValue', INVALID_FILTER_FIELDNAME_OR_VALUE: 'invalidFilterFieldNameOrValue', FILTER_CANNOT_BE_PERFORMED: 'filterCannotBePerformed', NOT_ACTIVE_SHEET: 'notActiveSheet', INVALID_CUSTOM_VIEW_NAME: 'invalidCustomViewName', MISSING_RANGEN_FOR_RELATIVE_DATE_FILTERS: 'missingRangeNForRelativeDateFilters', MISSING_MAX_SIZE: 'missingMaxSize', MISSING_MIN_SIZE: 'missingMinSize', MISSING_MINMAX_SIZE: 'missingMinMaxSize', INVALID_SIZE: 'invalidSize', INVALID_SIZE_BEHAVIOR_ON_WORKSHEET: 'invalidSizeBehaviorOnWorksheet', SHEET_NOT_IN_WORKBOOK: 'sheetNotInWorkbook', INDEX_OUT_OF_RANGE: 'indexOutOfRange', DOWNLOAD_WORKBOOK_NOT_ALLOWED: 'downloadWorkbookNotAllowed', NULL_OR_EMPTY_PARAMETER: 'nullOrEmptyParameter', BROWSER_NOT_CAPABLE: 'browserNotCapable', UNSUPPORTED_EVENT_NAME: 'unsupportedEventName', INVALID_DATE_PARAMETER: 'invalidDateParameter', INVALID_SELECTION_FIELDNAME: 'invalidSelectionFieldName', INVALID_SELECTION_VALUE: 'invalidSelectionValue', INVALID_SELECTION_DATE: 'invalidSelectionDate', NO_URL_FOR_HIDDEN_WORKSHEET: 'noUrlForHiddenWorksheet', MAX_VIZ_RESIZE_ATTEMPTS: 'maxVizResizeAttempts' };
		ns.FieldAggregationType = { SUM: 'SUM', AVG: 'AVG', MIN: 'MIN', MAX: 'MAX', STDEV: 'STDEV', STDEVP: 'STDEVP', VAR: 'VAR', VARP: 'VARP', COUNT: 'COUNT', COUNTD: 'COUNTD', MEDIAN: 'MEDIAN', ATTR: 'ATTR', NONE: 'NONE', PERCENTILE: 'PERCENTILE', YEAR: 'YEAR', QTR: 'QTR', MONTH: 'MONTH', DAY: 'DAY', HOUR: 'HOUR', MINUTE: 'MINUTE', SECOND: 'SECOND', WEEK: 'WEEK', WEEKDAY: 'WEEKDAY', MONTHYEAR: 'MONTHYEAR', MDY: 'MDY', END: 'END', TRUNC_YEAR: 'TRUNC_YEAR', TRUNC_QTR: 'TRUNC_QTR', TRUNC_MONTH: 'TRUNC_MONTH', TRUNC_WEEK: 'TRUNC_WEEK', TRUNC_DAY: 'TRUNC_DAY', TRUNC_HOUR: 'TRUNC_HOUR', TRUNC_MINUTE: 'TRUNC_MINUTE', TRUNC_SECOND: 'TRUNC_SECOND', QUART1: 'QUART1', QUART3: 'QUART3', SKEWNESS: 'SKEWNESS', KURTOSIS: 'KURTOSIS', INOUT: 'INOUT', SUM_XSQR: 'SUM_XSQR', USER: 'USER' };
		ns.FieldRoleType = { DIMENSION: 'dimension', MEASURE: 'measure', UNKNOWN: 'unknown' };
		ns.FilterUpdateType = { ALL: 'all', REPLACE: 'replace', ADD: 'add', REMOVE: 'remove' };
		ns.FilterType = { CATEGORICAL: 'categorical', QUANTITATIVE: 'quantitative', HIERARCHICAL: 'hierarchical', RELATIVEDATE: 'relativedate' };
		ns.NullOption = { NULL_VALUES: 'nullValues', NON_NULL_VALUES: 'nonNullValues', ALL_VALUES: 'allValues' };
		ns.ParameterAllowableValuesType = { ALL: 'all', LIST: 'list', RANGE: 'range' };
		ns.ParameterDataType = { FLOAT: 'float', INTEGER: 'integer', STRING: 'string', BOOLEAN: 'boolean', DATE: 'date', DATETIME: 'datetime' };
		ns.PeriodType = { YEAR: 'year', QUARTER: 'quarter', MONTH: 'month', WEEK: 'week', DAY: 'day', HOUR: 'hour', MINUTE: 'minute', SECOND: 'second' };
		ns.SelectionUpdateType = { REPLACE: 'replace', ADD: 'add', REMOVE: 'remove' };
		ns.SheetSizeBehavior = { AUTOMATIC: 'automatic', EXACTLY: 'exactly', RANGE: 'range', ATLEAST: 'atleast', ATMOST: 'atmost' };
		ns.SheetType = { WORKSHEET: 'worksheet', DASHBOARD: 'dashboard', STORY: 'story' };
		ns.TableauEventName = { CUSTOM_VIEW_LOAD: 'customviewload', CUSTOM_VIEW_REMOVE: 'customviewremove', CUSTOM_VIEW_SAVE: 'customviewsave', CUSTOM_VIEW_SET_DEFAULT: 'customviewsetdefault', FILTER_CHANGE: 'filterchange', FIRST_INTERACTIVE: 'firstinteractive', FIRST_VIZ_SIZE_KNOWN: 'firstvizsizeknown', MARKS_SELECTION: 'marksselection', MARKS_HIGHLIGHT: 'markshighlight', PARAMETER_VALUE_CHANGE: 'parametervaluechange', STORY_POINT_SWITCH: 'storypointswitch', TAB_SWITCH: 'tabswitch', VIZ_RESIZE: 'vizresize' };
		ns.ToolbarPosition = { TOP: 'top', BOTTOM: 'bottom' };
	})();
	(function() {
		$tab__ApiObjectRegistry.$creationRegistry = null;
		$tab__ApiObjectRegistry.$singletonInstanceRegistry = null;
	})();
	(function() {
		$tab__SheetImpl.noZoneId = 4294967295;
	})();
	(function() {
		$tab__WorksheetImpl.$regexHierarchicalFieldName = new RegExp('\\[[^\\]]+\\]\\.', 'g');
	})();
	(function() {
		$tableauSoftware_Version.$currentVersion = new $tableauSoftware_Version(2, 1, 2, 'null');
	})();
})();

window.tableau = window.tableauSoftware = global.tableauSoftware;

tableauSoftware.Promise = tab._PromiseImpl;
tab._Deferred = tab._DeferredImpl;
tab._Collection = tab._CollectionImpl;

tab._ApiBootstrap.initialize();


})();
;
(function ($, Drupal, drupalSettings) {
  Drupal.behaviors.tableauVis = {
    attach: function (context) {
      $back_bool = drupalSettings[0].tableau_vis.tableau_back_bool;
      $break_bool = drupalSettings[0].tableau_vis.tableau_break_bool;
      $breakpoint = drupalSettings[0].tableau_vis.tableau_breakpoint;
      $placeholder = drupalSettings[0].tableau_vis.tableau_placeholder_url;
      $defaultImg = drupalSettings[0].tableau_vis.default_preload_img;
      $server = drupalSettings[0].tableau_vis.tableau_server;
      $target = drupalSettings[0].tableau_vis.tableau_target_site;
      getTicket();
      checkServer();

      $("body .vis-info", context).once('tableauVis').each(function (index) {
        $this = $(this);
        var vizTainer = $this.find('.vis-container');
        vizTainer.attr('id', 'viz-' + index);
        loadHandler($this);
      });
    }
  };

  function loadHandler($this) {
    var object = $this.find('.vis-container');
    var container;
    for (var obj of object) {
      container = obj;
    }
    var deskRatio = $this.find('.desktop .aspect-ratio').text();
    var deskVis = $this.find('.desktop .visualization').text();
    var deskUseHolder = $this.find('.desktop .use-placeholder').text();
    var deskImg = $this.find('.desktop .img').text();
    var mobVis = $this.find('.mobile .visualization').text();
    var mobRatio = $this.find('.mobile .aspect-ratio').text();
    var mobUseHolder = $this.find('.mobile .use-placeholder').text();
    var mobImg = $this.find('.mobile .img').text();
    var initialWidth = $(window).width();
    var deviceSize = (initialWidth >= $breakpoint) ? 'desktop' : 'phone';
    var useHolder;
    var placeholder;
    var visual;
    if (deviceSize !== 'desktop' && mobVis.includes("/") == true) {
      if (mobRatio) {
        object.css("aspect-ratio", mobRatio);
      }
      useHolder = mobUseHolder;
      visual = mobVis;
      imgUrl = mobImg;
    } else {
      if (deskRatio) {
        object.css("aspect-ratio", deskRatio);
      }
      useHolder = deskUseHolder;
      visual = deskVis;
      imgUrl = deskImg;
    }

    if (useHolder) {
      object.addClass('pre-load');
      if (imgUrl) {
        object.prepend($('<img>', {
          class: 'preload-image',
          src: imgUrl
        }));
      } else {
        object.prepend($('<img>', {
          class: 'preload-image',
          src: $defaultImg
        }));
      }

      object.click(function () {
        object.removeClass("pre-load");
        object.removeAttr('aspect-ratio');
        object.find('.preload-image').remove();
        getTicket();
        loadViz($this, object, container, ticket, visual, deviceSize);
      });
    } else {
      loadViz($this, object, container, ticket, visual, deviceSize);
    }
    if (!!window.performance && window.performance.navigation.type === 2 && back_bool == 1) {
      window.location.reload();
    }
  }
  function loadViz($this, object, container, ticket, visual, deviceSize) {
    /* Disable Enter Key */
    $(document).keypress(function (event) {
      if (event.which == '13') {
        event.preventDefault();
      }
    });
    var submitCount;
    var visual;
    var viz;
    var idleTime = 0;
    var lastWidth;

    if (object.is(':empty') && (typeof window != 'undefined')) {
      var vizURL = $server + ticket + '/t/' + $target + '/views/' + visual;
      var options = {
        embed: 'yes',
        hideToolbar: true,
        hideTabs: true,
        device: deviceSize,
        showVizHome: 'no',
        // onFirstInteractive is a callback that happens once the Viz is loaded
        onFirstInteractive: function () {
          vizResize(object);
        }
      };

      if (serverCheck) {
        viz = new tableau.Viz(container, vizURL, options);
        submitCount = 0;
      } else {
        object.innerHTML += "<img src='" + placeholder + "' alt='tableau visualization currently unavailable' />";
      }
      $(window).resize(function () {
        vizResize(object);
        getTicket();
        checkServer();
        var windowWidth = $(window).width();
        if ((windowWidth <= $breakpoint && lastWidth >= $breakpoint && $break_bool == 1) || (windowWidth >= $breakpoint && lastWidth <= $breakpoint && $break_bool == 1)) {
          if (viz) {
            viz.dispose();
            loadHandler($this);
          }
        }
        lastWidth = windowWidth;
      });
      $('#export-viz-pdf').click(function () {
        if (viz) {
          viz.showExportImageDialog();
        }
      });

      /* If filter exists: Make API calls based on filter */
      if ($('.tableau-view').length) {
        var tableauSearch = $('.tableau-view .form-type-textfield input');
        var tableauApply = $('.tableau-view .form-submit');
      }
      $('.tableau-filter').each(function () {
        var currentFilter = $(this).attr('id');
        var pName = currentFilter.slice(4);
        var pType = $('#' + currentFilter + ' .type').val();
        var pSelect = $('#' + pName);
        var pTag = document.getElementById(pName).tagName.toLowerCase();
        var workbook;
        switch (pType) {
          case 'Filter':
          case 'SubFilter':
            pSelect.change(function () {
              value = $('#' + pName).val();
              sheet = viz.getWorkbook().getActiveSheet().getWorksheets().get("pSheet");
              return sheet.applyFilterAsync(pName, value, tableau.FilterUpdateType.REPLACE);
            });
            break;
          case 'Parameter':
            if (pTag == 'select') {
              pSelect.prop("selectedIndex", 0);
              pSelect.change(function () {
                value = $('#' + pName).val();
                if (viz) {
                  workbook = viz.getWorkbook();
                  workbook.changeParameterValueAsync(pName, value);
                  viz.refreshDataAsync();
                }
              });
            }
            if (pTag == "fieldset") {
              $("input[name='" + pName + "']:first").attr("checked", true);
              pSelect.change(function () {
                value = $("input:radio[name='" + pName + "']:checked").val();
                if (viz) {
                  workbook = viz.getWorkbook();
                  workbook.changeParameterValueAsync(pName, value);
                  viz.refreshDataAsync();
                }
              });
            } else if (pTag == 'input') {
              dropdown = $('#community-select');
              submitButton = $('#tableau-submit');
              resetButton = $('#tableau-reset');
              resultText = $('#tableau-results');
              $('#' + pName).keypress(function (event) {
                if (event.keyCode == '13') {
                  if ($('#' + pName).val() && dropdown.length) {
                    value = $('#' + pName).val();
                    $dropdownValue = dropdown.val();
                    $communityName = $dropdownValue.split(' -')[0];
                    tableauSearch.val($dropdownValue);
                    tableauApply.click();
                    if (viz) {
                      workbook = viz.getWorkbook();
                      workbook.changeParameterValueAsync(pName, value);
                      workbook.changeParameterValueAsync('pCommunity', $communityName);
                      viz.refreshDataAsync();
                    }
                  }
                }
              });
              $('#' + pName, context).once(function () {
                $(this).on('input', function (e) {
                  var valueLength = $('#' + pName).val().length;
                  value = $('#' + pName).val();
                  if (valueLength == 5) {
                    getCommunity(value);
                    dropdown.prop('disabled', false);
                  }
                });
              });
              submitButton.on('click', function () {
                if ($('#' + pName).val() && dropdown.length) {
                  value = $('#' + pName).val();
                  $dropdownValue = dropdown.val();
                  $communityName = $dropdownValue.split(' -')[0];
                  tableauSearch.val($dropdownValue);
                  tableauApply.click();
                  if (viz) {
                    workbook = viz.getWorkbook();
                    workbook.changeParameterValueAsync(pName, value);
                    workbook.changeParameterValueAsync('pCommunity', $communityName);
                    viz.refreshDataAsync();
                  }
                }
              });
              resetButton.on('click', function () {
                if (viz) {
                  viz.refreshDataAsync();
                } else {
                  window.location.reload();
                }
              });
            }
            break;
          default:
        }
      });
    }
  }

  function vizResize(object) {
    var frame = object.find('iframe');
    var frameWidth = 0;
    var frameHeight = 0;
    var containerWidth = object.width();
    frameWidth = frame.width();
    frameHeight = frame.height();
    var percentage = (containerWidth / frameWidth).toFixed(2);
    if (percentage.startsWith('0')) {
      percentage = percentage.substring(percentage.indexOf('.'));
    }
    var newHeight = (frameHeight * percentage) + 1 + 'px';
    var newWidth = (frameWidth * percentage) + 1 + 'px';

    var scale = 'scale(' + percentage + ')';

    frame.css({
      '-webkit-transform': scale,
      '-moz-transform': scale,
      '-ms-transform': scale,
      '-o-transform': scale,
      'transform': scale,
      'transform-origin': 'top left',
    });

    object.css({
      'height': newHeight
    })
  }

  function getTicket() {
    $.ajax({
      type: "GET",
      url: "/tableau-vizualization/ticket",
      async: false,
      success: function (text) {
        ticket = text;
      }
    });
  }
  function checkServer() {
    $.ajax({
      type: "GET",
      url: "/tableau-vizualization/url-check",
      async: false,
      success: function (text) {
        serverCheck = text.trim();
      }
    });
  }

  function getCommunity(zip) {
    $zip = zip;
    $url = 'rest/tableau-select-communities.json?zip=' + $zip;
    var dropdown = $('#community-select');
    dropdown.empty();
    dropdown.prop('selectedIndex', 0);
    $.getJSON($url, function (jsonData) {
      $.each(jsonData, function (key, entry) {
        $community_id = entry.value + '';
        $title = $community_id.split(' -')[0];
        dropdown.append($('<option></option>').attr('value', entry.value).text($title));
      });
    });
  }



})(jQuery, Drupal, drupalSettings);
;
jQuery(function(t){t(".hero-dash").ready(function(){960<=t(window).width()&&t(".hero-dash .hero-headline").css("font-size",function(){var e=t(this).text().length;return 1<=e&&e<15?"3.4vw":20<=e&&e<60?"3.1vw":60<=e&&e<100?"2.8vw":100<=e&&e<140?"2.6vw":"2.4vw"})})}),function(a){"use strict";Drupal.behaviors.heroModal={attach:function(e,t){a(".hero-cta").click(function(e){a(this).next(".hero-dash-cta-modal").length&&(e.preventDefault(),a(this).next(".hero-dash-cta-modal").css("display","flex"))}),a(".close").click(function(e){a(".hero-dash-cta-modal").length&&(e.preventDefault(),a(".hero-dash-cta-modal").css("display","none"))})}}}(jQuery);;
!function(e){e(".menu-featured")[0]&&e(".menu-featured").eq(0).css("margin-top","2.5rem")}(jQuery),function(i){i(document).ready(function(){var e=i(".active.depth-1 > a"),t=i(".active.depth-1 > a").attr("href"),a=i(".active.depth-1 > a").text(),n=i(".active.depth-1 > .menu > .menu-inner");0<i(".active.depth-1").children(".menu").length?i("#block-mainnavigation .active.depth-1 > a").hasClass("is-active")||i(n).append(`<li class="menu-item depth-2"><a class="menu-backto" href="${t}">${a}</a></li>`):(i(e).css("pointer-events","none"),i(e).addClass("no-after"))})}(jQuery);;
/*! js-cookie v3.0.1 | MIT */
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e=e||self,function(){var n=e.Cookies,o=e.Cookies=t();o.noConflict=function(){return e.Cookies=n,o}}())}(this,(function(){"use strict";function e(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)e[o]=n[o]}return e}return function t(n,o){function r(t,r,i){if("undefined"!=typeof document){"number"==typeof(i=e({},o,i)).expires&&(i.expires=new Date(Date.now()+864e5*i.expires)),i.expires&&(i.expires=i.expires.toUTCString()),t=encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape);var c="";for(var u in i)i[u]&&(c+="; "+u,!0!==i[u]&&(c+="="+i[u].split(";")[0]));return document.cookie=t+"="+n.write(r,t)+c}}return Object.create({set:r,get:function(e){if("undefined"!=typeof document&&(!arguments.length||e)){for(var t=document.cookie?document.cookie.split("; "):[],o={},r=0;r<t.length;r++){var i=t[r].split("="),c=i.slice(1).join("=");try{var u=decodeURIComponent(i[0]);if(o[u]=n.read(c,u),e===u)break}catch(e){}}return e?o[e]:o}},remove:function(t,n){r(t,"",e({},n,{expires:-1}))},withAttributes:function(n){return t(this.converter,e({},this.attributes,n))},withConverter:function(n){return t(e({},this.converter,n),this.attributes)}},{attributes:{value:Object.freeze(o)},converter:{value:Object.freeze(n)}})}({read:function(e){return'"'===e[0]&&(e=e.slice(1,-1)),e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent)},write:function(e){return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,decodeURIComponent)}},{path:"/"})}));
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
(function ($, Drupal, cookies) {
  var deprecatedMessageSuffix = "is deprecated in Drupal 9.0.0 and will be removed in Drupal 10.0.0. Use the core/js-cookie library instead. See https://www.drupal.org/node/3104677";
  var isFunction = function isFunction(obj) {
    return Object.prototype.toString.call(obj) === '[object Function]';
  };
  var parseCookieValue = function parseCookieValue(value, parseJson) {
    if (value.indexOf('"') === 0) {
      value = value.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    }
    try {
      value = decodeURIComponent(value.replace(/\+/g, ' '));
      return parseJson ? JSON.parse(value) : value;
    } catch (e) {}
  };
  var reader = function reader(cookieValue, cookieName, converter, readUnsanitized, parseJson) {
    var value = readUnsanitized ? cookieValue : parseCookieValue(cookieValue, parseJson);
    if (converter !== undefined && isFunction(converter)) {
      return converter(value, cookieName);
    }
    return value;
  };
  $.cookie = function (key) {
    var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : undefined;
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : undefined;
    Drupal.deprecationError({
      message: "jQuery.cookie() ".concat(deprecatedMessageSuffix)
    });
    if (value !== undefined && !isFunction(value)) {
      var attributes = _objectSpread(_objectSpread({}, $.cookie.defaults), options);
      if (typeof attributes.expires === 'string' && attributes.expires !== '') {
        attributes.expires = new Date(attributes.expires);
      }
      var cookieSetter = cookies.withConverter({
        write: function write(cookieValue) {
          return encodeURIComponent(cookieValue);
        }
      });
      value = $.cookie.json && !$.cookie.raw ? JSON.stringify(value) : String(value);
      return cookieSetter.set(key, value, attributes);
    }
    var userProvidedConverter = value;
    var cookiesShim = cookies.withConverter({
      read: function read(cookieValue, cookieName) {
        return reader(cookieValue, cookieName, userProvidedConverter, $.cookie.raw, $.cookie.json);
      }
    });
    if (key !== undefined) {
      return cookiesShim.get(key);
    }
    var results = cookiesShim.get();
    Object.keys(results).forEach(function (resultKey) {
      if (results[resultKey] === undefined) {
        delete results[resultKey];
      }
    });
    return results;
  };
  $.cookie.defaults = _objectSpread({
    path: ''
  }, cookies.defaults);
  $.cookie.json = false;
  $.cookie.raw = false;
  $.removeCookie = function (key, options) {
    Drupal.deprecationError({
      message: "jQuery.removeCookie() ".concat(deprecatedMessageSuffix)
    });
    cookies.remove(key, _objectSpread(_objectSpread({}, $.cookie.defaults), options));
    return !cookies.get(key);
  };
})(jQuery, Drupal, window.Cookies);;
!function(e,a){e.behaviors.alertMessage={attach:function(e){a(".block-global-alert",e).once("alertMessage").each(function(){var i=a(this);"true"!=a.cookie("hideAlert")&&(i.addClass("visible"),i.find(".alert-dismiss").click(function(){i.removeClass("visible");var e=new Date;e.setTime(e.getTime()+864e5),a.cookie("hideAlert","true",{expires:e})}))})}}}(Drupal,jQuery);;
!function(e,C){"use strict";e.behaviors.headerToggle={attach:function(e){C(".site-header",e).once("headerToggle").each(function(){var e,s=C(".site-header"),d=C(".layout-container"),o=C("footer"),a=(C("#copy"),C(".header-open")),n=C(".header-close"),l=C(".menu-main"),i=C(".menu-main .depth-1 > a"),t=C(".menu-main .depth-1.active > .menu"),c=C(".strut-sticky"),r=null;C(window).resize(function(){C(window).width()}),a.on("click",function(e){1==s.hasClass("closed")&&(d.addClass("closed"),d.removeClass("opened"),o.addClass("closed"),o.removeClass("opened"),l.addClass("closed"),l.removeClass("opened"),s.addClass("opened"),s.removeClass("closed"))}),n.on("click",function(e){1==s.hasClass("opened")&&(d.addClass("opened"),d.removeClass("closed"),o.addClass("opened"),o.removeClass("closed"),l.addClass("opened"),l.removeClass("closed"),s.addClass("closed"),s.removeClass("opened"))}),l.length&&C(".menu-main .depth-1").hasClass("active")&&(l.show(),i.on("click",function(e){e.preventDefault(),e.stopPropagation(),!0!==l.hasClass("opened")?(l.addClass("opened"),C(window).width()<992&&(r=C(window).width()-t.outerWidth(),t.css("padding-right",r))):(C(window).width()<992&&(r=C(window).width()-t.outerWidth(),t.css("padding-right",r)),l.removeClass("opened"))}),e=l.offset().top,C(window).scroll(function(){C(window).scrollTop()>=e?(s.addClass("fixed"),l.addClass("fixed"),c.addClass("fixed")):(s.removeClass("fixed"),l.removeClass("fixed"),c.removeClass("fixed"))}),C(document).click(e=>{C(e.target).closest("#mm").length||l.removeClass("opened")}))})}}}(Drupal,jQuery,drupalSettings);;
/**
 * @file
 * Adds Google Custom Search Watermark.
 */

(function ($, Drupal, drupalSettings) {
  'use strict';

  Drupal.behaviors.googleCSECustomSearch = {
    attach: function (context, settings) {
      if (!drupalSettings.googleCSE.isDefault) {
        return;
      }
      var getWatermarkBackground = function (value) {
        var googleCSEBaseUrl = 'https://www.google.com/cse/intl/';
        var googleCSEImageUrl = 'images/google_custom_search_watermark.gif';
        var language = drupalSettings.googleCSE.language + '/';
        return value ? '' : ' url(' + googleCSEBaseUrl + language + googleCSEImageUrl + ') left no-repeat';
      };
      var onFocus = function (e) {
        $(e.target).css('background', '#ffffff');
      };
      var onBlur = function (e) {
        $(e.target).css('background', '#ffffff' + getWatermarkBackground($(e.target).val()));
      };
      var googleCSEWatermark = function (context, query) {
        var form = jQuery(context);
        var searchInputs = $('[data-drupal-selector="' + query + '"]', form);
        if (navigator.platform === 'Win32') {
          searchInputs.css('style', 'border: 1px solid #7e9db9; padding: 2px;');
        }
        searchInputs.blur(onBlur);
        searchInputs.focus(onFocus);
        searchInputs.each(function () {
          var event = {};
          event.target = this;
          onBlur(event);
        });
      };

      googleCSEWatermark('[data-drupal-selector="search-block-form"] [data-drupal-form-fields="edit-keys--2"]', 'edit-keys');
      googleCSEWatermark('[data-drupal-selector="search-block-form"] [data-drupal-form-fields="edit-keys"]', 'edit-keys');
      googleCSEWatermark('[data-drupal-selector="search-form"]', 'edit-keys');
      googleCSEWatermark('[data-drupal-selector="google-cse-search-box-form"]', 'edit-query');
    }
  };
})(jQuery, Drupal, drupalSettings);
;
!function(e,n){"use strict";e.behaviors.SearchForm={attach:function(e){var o=n(".search-block-form"),c=n('.search-block-form input[type="submit"]'),r=n(".search-block-form .close"),a=n('.search-block-form input[type="search"]'),t=n("#block-tertiarymenu");c.on("click",function(e){!0!==o.hasClass("opened")&992<n(window).width()&&(o.addClass("opened"),a.attr("placeholder","Search"),t.hide(),e.preventDefault())}),r.on("click",function(){o.removeClass("opened"),t.show()})}}}(Drupal,jQuery);;
